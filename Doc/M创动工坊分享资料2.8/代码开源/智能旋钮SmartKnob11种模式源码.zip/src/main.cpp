/**
 * ESP32 position motion control example with magnetic sensor
 */

//本代码由CSDN loop222编写，感谢！
//M创动工坊仅增加了串口输入切换模式。

 
#include <SimpleFOC.h>

// SPI Magnetic sensor instance (AS5047U example)
// MISO 12
// MOSI 9
// SCK 14
// magnetic sensor instance - SPI
//MagneticSensorSPI sensor = MagneticSensorSPI(AS5147_SPI, 5);  //15

// I2C Magnetic sensor instance (AS5600 example)
// make sure to use the pull-ups!!
// SDA 21
// SCL 22
// magnetic sensor instance - I2C
MagneticSensorI2C sensor = MagneticSensorI2C(AS5600_I2C);

// Analog output Magnetic sensor instance (AS5600)
// MagneticSensorAnalog sensor = MagneticSensorAnalog(A1, 14, 1020);

// Motor instance
BLDCMotor motor = BLDCMotor(7);   //11  必须设置电机的实际极对数，底层代码采用浮点数运算，估算后的极对数经常因为带有浮点数而错误
BLDCDriver3PWM driver = BLDCDriver3PWM(25, 32,33,12);  //;

// angle set point variable
float target_angle = 0;
// instantiate the commander
Commander command = Commander(Serial);
void doTarget(char* cmd) { command.scalar(&target_angle, cmd); }
float CLAMP(const float value, const float low, const float high);
void knob_config(uint8_t mode);
void knob_haptic(float strength);
void smart_knob(void);

// 添加模式切换命令
uint8_t current_mode = 0;
void doMode(char* cmd) { 
    int mode = atoi(cmd);
    if (mode >= 0 && mode <= 10) {
        current_mode = mode;
        knob_config(current_mode);
        Serial.print("切换到模式: ");
        Serial.println(mode);
    } else {
        Serial.println("无效的模式，请输入0-10");
    }
}

void setup() {

//  Wire.setPins(19, 18);  //SDA,SCL,可设置任意引脚
//  Wire.setClock(400000); //400KHz
//  Wire.begin(); 
  
  // initialise magnetic sensor hardware
  sensor.init();
  // link the motor to the sensor
  motor.linkSensor(&sensor);

  // driver config
  // power supply voltage [V]
  driver.voltage_power_supply = 12;
  driver.init();
  // link the motor and the driver
  motor.linkDriver(&driver);
  
  // choose FOC modulation (optional)
  motor.foc_modulation = FOCModulationType::SpaceVectorPWM;

  // set motion control loop to be used
  motor.controller = MotionControlType::torque;   //必须选择力矩模式

  // Not actually using the velocity loop built into SimpleFOC; but I'm using those PID variables            
  // to run PID for torque (and SimpleFOC studio supports updating them easily over serial for tuning)
  motor.PID_velocity.P = 4;   //motor_task.cpp 第68行
  motor.PID_velocity.I = 0;
  motor.PID_velocity.D = 0.04;
  motor.PID_velocity.output_ramp = 10000;
  motor.PID_velocity.limit = 10;
    
  // maximal voltage to be set to the motor
  motor.voltage_limit = 6;          //限制电压
  motor.voltage_sensor_align = 2.5;   //零点校准对齐电压，默认为3，大功率电机设置小比如0.5-1,小功率设置大比如2-3,
  
  // velocity low pass filtering time constant
  // the lower the less filtered
  motor.LPF_velocity.Tf = 0.05;     //Tf太小电机振动

  // angle P controller 
  motor.P_angle.P = 20;
  // maximal velocity of the position control
  motor.velocity_limit = 40;

  // use monitoring with serial 
  Serial.begin(115200);
  // comment out if not needed
  motor.useMonitoring(Serial);
  
  // initialize motor
  motor.init();
  // align sensor and start FOC
  motor.initFOC();           //第一次编译使用这一句，上电后电机先零点校准，获得偏置角和方向，填入括号中，重新编译下载
  //motor.initFOC(2.34, CCW);    //写入参数后，以后上电直接进入闭环，不再零点校准

  // add target command T
  command.add('T', doTarget, (char *)"target angle");
    // 添加模式切换命令 M
  command.add('M', doMode, (char *)"mode");

  Serial.println(F("Motor ready."));
  Serial.println(F("Set the target angle using serial terminal:"));
  Serial.println(F("Set the mode (0-10) using serial terminal with command M:"));
  _delay(1000);
  
  knob_config(0);   //模式0
}

// angle set point variable
//float target_angle = 0;

void loop() {

  // main FOC algorithm function
  // the faster you run this function the better
  // Arduino UNO loop  ~1kHz
  // Bluepill loop ~10kHz 
  motor.loopFOC();

  // Motion control function
  // velocity, position or voltage (defined in motor.controller)
  // this function can be run at much lower frequency than loopFOC() function
  // You can also use motor.move() and set the motor.target in the code
  //motor.move(target_angle);
  smart_knob();


  // function intended to be used with serial plotter to monitor motor variables
  // significantly slowing the execution down!!!!
  // motor.monitor();
  
  // user communication
  command.run();    //串口通信
}

/******************************************************************************/
static const float DEAD_ZONE_DETENT_PERCENT = 0.2;     //死区制动百分率
static const float DEAD_ZONE_RAD = 1 * _PI / 180;      //死区RAD
static const float IDLE_VELOCITY_EWMA_ALPHA = 0.001;   //怠速速度ewma alpha
static const float IDLE_VELOCITY_RAD_PER_SEC = 0.05;   //怠速速度每秒钟弧度
static const uint32_t IDLE_CORRECTION_DELAY_MILLIS = 500;        //怠速修正延迟millis
static const float IDLE_CORRECTION_MAX_ANGLE_RAD = 5 * _PI/180;  //怠速校正最大角度rad
static const float IDLE_CORRECTION_RATE_ALPHA = 0.0005;          //怠速修正率
/******************************************************************************/
//smartknob.pb.h  第21行
typedef struct _PB_SmartKnobConfig {
    int32_t position;
    int32_t min_position;
    int32_t max_position;
    float position_width_radians;
    float detent_strength_unit;
    float endstop_strength_unit;
    float snap_point;
    char text[51];
    uint32_t detent_positions_count;  //pb_size_t
    int32_t detent_positions[5];
    float snap_point_bias;
} PB_SmartKnobConfig;

PB_SmartKnobConfig  config;
/******************************************************************************/
//interface_task.cpp  第28行
static PB_SmartKnobConfig configs[] = {
    // int32_t position;
    // int32_t min_position;
    // int32_t max_position;
    // float position_width_radians;
    // float detent_strength_unit;
    // float endstop_strength_unit;
    // float snap_point;
    // char text[51];
    // pb_size_t detent_positions_count;
    // int32_t detent_positions[5];
    // float snap_point_bias;

    {//0
        0,
        0,
        -1, // max position < min position indicates no bounds
        10 * PI / 180,
        0,
        1,
        1.1,
        "无边界和制动",
        0,
        {},
        0,
    },
    {//1
        0,
        0,
        10,
        10 * PI / 180,
        0,
        1,
        1.1,
        "有边界无制动",
        0,
        {},
        0,
    },
    {//2
        0,
        0,
        72,
        10 * PI / 180,
        0,
        1,
        1.1,
        "多圈无制动",
        0,
        {},
        0,
    },
    {//3
        0,
        0,
        1,
        60 * PI / 180,
        1,
        1,
        0.55, // Note the snap point is slightly past the midpoint (0.5); compare to normal detents which use a snap point *past* the next value (i.e. > 1)
        "开关模式",
        0,
        {},
        0,
    },
    {//4
        0,
        0,
        0,
        60 * PI / 180,
        0.01,
        0.6,
        1.1,
        "自动回中",
        0,
        {},
        0,
    },
    {//5
        127,
        0,
        255,
        1 * PI / 180,
        0,
        1,
        1.1,
        "精细无制动",
        0,
        {},
        0,
    },
    {//6
        127,
        0,
        255,
        1 * PI / 180,
        1,
        1,
        1.1,
        "精细有制动",
        0,
        {},
        0,
    },
    {//7
        0,
        0,
        31,
        8.225806452 * PI / 180,
        2,
        1,
        1.1,
        "粗略强制动",
        0,
        {},
        0,
    },
    {//8
        0,
        0,
        31,
        8.225806452 * PI / 180,
        0.2,
        1,
        1.1,
        "粗略弱制动",
        0,
        {},
        0,
    },
    {//9
        0,
        0,
        31,
        7 * PI / 180,
        2.5,
        1,
        0.7,
        "磁性制动",
        4,
        {2, 10, 21, 22},
        0,
    },
    {//10
        0,
        -6,
        6,
        60 * PI / 180,
        1,
        1,
        0.55,
        "回中带制动",
        0,
        {},
        0.4
    },
};
/******************************************************************************/
float current_detent_center = 0;     //当前位置
float idle_check_velocity_ewma = 0;
uint32_t last_idle_start = 0;        //上次空闲开始状态
/******************************************************************************/
float CLAMP(const float value, const float low, const float high)
{
  return value < low ? low : (value > high ? high : value);
}
/******************************************************************************/
//移植来自 motor_task.cpp  
//切换模式后的参数配置
void knob_config(uint8_t mode)
{
  current_detent_center = motor.shaft_angle;
  config = configs[mode];
  Serial.println(config.text);  //串口打印当前的模式
}
/******************************************************************************/
//电机振动，按键时做为反馈  motor_task.cpp  第176行
void knob_haptic(float strength)
{
  motor.move(strength);
  for (uint8_t i = 0; i < 3; i++) {
    motor.loopFOC();
    delay(1);
  }
  motor.move(-strength);
  for (uint8_t i = 0; i < 3; i++) {
    motor.loopFOC();
    delay(1);
  }
  motor.move(0);
  motor.loopFOC();
}
/******************************************************************************/
//motor_task.cpp  第194行
void smart_knob(void)
{
  // If we are not moving and we're close to the center (but not exactly there), slowly adjust the centerpoint to match the current position
  idle_check_velocity_ewma = motor.shaft_velocity * IDLE_VELOCITY_EWMA_ALPHA + idle_check_velocity_ewma * (1 - IDLE_VELOCITY_EWMA_ALPHA);
  if (fabsf(idle_check_velocity_ewma) > IDLE_VELOCITY_RAD_PER_SEC) {
    last_idle_start = 0;
  }
  else {
    if (last_idle_start == 0) {
      last_idle_start = millis();
    }
  }
  if (last_idle_start > 0 && millis() - last_idle_start > IDLE_CORRECTION_DELAY_MILLIS && fabsf(motor.shaft_angle - current_detent_center) < IDLE_CORRECTION_MAX_ANGLE_RAD) {
    current_detent_center = motor.shaft_angle * IDLE_CORRECTION_RATE_ALPHA + current_detent_center * (1 - IDLE_CORRECTION_RATE_ALPHA);
  }
  
  // Check where we are relative to the current nearest detent; update our position if we've moved far enough to snap to another detent
  float angle_to_detent_center = motor.shaft_angle - current_detent_center;
  
  float snap_point_radians = config.position_width_radians * config.snap_point;
  float bias_radians = config.position_width_radians * config.snap_point_bias;
  float snap_point_radians_decrease = snap_point_radians + (config.position <= 0 ? bias_radians : -bias_radians);
  float snap_point_radians_increase = -snap_point_radians + (config.position >= 0 ? -bias_radians : bias_radians); 
  
  int32_t num_positions = config.max_position - config.min_position + 1;
  if (angle_to_detent_center > snap_point_radians_decrease && (num_positions <= 0 || config.position > config.min_position)) {
    current_detent_center += config.position_width_radians;
    angle_to_detent_center -= config.position_width_radians;
    config.position--;
  } else if (angle_to_detent_center < snap_point_radians_increase && (num_positions <= 0 || config.position < config.max_position)) {
    current_detent_center -= config.position_width_radians;
    angle_to_detent_center += config.position_width_radians;
    config.position++;
  }
  
  float dead_zone_adjustment = CLAMP(
    angle_to_detent_center,
    fmaxf(-config.position_width_radians*DEAD_ZONE_DETENT_PERCENT, -DEAD_ZONE_RAD),
    fminf(config.position_width_radians*DEAD_ZONE_DETENT_PERCENT, DEAD_ZONE_RAD));
  
  bool out_of_bounds = num_positions > 0 && ((angle_to_detent_center > 0 && config.position == config.min_position) || (angle_to_detent_center < 0 && config.position == config.max_position));
  motor.PID_velocity.limit = 10; //out_of_bounds ? 10 : 3;
  motor.PID_velocity.P = out_of_bounds ? config.endstop_strength_unit * 4 : config.detent_strength_unit * 4;
  
  // Apply motor torque based on our angle to the nearest detent (detent strength, etc is handled by the PID_velocity parameters)
  if (fabsf(motor.shaft_velocity) > 60) {
    // Don't apply torque if velocity is too high (helps avoid positive feedback loop/runaway)
    motor.move(0);
  } else {
    float input = -angle_to_detent_center + dead_zone_adjustment;
    if (!out_of_bounds && config.detent_positions_count > 0) {
      bool in_detent = false;
      for (uint8_t i = 0; i < config.detent_positions_count; i++) {
        if (config.detent_positions[i] == config.position) {
          in_detent = true;
          break;
        }
      }
      if (!in_detent) {
        input = 0;
      }
    }
    
    float torque = motor.PID_velocity(input);
    motor.move(torque);
  }
  
  delay(1);
}
/******************************************************************************/
