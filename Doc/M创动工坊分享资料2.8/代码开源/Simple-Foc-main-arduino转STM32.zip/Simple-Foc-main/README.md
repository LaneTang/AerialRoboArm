# Simple-Foc
基于arduino版的simpleFoc移植到stm32，具体参考https://docs.simplefoc.com/motion_control


