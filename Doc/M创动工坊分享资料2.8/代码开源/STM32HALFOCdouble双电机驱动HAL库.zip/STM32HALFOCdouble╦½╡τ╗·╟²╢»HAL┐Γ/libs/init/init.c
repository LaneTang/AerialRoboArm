/* Includes -------------------------------------------------------------------*/
#include "init.h"	 
#include "foc_dev.h"
#include "UART_DMA.h"
#include "AD.h"
/* Variables ------------------------------------------------------------------*/
/* Functions ------------------------------------------------------------------*/	 
/**
 * @brief 	初始化
 * @param 	None
 * @retval	None
 * @note	None
 */

void frameInit(void){
	// 启动外设
//	Remote_InitRemote(&huart3);
	Uart_InitUartDMA(&huart1, UartRXBuff, 11);
	Main_Task_Init();
	ADC_InitDMA();
	
}
/**
 * @brief 	初始化RTOS线程
 * @param 	None
 * @retval	None
 * @note	None
 */

void frameRTOSInit(void){
	MotorCtrl_TaskStart();
}

/**
 * @brief 	轮询任务
 * @param 	None
 * @retval	None
 * @note	None
 */
void mainloop(void){
	HAL_Delay(10);
	
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
