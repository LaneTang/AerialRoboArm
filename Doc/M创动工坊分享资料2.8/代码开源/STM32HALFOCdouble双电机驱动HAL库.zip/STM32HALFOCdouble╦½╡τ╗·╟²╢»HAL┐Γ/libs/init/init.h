#ifndef __INIT_CONFIG_H
#define __INIT_CONFIG_H
#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/

#include "tim.h"
#include "as5600_dev.h"
#include "main_task.h"
/* define ----------------------------------------------------------------------*/

/* Typedef --------------------------------------------------------------------*/

/* Variables ------------------------------------------------------------------*/
	 
/* Functions ------------------------------------------------------------------*/	 
void frameInit(void);
void mainloop(void);
void frameRTOSInit(void);
#ifdef __cplusplus
}
#endif
#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
