/**
 * DreamChaser Frame Header File
 * 
 * @File:        slope_lib.h
 * @Brief:       斜坡控制
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#ifndef __SLOPE_ALGO_H
#define __SLOPE_ALGO_H
#ifdef __cplusplus
extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
/* define ----------------------------------------------------------------------*/
	 
/* Typedef --------------------------------------------------------------------*/
typedef struct 
{
    float acc;
    float dec;
    
} Slope_Param_t;
typedef struct
{
float valuenow;
float valuelast;
float timenow;
float timelast;
float k;
}kSlop_para_t;
/* Variables ------------------------------------------------------------------*/
	 
/* Functions ------------------------------------------------------------------*/	 


void Slope_InitSlopeParam(Slope_Param_t* pparam, float acc, float dec);
float Slope_CalcSlopeRef(float rawref, float targetref, Slope_Param_t* pparam);
float kSlop_cal(kSlop_para_t *ksloppara);
void kSlop_cal_k(float ref,kSlop_para_t *ksloppara);

#ifdef __cplusplus
}
#endif

#endif
