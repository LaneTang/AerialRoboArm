/**
 * DreamChaser Frame Header File
 * 
 * @File:        rmmotor.h
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#ifndef __SNAIL_DEV_H
#define __SNAIL_DEV_H
#ifdef __cplusplus
extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "frame_config.h"
#if __IF_ENABLE( __DEV_SNAIL )
#include "pid_lib.h"
#include "pwm_util.h"
	#include <math.h>
/* define ----------------------------------------------------------------------*/

/* Typedef --------------------------------------------------------------------*/

typedef struct 
{
	int counter;
	int counter_last;
	int delta_counter;
	float angle;
	float speed;
	float filtered_speed;
}SnailData;

typedef struct
{
	SnailData Data;
	PID_PIDTypeDef PID;
	PID_PIDParamTypeDef PIDpara;
	PWMHandle_t PWMHandle;
	TIM_HandleTypeDef *EncoderHandle;
	int compare;
	float time_last;
	float time_now;
	float time_delt;
	uint32_t Snail_Config_time;
}MotorSnail_t;


/* Variables ------------------------------------------------------------------*/

/* Functions ------------------------------------------------------------------*/	
void MotorSnailConfig(MotorSnail_t *snail,TIM_HandleTypeDef *PwmTIMHandle,int PWMchannel,TIM_HandleTypeDef *EncoderTIMHandle);
void SetSnailDuty(MotorSnail_t *snail,float duty);
void MotorSnail_SetFdb(MotorSnail_t *snail);
void SetSnailOutput(MotorSnail_t *snail);
void Snail_Start(MotorSnail_t *snail);
void Snail_Stop(MotorSnail_t *snail);
#endif

#endif

#ifdef __cplusplus
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
