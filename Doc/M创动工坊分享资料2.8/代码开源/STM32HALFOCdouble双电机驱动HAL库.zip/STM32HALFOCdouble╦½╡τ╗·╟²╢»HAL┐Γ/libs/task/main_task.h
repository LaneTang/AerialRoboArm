/**
 *
 * @File:        main_task.c
 * @Brief:
 * @Author:      本人不帅
 * @Modified:    2025/4/15
 *
 */
#ifndef __GIMBAL_TASK_H
#define __GIMBAL_TASK_H
#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "tim.h"
//#include "slope_lib.h"
//#include "pid_lib.h"
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
	 
/* Define ----------------------------------------------------------------------*/

/* Typedef --------------------------------------------------------------------*/

/* Variables ------------------------------------------------------------------*/
extern 
uint8_t UartRXBuff[11];
/* Functions ------------------------------------------------------------------*/	 
void MotorCtrl_TaskStart(void);
void Main_Task_Init(void);
#ifdef __cplusplus
}
#endif
#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
