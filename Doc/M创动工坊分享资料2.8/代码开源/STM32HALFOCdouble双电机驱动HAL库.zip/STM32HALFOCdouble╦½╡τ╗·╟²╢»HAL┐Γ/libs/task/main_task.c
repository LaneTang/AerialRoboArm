/**
 *
 * @File:        main_task.c
 * @Brief:
 * @Author:      本人不帅
 * @Modified:    2025/4/15
 *
 */
/* Includes -------------------------------------------------------------------*/
#include "as5600_dev.h"
#include "foc_dev.h"
#include "main_task.h"
#include "UART_DMA.h"
#include "pid_lib.h"
/* Variables ------------------------------------------------------------------*/
//low_pass_t speed_lp;
//PID_t PID_Pitch[2];
uint8_t UartRXBuff[11];
uint8_t TXBuff[] = {31,32};
PID_t PID_Speed;
PID_t PID_Angle;
PID_t PID_Iq;
low_pass_t I_q_lp;
uint8_t is_log;

FOC_t FOC0, FOC1;
/* Functions ------------------------------------------------------------------*/
/**
* @brief        不同模式下云台参数设置
  * @param      无
  * @retval     无
  */
float uq_ref = 0;
float uq_set = 0;
float Iq_ref = 0;
float angle_ref = 0;
float speed_ref = 0;
float I_q_look = 0;
float look_err = 0;
float I_q_raw = 0;
float dec = 1;
void Main_Task_Init() {

    FOC_Closeloop_Init(&FOC0,&htim2, 12,10, 1, 7);
    FOC_PWMPin_Init(&FOC0,&htim2,&htim2,&htim2,TIM_CHANNEL_1,TIM_CHANNEL_2,TIM_CHANNEL_3);

    IIC_encoder_Config(&FOC0.encoder,&hi2c2,0x36,12,0x0C);

    FOC_Closeloop_Init(&FOC1,&htim2, 12,10, 1, 7);
    FOC_PWMPin_Init(&FOC1,&htim2,&htim3,&htim3,TIM_CHANNEL_4,TIM_CHANNEL_1,TIM_CHANNEL_2);
    IIC_encoder_Config(&FOC1.encoder,&hi2c1,0x36,12,0x0C);

    FOC_AlignmentSensor(&FOC0);
    FOC_AlignmentSensor(&FOC1);

}
float k = 3;
void MotorCtrl_Task() {


    PID_ParamInit(&PID_Speed.pid_para, 1, 0, 1, 25, 30);
    PID_ParamInit(&PID_Angle.pid_para, 40, 0, 0, 5, 30);
    PID_ParamInit(&PID_Iq.pid_para, 0, 0, 0, 5, 5);
    low_pass_filter_init(&I_q_lp,0.2, 1);
    is_log = 1;
    for(;;)
    {
        IIC_Encoder_Read(&FOC0.encoder,1);
        IIC_Encoder_Read(&FOC1.encoder,1);
//        I_q_raw = Get_Iq();
//        I_q_look = (6.812 * uq_set - 0.2885*AS5600.speed_filted)*0.3 + I_q_look * 0.7;
//        look_err = I_q_look - I_q_raw;
//        if(AS5600.speed_filted >= 0) {
//            if(AS5600.speed_filted > dec) {
//                speed_ref = AS5600.speed_filted - dec;
//            } else {
//                speed_ref = 0;
//            }
//        } else {
//            if(AS5600.speed_filted < -dec) {
//                speed_ref = AS5600.speed_filted + dec;
//            } else {
//                speed_ref = 0;
//            }
//        }
//        PID_SetFdb(	&PID_Speed.pid, FOC0.encoder.speed_filted);
//        PID_SetRef(	&PID_Speed.pid, speed_ref) ;
//        PID_Calc(&PID_Speed.pid, &PID_Speed.pid_para);
//        Iq_ref = PID_Speed.pid.output;

//        uq_set = PID_Iq.pid.output + 0.1515*Iq_ref + 0.03983 * FOC0.encoder.speed_filted - 0.015195;
        uq_set = (FOC0.encoder.angle_consequent - FOC1.encoder.angle_consequent)*k;
        FOC_SetTorque(&FOC0, -uq_set ,FOC_Get_ElectricalAngle(&FOC0));
        FOC_SetTorque(&FOC1, uq_set ,FOC_Get_ElectricalAngle(&FOC1));

        osDelay(1);
    }
}

/************************ RTOS *******************/
void MotorCtrl_TaskStart(void)
{
    xTaskCreate((TaskFunction_t)MotorCtrl_Task,"",128,NULL,6,NULL);
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
