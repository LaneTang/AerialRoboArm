/**
 * DreamChaser Frame Source File
 * 
 * @File:        filter_lib.c
 * @Brief:       数字滤波器
 * @Author:      Ju	Chaowen
 * @Modified:    2021年3月21日 16点16分
 *
 */
#include "filter_lib.h"	 
#define PI 3.1415926
/**
 * @brief 	一阶低通滤波
 * @param 	filt低通结构体，param低通参数（0-1之间）,period 控制频率
 * @retval	None
 * @note	None
 */

void low_pass_filter_init(low_pass_t *filt,float param, uint16_t period){
	filt->param = param;
	filt->filted_last_val = 0;
	filt->period=period;
}

float low_pass_filter(float val,low_pass_t *filt){
	
    if ((filt->param > 0) && (filt->param <= 1)) 
			{
        filt->filted_val = filt->param * val + (1 - filt->param) * filt->filted_last_val;
        filt->filted_last_val = filt->filted_val;
        if (filt->period > 0)
            filt->cutoff_frq = filt->param / (2 * PI * (float)filt->period * 0.001f);
				
        return filt->filted_val;
			} 
		else
        return val;

}
/**
 * @brief 	滑动均值滤波
 * @param 	None
 * @retval	None
 * @note	None
 */
void ave_slide_filter_init( ave_filter_t * filter,uint8_t length , float * buff){
	filter->buff = buff;
	filter->length = length;
	filter->sum = 0;
}

float ave_slide_filter(float input, ave_filter_t * filter){
	filter->sum = filter->sum - filter->buff[0] + input;
	
	for (int i = 0 ; i< (filter->length - 1);i++){
		filter->buff[i] =  filter->buff[i+1];
	}
	filter->buff[ filter->length - 1] = input;
	
	return (filter->sum) / (filter->length);
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
