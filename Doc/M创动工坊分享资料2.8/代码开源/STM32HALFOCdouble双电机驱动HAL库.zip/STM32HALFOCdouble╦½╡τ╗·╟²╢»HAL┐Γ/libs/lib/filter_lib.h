/**
 * DreamChaser Frame Header File
 * 
 * @File:        filter_lib.h
 * @Brief:       数字滤波器
 * @Author:      Ju	Chaowen
 * @Modified:    2021年3月21日 16点17分
 *
 */
#ifndef __FILTER_LIB_H
#define __FILTER_LIB_H
#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"
#include "math.h"
/* Typedef --------------------------------------------------------------------*/
typedef struct{
	float cutoff_frq;
	float filted_val;
	float filted_last_val;
	float param;
	uint16_t period;
}
low_pass_t;

typedef struct{
	uint8_t length;
	float sum;
	float * buff;
}
ave_filter_t;

/* Functions ------------------------------------------------------------------*/	 
float low_pass_filter(float val,low_pass_t *filt);
void low_pass_filter_init(low_pass_t *filt,float param, uint16_t period);

float ave_slide_filter(float input,ave_filter_t * filter);
void ave_slide_filter_init( ave_filter_t * filter,uint8_t length , float * buff);
#ifdef __cplusplus
}
#endif
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
