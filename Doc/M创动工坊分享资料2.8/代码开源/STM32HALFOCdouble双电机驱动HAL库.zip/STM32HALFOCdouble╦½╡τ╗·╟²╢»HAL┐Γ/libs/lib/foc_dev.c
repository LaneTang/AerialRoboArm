/*
 * @Author: Rick rick@guaik.io
 * @Date: 2023-06-25 14:17:26
 * @LastEditors: 本人不帅
 * @LastEditTime: 2025/4/15
 * @Description:
 */
#include "foc_dev.h"
//#include "pwm_util.h"
#include <math.h>
#include "AD.h"
#define _3PI_2 4.71238898038469f

#define _1_SQRT3 	 0.57735026919f
#define _2_SQRT3   1.15470053838f

// 归一化角度到 [0, 2PI]
float _normalizeAngle(float angle) {
    float a = fmod(angle, 2 * PI);
    return a >= 0 ? a : (a + 2 * PI);
}

void _setPwm(FOC_t *hfoc, float Ua, float Ub, float Uc) {
    Ua = limit(Ua, hfoc->voltage_limit , 0.0f);
    Ub = limit(Ub, hfoc->voltage_limit , 0.0f);
    Uc = limit(Uc, hfoc->voltage_limit , 0.0f);

    float dc_a = limit(Ua / hfoc->voltage_power_supply, 1.0f, 0.0f);
    float dc_b = limit(Ub / hfoc->voltage_power_supply, 1.0f, 0.0f);
    float dc_c = limit(Uc / hfoc->voltage_power_supply, 1.0f, 0.0f);

    
//    __HAL_TIM_SetCompare(hfoc->tim, TIM_CHANNEL_1, dc_a * hfoc->tim->Init.Period);//3360,5000HZ
//    __HAL_TIM_SetCompare(hfoc->tim, TIM_CHANNEL_2, dc_b * hfoc->tim->Init.Period);
//    __HAL_TIM_SetCompare(hfoc->tim, TIM_CHANNEL_3, dc_c * hfoc->tim->Init.Period);
    __HAL_TIM_SetCompare(hfoc->PWMPin.tim1, hfoc->PWMPin.PIN1, dc_a * hfoc->tim->Init.Period);//3360,5000HZ
    __HAL_TIM_SetCompare(hfoc->PWMPin.tim2, hfoc->PWMPin.PIN2, dc_b * hfoc->tim->Init.Period);
    __HAL_TIM_SetCompare(hfoc->PWMPin.tim3, hfoc->PWMPin.PIN3, dc_c * hfoc->tim->Init.Period);
}
/**
 * @description: FOC闭环控制初始化
 * @param {FOC_t} *hfoc foc句柄
 * @param {TIM_HandleTypeDef} *tim PWM定时器句柄
 * @param {float} pwm_period PWM的重装载值
 * @param {float} voltage 电源电压值
 * @param {int} dir 方向
 * @param {int} pp 极对数
 * @return {*}
 */
void FOC_Closeloop_Init(FOC_t *hfoc, TIM_HandleTypeDef *tim,float voltage_supplay,float voltage_limit, int dir, int pp) {
    memset((void *)hfoc, 0, sizeof(FOC_t));
    hfoc->tim = tim;
//    HAL_TIM_Base_Start(tim);
//    HAL_TIM_PWM_Start(tim, TIM_CHANNEL_1);
//    HAL_TIM_PWM_Start(tim, TIM_CHANNEL_2);
//    HAL_TIM_PWM_Start(tim, TIM_CHANNEL_3);
    // 配置电源电压和限压
    hfoc->voltage_power_supply = voltage_supplay;
    if(voltage_limit > voltage_supplay)voltage_limit = voltage_supplay;
    hfoc->voltage_limit = voltage_limit;
    // 配置方向和极对数
    hfoc->dir = dir;
    hfoc->pp = pp;
}
void FOC_PWMPin_Init(FOC_t *hfoc,TIM_HandleTypeDef *tim1,TIM_HandleTypeDef *tim2,TIM_HandleTypeDef *tim3,uint8_t ch1,uint8_t ch2,uint8_t ch3) {

    hfoc->PWMPin.tim1 = tim1;
    hfoc->PWMPin.tim2 = tim2;
    hfoc->PWMPin.tim3 = tim3;

    hfoc->PWMPin.PIN1  = ch1;
    hfoc->PWMPin.PIN2  = ch2;
    hfoc->PWMPin.PIN3  = ch3;

    HAL_TIM_Base_Start(tim1);
    HAL_TIM_PWM_Start(tim1, ch1);
	
    HAL_TIM_Base_Start(tim2);
    HAL_TIM_PWM_Start(tim2, ch2);
	
    HAL_TIM_Base_Start(tim3);
    HAL_TIM_PWM_Start(tim3, ch3);
}

/**
 * @description: 获取闭环控制电角度数据
 * @param {FOC_t} *hfoc foc句柄
 * @return {float} 电角度值
 */
float FOC_Get_ElectricalAngle(FOC_t *hfoc) {
    return _normalizeAngle((float)(hfoc->dir * hfoc->pp) * hfoc->encoder.angle_raw - hfoc->zero_electric_angle);
}
/**
 * @description: 设置力矩
 * @param {FOC_t} *hfoc foc句柄
 * @param {float} Uq 力矩值
 * @param {float} angle_el 电角度
 * @return {*}
 */
void FOC_SetTorque(FOC_t *hfoc, float Uq, float angle_el) {
    Uq = limit(Uq, hfoc->voltage_power_supply / 2.0f,-hfoc->voltage_power_supply / 2.0f);
    float Ud = 0;
    angle_el = _normalizeAngle(angle_el);

    // Park逆变换
    hfoc->u_alpha = -Uq * sin(angle_el) + Ud * cos(angle_el);
    hfoc->u_beta = Uq * cos(angle_el) + Ud * sin(angle_el);

    // Clark逆变换
    hfoc->u_a = hfoc->u_alpha + hfoc->voltage_limit / 2.0f;
    hfoc->u_b = (-hfoc->u_alpha + sqrt(3) * hfoc->u_beta) / 2.0f + hfoc->voltage_limit / 2.0f;
    hfoc->u_c = (-hfoc->u_alpha - sqrt(3) * hfoc->u_beta) / 2.0f + hfoc->voltage_limit / 2.0f;
    _setPwm(hfoc, hfoc->u_a, hfoc->u_b, hfoc->u_c);
}
float Get_Iq(FOC_t *hfoc) {
    float I_alpha=CurrentData.I_a;
    float I_beta = _1_SQRT3 * CurrentData.I_a + _2_SQRT3 * CurrentData.I_b;
    float angle_el = FOC_Get_ElectricalAngle(hfoc);
    float ct = cos(angle_el);
    float st = sin(angle_el);
    float I_q = I_beta * ct - I_alpha * st;
    I_q = -I_q;

    CurrentData.I_q = I_q;

    return I_q;
}
/**
 * @description: 编码器零位较准（需要配置传感器相关函数指针）
 * @param {FOC_t} *hfoc foc句柄
 * @return {*}
 */
float OpenShaftAngle = 0;
float AligCompletShaftAngle = 0;
float alignmentVolt = 3;
int i = 0;
float cali_pp = 0;
void FOC_AlignmentSensor(FOC_t *hfoc) {
    // 较准0位电角度
    FOC_SetTorque(hfoc, alignmentVolt, 0);
    float step = 0.001f;
    HAL_Delay(1500);
    IIC_Encoder_Read(&hfoc->encoder,1);
    HAL_Delay(100);
    IIC_Encoder_Read(&hfoc->encoder,1);
    HAL_Delay(100);
    IIC_Encoder_Read(&hfoc->encoder,1);
    HAL_Delay(100);
    IIC_Encoder_Read(&hfoc->encoder,1);
    HAL_Delay(100);
    OpenShaftAngle = hfoc->encoder.angle_consequent;
    for(i = 0; i<1000; i++) {
        FOC_SetTorque(hfoc, alignmentVolt, i*step*_3PI_2);
        IIC_Encoder_Read(&hfoc->encoder,1);
        HAL_Delay(2);
    }
    FOC_SetTorque(hfoc, alignmentVolt, _3PI_2);
    HAL_Delay(1500);
    IIC_Encoder_Read(&hfoc->encoder,1);
    HAL_Delay(100);
    IIC_Encoder_Read(&hfoc->encoder,1);
    HAL_Delay(100);
    IIC_Encoder_Read(&hfoc->encoder,1);
    HAL_Delay(100);
    IIC_Encoder_Read(&hfoc->encoder,1);
    HAL_Delay(100);
    hfoc->zero_electric_angle = FOC_Get_ElectricalAngle(hfoc);
    FOC_SetTorque(hfoc, 0, _3PI_2);
    ADC_Cal_Offset();
    AligCompletShaftAngle = hfoc->encoder.angle_consequent;
    if(AligCompletShaftAngle > OpenShaftAngle) {
        hfoc->dir = 1;
        cali_pp = _3PI_2/(AligCompletShaftAngle - OpenShaftAngle);
    } else if(AligCompletShaftAngle < OpenShaftAngle) {
        hfoc->dir = -1;
        cali_pp = -_3PI_2/(AligCompletShaftAngle - OpenShaftAngle);
    } else {
        FOC_AlignmentSensor(hfoc);
    }
}
