#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
	
#define __HAL_DMA_SET_COUNTER(__HANDLE__, __COUNTER__) ((__HANDLE__)->Instance->CNDTR = (uint16_t)(__COUNTER__))

#define RXSIZE 11    //接收数据的长度
	
typedef struct
{
	float x;
	float y;
}RemoteData;

extern RemoteData rxdata;
extern uint8_t rxbuff[];
 

void Uart_InitUartDMA(UART_HandleTypeDef* huart, uint8_t rxbuff[], uint32_t size);
void Uart_ReceiveHandler(UART_HandleTypeDef *huart);
#ifdef __cplusplus
}
#endif
/************************ 本人不帅 *****END OF FILE****/
