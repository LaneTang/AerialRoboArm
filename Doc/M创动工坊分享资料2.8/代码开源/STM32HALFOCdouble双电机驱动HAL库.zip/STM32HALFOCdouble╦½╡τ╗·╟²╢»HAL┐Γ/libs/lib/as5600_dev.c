/**
 *
 * @File:        main_task.c
 * @Brief:
 * @Author:      本人不帅
 * @Modified:    2025/4/15
 *
 */
#include "as5600_dev.h"

/* Variables ------------------------------------------------------------------*/
/* Functions ------------------------------------------------------------------*/
/**
  * @brief      编码器初始化
  * @param
  * @retval     NULL
  */
void IIC_encoder_Config(iic_ecoder_t *iic_ecoder,I2C_HandleTypeDef *I2C_Handle,uint8_t chip_address,uint8_t bit_resolution,uint8_t angle_register_addr)
{
    iic_ecoder->hI2C = I2C_Handle;
    iic_ecoder->init.chip_address = chip_address<<1;
    iic_ecoder->init.bit_resolution = bit_resolution;
    iic_ecoder->init.angle_register_addr =angle_register_addr;
};
/**
  * @brief      数据读取
  * @param
  * @retval     NULL
  */
//uint32_t last_read_tick = 0;
void IIC_Encoder_Read(iic_ecoder_t *iic_ecoder,float delt_tick) {
    IIC_Mem_Read_IT(iic_ecoder->hI2C,iic_ecoder->init.chip_address, iic_ecoder->init.angle_register_addr, iic_ecoder->buff,2);

    iic_ecoder->count =  iic_ecoder->buff[0]<<8|iic_ecoder->buff[1];

    iic_ecoder->angle_raw = 	(float)iic_ecoder->count/(1<<iic_ecoder->init.bit_resolution)*PI*2;
    float delt_angle = iic_ecoder->angle_raw - iic_ecoder->angle_raw_last;


    uint32_t tick_now = HAL_GetTick();;
//    float delt_tick = tick_now - last_read_tick;
    if(delt_angle > 3) {
        iic_ecoder->round_count -= 1;
        delt_angle -= PI*2;
    }
    if(delt_angle < -3) {
        iic_ecoder->round_count += 1;
        delt_angle += PI*2;
    }
    iic_ecoder->angle_consequent = iic_ecoder->round_count*PI*2 + iic_ecoder->angle_raw;

    iic_ecoder->speed = delt_angle * 1000 / delt_tick;
		float filtpara = 0.4;
		iic_ecoder->speed_filted = iic_ecoder->speed * filtpara + iic_ecoder->speed_filted * (1-filtpara);
    iic_ecoder->angle_raw_last = iic_ecoder->angle_raw;
//    last_read_tick = tick_now;
}
/************************ COPYRIGHT BIT DreamChaser *****END OF FILE****/
