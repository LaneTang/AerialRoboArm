/**
 *
 * @File:        main_task.c
 * @Brief:
 * @Author:      本人不帅
 * @Modified:    2025/4/15
 *
 */
#ifndef __AD_H
#define __AD_H
#ifdef __cplusplus
extern "C" {
#endif
    /* Includes -------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
    /* define ----------------------------------------------------------------------*/

    /* Typedef --------------------------------------------------------------------*/
    typedef struct {
        float I_a;
        float I_b;
        float U_a;
        float U_b;
        float U_a_offset;
        float U_b_offset;
        float I_q;
    } CurrentData_t;
    /* Variables ------------------------------------------------------------------*/
    extern uint32_t ADC_data[4];
    extern CurrentData_t CurrentData;
    /* Functions ------------------------------------------------------------------*/
    void ADC_InitDMA(void);
    void ADC_Cal_Offset(void);
#endif
#ifdef __cplusplus
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
