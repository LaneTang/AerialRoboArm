/**
 *
 * @File:        main_task.c
 * @Brief:
 * @Author:      本人不帅
 * @Modified:    2025/4/15
 *
 */
#ifndef __AS5600_DEV_H
#define __AS5600_DEV_H
#ifdef __cplusplus
extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "iic_util.h"
#include <math.h> 
#include "mathtools_lib.h"
#include "FreeRTOS.h"
/* define ----------------------------------------------------------------------*/

//const uint16_t Const_I2C_RX_BUFF_LEN  = 10;
/* Typedef --------------------------------------------------------------------*/
typedef struct 
{
	uint8_t chip_address;
  uint8_t bit_resolution;
  uint8_t angle_register_addr;
}iic_ecoder_init_t;
typedef struct 
{
	iic_ecoder_init_t init;
	I2C_HandleTypeDef *hI2C;
//	uint8_t buff[Const_I2C_RX_BUFF_LEN];
	uint8_t buff[10];
	float angle_raw;
	float angle_raw_last;
	float angle_consequent;
	float speed;//rad/s
	float speed_filted;
	uint16_t count;
	int16_t round_count;
}iic_ecoder_t;



/* Variables ------------------------------------------------------------------*/
//extern iic_ecoder_t AS5600;
/* Functions ------------------------------------------------------------------*/	
void IIC_encoder_Config(iic_ecoder_t *AS5600,I2C_HandleTypeDef *I2C_Handle,uint8_t chip_address,uint8_t bit_resolution,uint8_t angle_register_addr);
void IIC_Encoder_Read(iic_ecoder_t *iic_ecoder,float delt_tick);
#endif


#ifdef __cplusplus
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
