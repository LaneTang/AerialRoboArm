/*
 * @Author: Rick rick@guaik.io
 * @Date: 2023-06-25 14:17:20
 * @LastEditors: Rick
 * @LastEditTime: 2023-06-29 19:16:57
 * @Description:
 */
#ifndef __FOC_DEV_H__
#define __FOC_DEV_H__
#include "tim.h" 
#include "as5600_dev.h"
// 获取编码器弧度值的函数指针
typedef void (*FUNC_SENSOR_UPDATE)();
typedef float (*FUNC_SENSOR_GET_ONCE_ANGLE)();
typedef float (*FUNC_SENSOR_GET_ANGLE)();
typedef float (*FUNC_SENSOR_GET_VELOCITY)();

typedef struct {
  TIM_HandleTypeDef *tim1;  // PWM定时器
  TIM_HandleTypeDef *tim2;  // PWM定时器
  TIM_HandleTypeDef *tim3;  // PWM定时器
	uint8_t PIN1;
	uint8_t PIN2;
	uint8_t PIN3;
}PWMPin_t;
typedef struct {
  TIM_HandleTypeDef *tim;  // PWM定时器
	iic_ecoder_t encoder;
	PWMPin_t PWMPin;
  float voltage_power_supply;  // 电源电压
  float voltage_limit;         // 电压限制
  float shaft_angle;           // 轴角度（开环）
  float open_loop_timestamp;   // 开环时间轴
  float zero_electric_angle;   // 零位电角
  float u_alpha;
  float u_beta;
  float u_a, u_b, u_c;
  float dc_a, dc_b, dc_c;

  int dir;  // 方向
  int pp;   // 极对数
}FOC_t;

//extern FOC_t FOC;
void FOC_Closeloop_Init(FOC_t *hfoc, TIM_HandleTypeDef *tim,float voltage_supplay,float voltage_limit, int dir, int pp);
void FOC_PWMPin_Init(FOC_t *hfoc,TIM_HandleTypeDef *tim1,TIM_HandleTypeDef *tim2,TIM_HandleTypeDef *tim3,uint8_t ch1,uint8_t ch2,uint8_t ch3);

void FOC_AlignmentSensor(FOC_t *hfoc);
float FOC_Get_ElectricalAngle(FOC_t *hfoc);
void FOC_SetTorque(FOC_t *hfoc, float Uq, float angle_el);
float Get_Iq(FOC_t *hfoc);
#endif

