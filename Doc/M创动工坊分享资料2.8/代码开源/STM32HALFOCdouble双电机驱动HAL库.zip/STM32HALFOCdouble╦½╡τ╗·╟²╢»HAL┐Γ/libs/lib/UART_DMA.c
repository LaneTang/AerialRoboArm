/* Includes ------------------------------------------------------------------*/
#include "UART_DMA.h"
uint8_t rxbuff[100];//数据接收缓冲区	
RemoteData rxdata;//接收数据的结构体

/* Functions ----------------------------------------------------------*/
/**
  * @brief UartDma初始化
  * @param huart Uart句柄; size 接收数据的长度
  */
void Uart_InitUartDMA(UART_HandleTypeDef* huart, uint8_t rxbuff[], uint32_t size) { 
    /* open uart idle it */
    __HAL_UART_CLEAR_IDLEFLAG(huart);
    __HAL_UART_ENABLE_IT(huart, UART_IT_IDLE);
		
		rxdata.x = 0;
		rxdata.y = 0;

    uint32_t tmp1 = 0;
    tmp1 = huart->RxState;
    if (tmp1 == HAL_UART_STATE_READY) {
        if ((rxbuff == NULL) || (size == 0)) {
            return;
        }
        huart->pRxBuffPtr = rxbuff;
        huart->RxXferSize = size;
        huart->ErrorCode  = HAL_UART_ERROR_NONE;
        /* Enable the DMA Stream */
        HAL_DMA_Start(huart->hdmarx, (uint32_t)&huart->Instance->DR, (uint32_t)rxbuff, size);
        /* 
         * Enable the DMA transfer for the receiver request by setting the DMAR bit
         * in the UART CR3 register 
         */
        SET_BIT(huart->Instance->CR3, USART_CR3_DMAR);
    }
}
/**
  * @brief 解码函数（自定义）这里所写的是一个遥控器两个摇杆的解码
  */
void Decode(RemoteData *rxdata,uint8_t *rxbuff)
{
		if(rxbuff[0] == 0xA5&&rxbuff[10] == 0x5A){
			*((uint8_t*)& rxdata->x) = rxbuff[1];
			*((uint8_t*)& rxdata->x+1) = rxbuff[2];
			*((uint8_t*)& rxdata->x+2) = rxbuff[3];
			*((uint8_t*)& rxdata->x+3) = rxbuff[4];
			
			*((uint8_t*)& rxdata->y) = rxbuff[5];
			*((uint8_t*)& rxdata->y+1) = rxbuff[6];
			*((uint8_t*)& rxdata->y+2) = rxbuff[7];
			*((uint8_t*)& rxdata->y+3) = rxbuff[8];
			rxdata->x += 0.5f;
			rxdata->y += 0.5f;
		}
}
/**
  * @brief 数据接收回调
  */
void Uart_ReceiveHandler(UART_HandleTypeDef *huart) {
	// clear idle it flag after uart receive a frame data
	if (__HAL_UART_GET_FLAG(huart, UART_FLAG_IDLE) && __HAL_UART_GET_IT_SOURCE(huart, UART_IT_IDLE)) {
		/* clear idle it flag avoid idle interrupt all the time */
		__HAL_UART_CLEAR_IDLEFLAG(huart);
		/* handle received data in idle interrupt */
		__HAL_DMA_DISABLE(huart->hdmarx);
		Decode(&rxdata, rxbuff);
	__HAL_DMA_SET_COUNTER(huart->hdmarx, RXSIZE);
	__HAL_DMA_ENABLE(huart->hdmarx);
	}
}
/***************************本人不帅**END OF FILE*****************************/
