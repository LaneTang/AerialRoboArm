/**
 *
 * @File:        main_task.c
 * @Brief:
 * @Author:      本人不帅
 * @Modified:    2025/4/15
 *
 */
 
/* Includes ------------------------------------------------------------------*/
#include "AD.h"

/* Variables ------------------------------------------------------------------*/
uint32_t ADC_data[4];
CurrentData_t CurrentData;
/**
  * @brief      初始化UART DMA
  * @param      huart: UART句柄
  * @retval     无
  */
void ADC_InitDMA(void) {
    HAL_ADC_Start_DMA(&hadc1,ADC_data,4);
}

void ADC_Cal_Offset(void){
	uint16_t detect_rounds = 1000;
	for(int i = 0; i < detect_rounds; i++)
	{
		CurrentData.U_a_offset += (float)ADC_data[0]/4096 * 3.3f;
		CurrentData.U_b_offset += (float)ADC_data[1]/4096 * 3.3f;
		HAL_Delay(1);
	}
	CurrentData.U_a_offset = CurrentData.U_a_offset / (float)detect_rounds;
	CurrentData.U_b_offset = CurrentData.U_b_offset / (float)detect_rounds;
}
/*DMA转换完成中断回调*/
uint32_t tick_la = 0;
uint32_t de = 0;
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	de = HAL_GetTick() - tick_la;
	CurrentData.U_a = (float)ADC_data[0]/4096 * 3.3f - CurrentData.U_a_offset;
	CurrentData.U_b = (float)ADC_data[1]/4096 * 3.3f - CurrentData.U_b_offset;
	
	float shunt_resistor = 0.01;
	CurrentData.I_a = CurrentData.U_a/shunt_resistor;
	CurrentData.I_b = CurrentData.U_b/shunt_resistor;
		
	tick_la = HAL_GetTick();
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
