/**
 * DreamChaser Frame Source File
 * 
 * @File:        .c
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#include "callback_config.h"	 
/* Functions ------------------------------------------------------------------*/	 
/**
  * @brief      定时器中断回调函数
  * @param      htim: 指针指向定时器句柄
  * @retval     无
  */
//void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef* htim) {
//	if (htim == Const_gimbal_TIMER_HANDLER){
//		Gimbal_TimerCallback();
//	}
//}

/**
  * @brief      UART RX 回调分配函数
  * @param      huart: uart IRQHandler id
  * @retval     无
  */
void Uart_RxIdleCallback(UART_HandleTypeDef* huart) {
	if(huart == Const_Remote_UART_HANDLER){
		Remote_RXCallback(huart);
	}
}

/**
  * @brief      CAN总线数据接收回调函数
  * @param      phcan: 指向CAN句柄的指针
  * @retval     无
  */
CAN_RxHeaderTypeDef Can_rxHeader;
	uint8_t Can_rxData[8];
//CAN_RxHeaderTypeDef Can_Header;
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *phcan) {
	

	/* Get RX message */
	uint32_t ret = HAL_CAN_GetRxMessage(phcan, CAN_RX_FIFO0, &Can_rxHeader, Can_rxData);
	if (ret != HAL_OK) {
		/* Reception Error */
	}
	if(phcan==&hcan1)
	{
	RmdMotor_MotorDataDecode(Can_rxHeader.StdId,Can_rxData);//Motor_EncoderDecodeCallback(phcan, Can_rxHeader.StdId, Can_rxData);
	}
}


void Uart_ReceiveHandler(UART_HandleTypeDef *huart) {
	// clear idle it flag after uart receive a frame data
	if (__HAL_UART_GET_FLAG(huart, UART_FLAG_IDLE) && __HAL_UART_GET_IT_SOURCE(huart, UART_IT_IDLE)) {
		/* clear idle it flag avoid idle interrupt all the time */
		__HAL_UART_CLEAR_IDLEFLAG(huart);
		/* handle received data in idle interrupt */
		Uart_RxIdleCallback(huart);
	}
}
void I2C_RxIdleCallback(I2C_HandleTypeDef *hi2c) {

}
/**
  * @brief      CAN总线数据接收回调函数
  * @param      phcan: 指向CAN句柄的指针
  * @retval     无
  */
void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef *hi2c){
	if (__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_STOPF) && __HAL_I2C_GET_IT_SOURCE(hi2c, I2C_IT_EVT)) {
		/* clear idle it flag avoid idle interrupt all the time */
		__HAL_I2C_CLEAR_STOPFLAG(hi2c);
		/* handle received data in idle interrupt */
		I2C_RxIdleCallback(hi2c);
	}
}

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
