/**
 * DreamChaser Frame Header File
 * 
 * @File:        .h
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#ifndef __CALLBACK_CONFIG_H
#define __CALLBACK_CONFIG_H
#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "frame_config.h"
#include "remote_dev.h"
#include "motor_dev.h"	
#include "modectrl_task.h"
#include "gimbal_task.h"
#include "RMD_dev.h"

/* define ----------------------------------------------------------------------*/
	 
/* Typedef --------------------------------------------------------------------*/

/* Variables ------------------------------------------------------------------*/
	 
/* Functions ------------------------------------------------------------------*/	 
void Uart_ReceiveHandler(UART_HandleTypeDef *huart);
#ifdef __cplusplus
}
#endif

#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
