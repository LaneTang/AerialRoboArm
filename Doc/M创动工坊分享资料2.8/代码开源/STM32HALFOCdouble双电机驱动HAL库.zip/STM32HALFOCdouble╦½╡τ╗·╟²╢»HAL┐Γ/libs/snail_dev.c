/**
 * DreamChaser Frame Source File
 * 
 * @File:        .c
 * @Brief:       
 * @Author:      Peng Huishuai
 * @Modified:    
 *
 */
#include "snail_dev.h"
#if __IF_ENABLE( __DEV_SNAIL )

/* Variables ------------------------------------------------------------------*/
float PulsePerRound = 4096;
/* Functions ------------------------------------------------------------------*/
/**
  * @brief      ԵʼۯSnail֧ܺ
  * @param      
  * @retval     Ϟ
  */
void MotorSnailConfig(MotorSnail_t *snail,TIM_HandleTypeDef *PwmTIMHandle,int PWMchannel,TIM_HandleTypeDef *EncoderTIMHandle)
{
	snail->PWMHandle.htim=PwmTIMHandle;
	snail->PWMHandle.ch=PWMchannel;
	snail->PWMHandle.state=PWM_ON;
	snail->EncoderHandle = EncoderTIMHandle;

	HAL_TIM_PWM_Start(PwmTIMHandle,PWMchannel);
	HAL_TIM_Encoder_Start(EncoderTIMHandle, TIM_CHANNEL_ALL);
	
	SetSnailDuty(snail,0.5f);
	SetSnailOutput(snail);
	snail->Snail_Config_time = HAL_GetTick();
}
/**
  * @brief      ٸsnail֧ܺע̍pwmхۅ
  * @param      snail֧ܺޡٹͥ     
  * @retval     
  */
void SetSnailDuty(MotorSnail_t *snail,float duty)
{
	if(HAL_GetTick() - snail->Snail_Config_time < 10000){
		snail->PWMHandle.duty = 0.5f;
	}
  else{
		snail->PWMHandle.duty = duty;
	}
	
	snail->compare=(uint32_t)(snail->PWMHandle.duty * snail->PWMHandle.htim->Init.Period);	
}

void SetSnailOutput(MotorSnail_t *snail)
{
	 if( HAL_GetTick() - snail->Snail_Config_time < 500 ) return;
	
	 Snail_Start(snail);
		__HAL_TIM_SetCompare(snail->PWMHandle.htim,snail->PWMHandle.ch,snail->compare); 
}

/**
  * @brief      ԦmFeedBack
  * @param      snail֧ܺޡٹͥ     
  * @retval     
  */
void MotorSnail_SetFdb(MotorSnail_t *snail)
{
	snail->time_now = HAL_GetTick();
	snail->Data.counter = __HAL_TIM_GET_COUNTER(snail->EncoderHandle);
	snail->Data.angle = snail->Data.counter / PulsePerRound * 360.0f;
	
	snail->Data.delta_counter = snail->Data.counter - snail->Data.counter_last;
	if(snail->Data.counter - snail->Data.counter_last > 30000){ 
		snail->Data.delta_counter -= 65535;
	}
	else if(snail->Data.counter - snail->Data.counter_last < -30000){ 
		snail->Data.delta_counter += 65535;
	}
	snail->time_delt = snail->time_now - snail->time_last;
    snail->Data.speed = (float)snail->Data.delta_counter / PulsePerRound * 2 * 3.1415926f * 25 / snail->time_delt;
	snail->Data.counter_last = snail->Data.counter ;
	snail->time_last = snail->time_now;
}
/**
 * @brief 	ߪǴPWM
 * @param 	
 * @retval	None
 */
void Snail_Start(MotorSnail_t *snail) {
	if(snail->PWMHandle.state==PWM_OFF)
	HAL_TIM_PWM_Start(snail->PWMHandle.htim,snail->PWMHandle.ch);
	snail->PWMHandle.state=PWM_ON;
}


/**
 * @brief 	ژҕSnail
 * @param 	
 * @retval	None
 */
void Snail_Stop(MotorSnail_t *snail) {
	if(snail->PWMHandle.state==PWM_ON)
	HAL_TIM_PWM_Stop(snail->PWMHandle.htim,snail->PWMHandle.ch);
	snail->PWMHandle.state=PWM_OFF;
}
#endif
 /************************ COPYRIGHT BIT DreamChaser *****END OF FILE****/ 
