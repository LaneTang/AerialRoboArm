#ifndef __MOTOR_CONTROL_H
#define __MOTOR_CONTROL_H

#include "stm32f4xx_hal.h"
#include "stdbool.h"
#include "can_util.h"
#include "can.h"

#define CMD_MOTOR_MODE      0x01
#define CMD_RESET_MODE      0x02
#define CMD_ZERO_POSITION   0x03


#define P_MIN -95.5f    // Radians
#define P_MAX 95.5f        
#define V_MIN -45.0f    // Rad/s
#define V_MAX 45.0f
#define KP_MIN 0.0f     // N-m/rad
#define KP_MAX 500.0f
#define KD_MIN 0.0f     // N-m/rad/s
#define KD_MAX 5.0f
#define T_MIN -18.0f
#define T_MAX 18.0f
#define A_MIN -40.0f  // amp
#define A_MAX 40.0f

/*
	�����������
*/
typedef enum{
	Normal = 0,
	Disconnected = 1,
	OverHeating = 2,
	
}Motor_ErrorEnum;


/*
	�������
*/
typedef enum {
	MOTOR_NONE  = 0,
	MOTOR_WHEEL = 1,
	MOTOR_FRONT  = 2,
	MOTOR_BACK   = 3
}
Motor_Type_e;


/*
	���λ����Ϣ
*/
typedef enum {
	Motor_NONE  = 0,
	MOTOR_LEFT  = 1,
	MOTOR_RIGHT = 2
}
Motor_Direcion_e;


/*
	�������
*/
typedef enum {
	MOTOR_NORMAL  = 1,
	MOTOR_INVERSE = -1
} 
Motor_Polarity_e;


/*
	HT���������Ϣ
*/
typedef struct {
	float     position;
	float     left_position;
	float     right_position;
	float     velocity;
	float     left_velocity;
	float     right_velocity;
	float     current;
	float     left_current;
	float     right_current;
	uint8_t   init_state;					
	uint32_t  last_update_time;
	
}
HTMotor_Feedback_t;	


/*
	RMD���������Ϣ
*/
typedef struct {
	uint8_t control_mode;
	int8_t  temperature ;
	int16_t current;
	int16_t speed;
	int16_t position;				
	uint32_t  last_update_time;
	
	int16_t position_last;
	int32_t position_real;
	int32_t position_init;
	int32_t loop;
}
RMDMotor_Feedback_t;	


/*
	RMD���PID������Ϣ
*/
typedef struct {
	uint8_t anglekp;
	uint8_t angleki;
	uint8_t speedkp;
	uint8_t speedki;
	uint8_t iqkp;
	uint8_t iqki;
}
RMDMotor_PIDParam_t;


/*
	HT���������Ϣ
*/
typedef struct {
	uint8_t 			    ID;
	CAN_HandleTypeDef phcan;
	Motor_Direcion_e  direction;
	Motor_Type_e      motor_type;
	HTMotor_Feedback_t  feedback;
	Motor_Polarity_e motor_polarity;
	// down_pos_limit <= user set pos * direction + zero_pos<= up_pos_limit
	float up_pos_limit;
	float down_pos_limit;
	float zero_pos;
	float position;
	float zeropos_position;
	float pola_position;
	float output_before;
	float output_after;

	float kp;
	float kd;
	
	uint8_t txdata[8];
}
HTMotor_t;	


/*
	RMD���������Ϣ
*/
typedef struct {
	uint16_t 			    ID;	
	CAN_HandleTypeDef phcan;
	Motor_Direcion_e  direction;
	Motor_Type_e      motor_type;
	RMDMotor_Feedback_t  feedback;
	RMDMotor_PIDParam_t  pidparam;
	Motor_Polarity_e motor_polarity;
	float zero_pos;

	int16_t torque_cur;
	
	Motor_ErrorEnum motor_error;
	
	uint8_t txdata[8];
	
	_Bool pos_init_flag;
}
RMDMotor_t;		


void ZeroPosition(void);
HTMotor_t* HtMotorGroup_MotorGetMotorPtr(Motor_Type_e type,Motor_Direcion_e direction);
void HtMotorGroup_MotorDataDecode(uint16_t rxid,uint8_t data[]);
void HtMotorGroup_MotorPackData(HTMotor_t* hmotor,float f_p, float f_v, float f_kp, float f_kd, float f_t);
void HtMotorGroup_MotorInit(void);
void HtMotorGroup_MotorStop(HTMotor_t* hmotor);
void HtMotorGroup_MotorStart(HTMotor_t* hmotor);
void HtMotorGroup_SetControlCmd(HTMotor_t* hmotor,uint8_t cmd);
bool HtMotorGroup_SetPosition(HTMotor_t* hmotor,float position);
bool HtMotorGroup_SetTorque(HTMotor_t* hmotor,uint8_t torque);
bool HtMotorGroup_SetVelocity(HTMotor_t* hmotor,uint8_t velocity);

void HtMotorGroup_CANTx(HTMotor_t* hmotor);

extern HTMotor_t Right_Motor_Front;
extern HTMotor_t Left_Motor_Front;
extern HTMotor_t Right_Motor_Back;
extern HTMotor_t Left_Motor_Back;


#endif

