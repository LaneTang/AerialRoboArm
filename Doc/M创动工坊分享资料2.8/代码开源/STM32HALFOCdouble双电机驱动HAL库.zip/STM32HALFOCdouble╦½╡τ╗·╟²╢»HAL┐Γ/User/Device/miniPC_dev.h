/**
 * DreamChaser Frame Header File
 *
 * @File:        miniPC_dev.h
 * @Brief:
 * @Author:      Zhu Tianyu
 * @Modified:
 *
 */
#ifndef _MINIPC_DEV_H
#define _MINIPC_DEV_H
#ifdef __cplusplus
extern "C" {
#endif

    /* Includes -------------------------------------------------------------------*/
#include "frame_config.h"
#if __IF_ENABLE( __DEV_MINIPC )
#include "main.h"

#include "cmsis_os.h"
#include <math.h>
#include "usbd_cdc_if.h"
#include <string.h>
#include "gimbal_task.h"
    /* Define ----------------------------------------------------------------------*/

    /* Typedef --------------------------------------------------------------------*/
    __packed typedef struct
    {
        float speed;
        float pos;
        float pitch;
        float yaw;
        float volt;
    } State_Data;


//__packed typedef struct
//{
//    PacketHeader header;
//    uint16_t timestamp;
//    uint8_t is_get;
//    int16_t x,y,z;
//    int16_t vx,vz;
//    uint8_t ID;
//}TargetDataPacket_t;

    __packed typedef struct
    {
			uint8_t header;
        float speed_ref;
        float pos_ref;
        float pitch_ref;
        float yaw_ref;
    } DataFromPC_t;

    __packed typedef struct
    {
        uint8_t header;
        State_Data state_data;
    } SendStatusPacket_t;

//extern DataFromPC_t DataFromPC;
//extern SentrySendStatusPacket_t SentrySendStatusPacket;

    void FreeRTOS_EnableMiniPC(void);
    void MiniPCDataReceive(uint8_t* buff,uint16_t len);
#endif

#endif
#ifdef __cplusplus
}
#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
