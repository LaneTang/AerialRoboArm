/**
 * DreamChaser Frame Source File
 * 
 * @File:        .c
 * @Brief:       
 * @Author:      Peng Huishuai
 * @Modified:    
 *
 */
#include "echo_dev.h"
/* Variables ------------------------------------------------------------------*/
Echo_t Echo_A,Echo_B;
/* Functions ------------------------------------------------------------------*/
/**
  * @brief      Init 
  * @param      
  * @retval     NULL
  */
void Echo_Init(Echo_t *echo, GPIO_TypeDef* GPIOx_tri,	uint16_t GPIO_Pin_tri, TIM_HandleTypeDef *TIMHandle_echo,int channel_echo){
	echo->GPIOx = GPIOx_tri;
	echo->GPIO_Pin = GPIO_Pin_tri;
	echo->TIMHandle = TIMHandle_echo;
	echo->channel = channel_echo;
	
	HAL_TIM_IC_Start_IT(TIMHandle_echo,channel_echo);   //开启TIM3的捕获通道1，并且开启捕获中断
  __HAL_TIM_ENABLE_IT(TIMHandle_echo,TIM_IT_UPDATE);   //使能更新中断
	
	echo->is_need_triger = 1;
	echo->is_have_rising_triger = 0;
	echo->is_have_rising_edge = 0;
	echo->fly_time_count = 0;
	echo->distance = 0;
}
void Echo_Send_Triger(Echo_t *echo){
	if(__HAL_TIM_GET_COUNTER(echo->TIMHandle) - echo->triger_start_count > 10000)
		echo->is_need_triger = 1;
	if(echo->is_need_triger){
		if(echo->is_have_rising_triger ==0){
			HAL_GPIO_WritePin(echo->GPIOx, echo->GPIO_Pin, GPIO_PIN_SET);
			echo->triger_start_count = __HAL_TIM_GET_COUNTER(echo->TIMHandle);
			echo->is_have_rising_triger = 1;
		}
		else{
			if(__HAL_TIM_GET_COUNTER(echo->TIMHandle) - echo->triger_start_count > 10){
				HAL_GPIO_WritePin(echo->GPIOx, echo->GPIO_Pin, GPIO_PIN_RESET);
				echo->is_need_triger = 0;
				echo->is_have_rising_triger = 0;
			}
		}
	}
}
void Echo_CaptureCallback(Echo_t *echo){
	if(echo->is_have_rising_edge){
			echo->fly_time_count = HAL_TIM_ReadCapturedValue(echo->TIMHandle,echo->channel);	//获取当前的计数器值
			TIM_RESET_CAPTUREPOLARITY(echo->TIMHandle,echo->channel);	//清除原来的设置		
			TIM_SET_CAPTUREPOLARITY(echo->TIMHandle,echo->channel,TIM_ICPOLARITY_RISING);	//设置上升沿捕获
	  	echo->is_have_rising_edge = 0;
		
			echo->distance = 340 * echo->fly_time_count * 0.001f * 0.1f /2.0f;//cm
			echo->delt_time = HAL_GetTick() - echo->lasttime;
		  echo->fps = 1000/echo->delt_time;
			echo->lasttime = HAL_GetTick();
			if(echo->distance > 100)echo->distance = 9;
			
			echo->is_need_triger = 1;
	}
	else{
			__HAL_TIM_DISABLE(echo->TIMHandle);	//关闭定时器
			__HAL_TIM_SET_COUNTER(echo->TIMHandle,0);	//计数器值清零
			TIM_RESET_CAPTUREPOLARITY(echo->TIMHandle,echo->channel);	//清除原来的设置				
			TIM_SET_CAPTUREPOLARITY(echo->TIMHandle,echo->channel,TIM_ICPOLARITY_FALLING );	//设置下降沿捕获
			__HAL_TIM_ENABLE(echo->TIMHandle);	//使能定时器	
		  echo->is_have_rising_edge = 1;
	}
}
void Echo_Task() { 
	//Chassis_ParaInit();		
	for(;;)
	{
			Echo_Send_Triger(&Echo_A);
			osDelay(1);
			Echo_Send_Triger(&Echo_B);
			osDelay(1);
	}
}
 
/************************ RTOS *******************/
void FreeRTOS_Echo_TaskStart(void)
{
		xTaskCreate((TaskFunction_t)Echo_Task,"",128,NULL,6,NULL);
}
/************************ COPYRIGHT BIT DreamChaser *****END OF FILE****/
