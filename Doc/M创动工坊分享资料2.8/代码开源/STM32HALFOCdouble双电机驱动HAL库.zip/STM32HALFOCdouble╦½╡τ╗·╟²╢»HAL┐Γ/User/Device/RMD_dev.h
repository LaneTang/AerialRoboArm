#ifndef RMD_DEV_H
#define RMD_DEV_H
#ifdef __cplusplus
extern "C" {
#endif

#include "frame_config.h"

//#if __IF_ENABLE( __DEV_RMD )
//#include "stm32f4xx_hal.h"
#include "can_util.h"
#include "mathtools_lib.h"

    /*
    	µ绺λփЅϢ
    */
    typedef enum {
        CW  = 0,
        CCW  = 1
    }
           Motor_Direcion_e;

    /*
    	RMDµ绺½₫ЅϢ
    */
    typedef struct {
        uint8_t control_mode;
        int8_t  temperature ;
        int16_t current;
        int16_t speed;//degree/s
        int16_t position;		//0-16383
        uint32_t  last_update_time;

        int16_t position_last;
        int32_t position_real;
        int32_t position_init;
        int32_t loop;
    } RMDMotor_Feedback_t;
    typedef struct {
        int8_t  temperature ;
        float current;
        float speed;//m/s
        float position;		//m
			float speed_l;//m/s
    } RMDMotor_Data_t;
    /*
    	RMDµ绺PID²ΊýЅϢ
    */
    typedef struct {
        uint8_t anglekp;
        uint8_t angleki;
        uint8_t speedkp;
        uint8_t speedki;
        uint8_t currentkp;
        uint8_t currentki;
    } RMDMotor_PIDParam_t;

    /*
    	RMDµ绺·¢ˍЅϢ
    */
    typedef struct {
        int32_t Motor_Ref;
        int16_t output;
        uint16_t 			    ID;
        CAN_HandleTypeDef* phcan;
        Motor_Direcion_e  direction;
        RMDMotor_Data_t Data;
        RMDMotor_Feedback_t  feedback;
        RMDMotor_PIDParam_t  pidparam;
        float zero_pos;

        uint8_t txdata[8];
       
        _Bool pos_init_flag;
    } RMDMotor_t;

    extern uint8_t p_current;
    extern uint8_t i_current;//1;

    extern uint8_t p_spd;
    extern uint8_t i_spd;


    extern CAN_RxHeaderTypeDef RxHeader;
    extern RMDMotor_t RMD_Wheel_L;
    extern RMDMotor_t RMD_Wheel_R;
    extern uint8_t TxData[8];
    extern uint8_t GroupTxData[8];

    void RmdMotor_MotorIqControl(RMDMotor_t* hmotor, int16_t iqControl,int16_t output_limit);
    void RmdMotor_MotorSpeedControl(RMDMotor_t* hmotor, int32_t speedControl,int32_t output_limit);
    void RmdMotor_MotorMultiAngleControl(RMDMotor_t* hmotor, int32_t angleControl);
    void RmdMotor_MotorMultiAngleControlLimitation(RMDMotor_t* hmotor, uint16_t maxSpeed, int32_t angleControl);
    void RmdMotor_MotorSingleloopAngleControl(RMDMotor_t* hmotor, uint8_t spinDirection, uint16_t angleControl);
    void RmdMotor_MotorSingleloopAngleControlLimitation(RMDMotor_t* hmotor, uint8_t spinDirection, uint16_t maxSpeed, uint16_t angleControl);
    void RmdMotor_MotorAdditionAngleControl(RMDMotor_t* hmotor, int32_t angleControl);
    void RmdMotor_MotorAdditionAngleControlLimitation(RMDMotor_t* hmotor, uint16_t maxSpeed, int32_t angleControl);

    void RmdMotor_MotorOff(RMDMotor_t* hmotor);
    void RmdMotor_MotorMotorStop(RMDMotor_t* hmotor);
    void RmdMotor_MotorOn(RMDMotor_t* hmotor);
    void RmdMotor_MotorDataDecode(uint16_t rxid,uint8_t data[]);
    void RmdMotor_MotorReadPIDParam(RMDMotor_t* hmotor);
    void RmdMotor_MotorGetState(RMDMotor_t* hmotor);
    void RmdMotor_MotorInit(void);

    void RmdMotor_CanTx(RMDMotor_t* hmotor);
    void RmdMotor_MotorInitialPosGet(RMDMotor_t* hmotor);
    void RmdMotor_Motor_WritePI(RMDMotor_t* hmotor, uint8_t kp_ang,uint8_t ki_ang, uint8_t kp_spd,uint8_t ki_spd, uint8_t kp_iq,uint8_t ki_iq);

    void RmdMotorGroup_TorqueCtrl(uint8_t txdata[],RMDMotor_t* hmotor,int16_t iqControl);
    void RmdMotorGroup_TorqueTX(uint8_t txdata[],RMDMotor_t* hmotor);

    extern uint8_t p_iq;
    extern uint8_t i_iq;
#endif

//#endif
#ifdef __cplusplus
}
#endif
