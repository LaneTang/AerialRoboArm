/**
 * DreamChaser Frame Source File
 * 
 * @File:       BMI088_dev.c
 * @Brief:       
 * @Author:      
 * @Modified:   
 *
 */

#include "BMI088_dev.h"
#if __IF_ENABLE( __DEV_BMI088 )

struct IMU_t IMU;
float imu_yaw_angle;
void AHRS_init(float quat[4]);
void get_angle(float q[4], float *yaw, float *pitch, float *roll);
void IMU_Task( void  *pv);
/**
  * @brief      ʹ��IMU
  * @param    
  */
void EnableIMU(struct IMU_t* IMU)
{
	
	
	IMU->IO.IMU_SPI_ACC.SPI_CS.GPIOx = GPIOA;
	IMU->IO.IMU_SPI_ACC.SPI_CS.GPIO_PIN = GPIO_PIN_4;
	IMU->IO.IMU_SPI_ACC.SPI_IO.spi = &hspi1;
	
	IMU->IO.IMU_SPI_GYRO.SPI_CS.GPIOx = GPIOB;
	IMU->IO.IMU_SPI_GYRO.SPI_CS.GPIO_PIN = GPIO_PIN_0;
	IMU->IO.IMU_SPI_GYRO.SPI_IO.spi = &hspi1;
	
	IMU->IO.INT1_ACCEL_Pin = GPIO_PIN_4;
	IMU->IO.INT1_GYRO_Pin = GPIO_PIN_5;
	
//	IMU->IO.PWM_Temp.htim = &htim1;
//	IMU->IO.PWM_Temp.ch = TIM_CHANNEL_1;
	
	
	
	IMU->IO.IMU_SPI_ACC.ENABLE_DMA = 0;
	InitSPI(&IMU->IO.IMU_SPI_ACC);
	IMU->IO.IMU_SPI_GYRO.ENABLE_DMA =0;
	InitSPI(&IMU->IO.IMU_SPI_GYRO);
	
	ReDir_SPI(&IMU->IO.IMU_SPI_GYRO,&IMU->IO.IMU_SPI_ACC);
	while(BMI088_init())
	{
			HAL_Delay(100);
	}		
	 BMI088_read(IMU->RawData.bmi088_data.gyro, IMU->RawData.bmi088_data.accel, &IMU->RawData.bmi088_data.temp);
	PID_ParamInit(&IMU->IO.pidpara, 1.0, 0.01, 0,1000,1);
	AHRS_init(IMU->RawData.INS_quat);
	//EnablePwm(&IMU->IO.PWM_Temp);//�¿��õģ���һ�㲻���¿�
	//SetPWMduty(&IMU->IO.PWM_Temp,0);
	 osThreadDef(IMUTask, (os_pthread)IMU_Task, osPriorityRealtime, 0, 1024);
  IMU->INS_task_local_handler = osThreadCreate(osThread(IMUTask), IMU);
}
/**
  * @brief      ��Ԫ��
  * @param    
  */
void AHRS_init(float quat[4])
{
	quat[0] = 0.0f;
	quat[1] = 1.0f;
	quat[2] = 0.0f;
	quat[3] = 0.0f;
}
/**
  * @brief      �ر�IMU
  * @param    
  */
void DisableIMU(struct IMU_t* IMU)
{
//	UART_Disable(&IMU->UartIMU);
}
/**
  * @brief      ���ó�ʼ��ƫ��
  * @param    
  */
void SetIMUOffset(struct IMU_t* IMU)
{
	SetYawOffset(IMU,IMU->IMUdata.yawRou);
	//SetPitchOffset(IMUdata.pitch);
	//SetRollOffset(IMUdata.roll);
}
/**
  * @brief      ����ROLLƫֵ
  * @param    
  */
void SetRollOffset(struct IMU_t* IMU,float offset)
{
	IMU->IMUdata.rollOffset = offset;
}
/**
  * @brief      ����YAWƫֵ
  * @param    
  */
void SetYawOffset(struct IMU_t* IMU,float offset)
{
	IMU->IMUdata.yawOffset = offset;
	IMU->IMUdata.yawLoop = 0;
}
/**
  * @brief      ����PITCHƫֵ
  * @param    
  */
void SetPitchOffset(struct IMU_t* IMU,float offset)
{
	IMU->IMUdata.pitchOffset = offset;
}


/**
  * @brief      ��������
  * @param    
  */
void UpdateIMUdata(struct IMU_t* IMU)
{
	IMU->IMUdata.SpeedPitch = IMU->RawData.bmi088_data.gyro[0]*180/3.14159f;
	IMU->IMUdata.SpeedRoll = IMU->RawData.bmi088_data.gyro[1]*180/3.14159f;
	IMU->IMUdata.SpeedYaw = IMU->RawData.bmi088_data.gyro[2]*180/3.14159f;
	
	float tempAngle[3];
	
	get_angle(IMU->RawData.INS_quat, &tempAngle[0],&tempAngle[1] , &tempAngle[2]);
	tempAngle[0] *= 57.29578f;
	tempAngle[1] *= 57.29578f;
	tempAngle[2] *= 57.29578f;
	IMU->IMUdata.yawLast = IMU->IMUdata.yawRou;
	
	IMU->IMUdata.roll =  tempAngle[1];
	if(tempAngle[2]>=0)
	{
	IMU->IMUdata.pitch =-180+ tempAngle[2];
	}
	else
	{
	IMU->IMUdata.pitch =180+ tempAngle[2];
	}
	//IMU->IMUdata.pitch =tempAngle[2];
	IMU->IMUdata.yawRou = tempAngle[0];
	
	if(IMU->IMUdata.yawRou-IMU->IMUdata.yawLast>320)
	{
		IMU->IMUdata.yawLoop--;
	}
	else if(IMU->IMUdata.yawRou-IMU->IMUdata.yawLast<-320)
	{
		IMU->IMUdata.yawLoop++;
	}
	
	IMU->IMUdata.yaw = IMU->IMUdata.yawRou + 360*IMU->IMUdata.yawLoop - IMU->IMUdata.yawOffset;
	IMU->IMUdata.Updatetime =HAL_GetTick();
	imu_yaw_angle = IMU->IMUdata.yaw;
}
/**
  * @brief     ��ȡ����
  * @param    
  */
void GetIMUdata(struct IMU_t* IMU)//IMUУ��&�������
{
	UpdateIMUdata(IMU);
}

void Returnypr(struct IMU_t* IMU,float * data)
{
	data[0] = IMU->IMUdata.yaw;
	data[1] = IMU->IMUdata.pitch;
	data[2] = IMU->IMUdata.roll;
}
void Returnyprs(struct IMU_t* IMU,float * data)
{
	data[0]= IMU->IMUdata.SpeedPitch;
	data[1] = IMU->IMUdata.SpeedRoll;
	data[2] = IMU->IMUdata.SpeedYaw;
}
uint32_t ReturnGYUptime(struct IMU_t* IMU)
{
	return IMU->IMUdata.Updatetime;
}


void AHRS_update(float quat[4], float time, float gyro[3], float accel[3])
{
    MahonyAHRSupdateIMU(quat, gyro[0], gyro[1], gyro[2], accel[0], accel[1], accel[2]);
}


/**
  * @brief      ��ȡ����Ƕ�
  * @param    
  */
void get_angle(float q[4], float *yaw, float *pitch, float *roll)
{
    *yaw = -atan2f(2.0f*(q[0]*q[3]+q[1]*q[2]), 2.0f*(q[0]*q[0]+q[1]*q[1])-1.0f);
    *pitch = asinf(-2.0f*(q[1]*q[3]-q[0]*q[2]));
    *roll = atan2f(2.0f*(q[0]*q[1]+q[2]*q[3]),2.0f*(q[0]*q[0]+q[3]*q[3])-1.0f);
}
/**
  * @brief      �¶ȿ���
  * @param    
  */
static uint8_t temperateGot;
void imu_temp_control(void* pv,float temp)
{
		struct IMU_t* IMU  =pv;
    uint16_t tempPWM;
    static uint8_t temp_constant_time = 0;
    if (temperateGot)
    {
				IMU->IO.pid.output = 45.0f;
				PID_Calc(&IMU->IO.pid,&IMU->IO.pidpara);
        if (IMU->IO.pid.output < 0.0f)
        {
            IMU->IO.pid.output = 0.0f;
        }
        tempPWM = IMU->IO.pid.output;
				PWM_SetPWMDuty(&IMU->IO.PWM_Temp,tempPWM);
				
    }
    else
    {
        //��û�дﵽ���õ��¶ȣ�һֱ����ʼ���
        //in beginning, max power
        if (temp > 45.0f)
        {
            temp_constant_time++;
            if (temp_constant_time > 200)
            {
                //�ﵽ�����¶ȣ�������������Ϊһ������ʣ���������
                temperateGot = 1;
                IMU->IO.pid.sum = MPU6500_TEMP_PWM_MAX / 2.0f;
            }
        }

        PWM_SetPWMDuty(&IMU->IO.PWM_Temp,MPU6500_TEMP_PWM_MAX - 1);
    }
}
/**
  * @brief      ������
  * @param    
  */
void IMU_Task( void  *pv)
{
	struct IMU_t * IMU  =pv;
	osDelay(1000);
	/*TODO: ָ��*/
	
	//��ȡ��ǰ�������������
	IMU->IO.IMU_SPI_ACC.ENABLE_DMA = 1;
	Enable_SPI_DMA(&IMU->IO.IMU_SPI_ACC);
	
	IMU->IO.IMU_SPI_GYRO.ENABLE_DMA = 1;
	Enable_SPI_DMA(&IMU->IO.IMU_SPI_GYRO);
	IMU->Flag.imu_start_dma_flag = 1;
  IMU->INS_task_local_handler = xTaskGetHandle(pcTaskGetName(NULL));
	while (1)
	{
			//wait spi DMA tansmit done
			//�ȴ�SPI DMA����
			while (ulTaskNotifyTake(pdTRUE, portMAX_DELAY) != pdPASS)
			{
			}


			if(IMU->Flag.gyro_update_flag & (1 << IMU_UPDATE_SHFITS))
			{
					IMU->Flag.gyro_update_flag &= ~(1 << IMU_UPDATE_SHFITS);
				
					BMI088_gyro_read_over(IMU->RawData.RxBuff.Gyro_buff + BMI088_GYRO_RX_BUF_DATA_OFFSET, IMU->RawData.bmi088_data.gyro);
			}

			if(IMU->Flag.accel_update_flag & (1 << IMU_UPDATE_SHFITS))
			{
						IMU->Flag.accel_update_flag &= ~(1 << IMU_UPDATE_SHFITS);
					
						BMI088_accel_read_over(IMU->RawData.RxBuff.ACCL_Buff+ BMI088_ACCEL_RX_BUF_DATA_OFFSET, IMU->RawData.bmi088_data.accel, &IMU->RawData.bmi088_data.time);
			}

			if(IMU->Flag.accel_temp_update_flag & (1 << IMU_UPDATE_SHFITS))
			{
					IMU->Flag.accel_temp_update_flag &= ~(1 << IMU_UPDATE_SHFITS);
					BMI088_temperature_read_over(IMU->RawData.RxBuff.Temp_Buff + BMI088_ACCEL_RX_BUF_DATA_OFFSET,  &IMU->RawData.bmi088_data.time);
					imu_temp_control(pv, IMU->RawData.bmi088_data.temp);
			}


			AHRS_update(IMU->RawData.INS_quat, 0.001f, IMU->RawData.bmi088_data.gyro, IMU->RawData.bmi088_data.accel);
			GetIMUdata(IMU);
	}
}



uint8_t gyro_dma_tx_buf[SPI_DMA_GYRO_LENGHT] = {0x82,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
uint8_t accel_dma_tx_buf[SPI_DMA_ACCEL_LENGHT] = {0x92,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
uint8_t accel_temp_dma_tx_buf[SPI_DMA_ACCEL_TEMP_LENGHT] = {0xA2,0xFF,0xFF,0xFF};
		
static void imu_cmd_spi_dma(void* pv)
{
	struct IMU_t* IMU  =pv;
        //���������ǵ�DMA����
        if( (IMU->Flag.gyro_update_flag & (1 << IMU_DR_SHFITS) ) && !(IMU->IO.IMU_SPI_GYRO.SPI_IO.spi->hdmatx->Instance->CR & DMA_SxCR_EN) && !(IMU->IO.IMU_SPI_GYRO.SPI_IO.spi->hdmarx->Instance->CR & DMA_SxCR_EN)
        && !(IMU->Flag.accel_update_flag & (1 << IMU_SPI_SHFITS)) && !(IMU->Flag.accel_temp_update_flag & (1 << IMU_SPI_SHFITS)))
        {
            IMU->Flag.gyro_update_flag &= ~(1 << IMU_DR_SHFITS);
            IMU->Flag.gyro_update_flag |= (1 << IMU_SPI_SHFITS);

            //HAL_GPIO_WritePin(CS1_GYRO_GPIO_Port, CS1_GYRO_Pin, GPIO_PIN_RESET);
					Set_SPI_Write_Read(&IMU->IO.IMU_SPI_GYRO,SPI_DMA_GYRO_LENGHT,gyro_dma_tx_buf);
					
           SPI_Read_Write(&IMU->IO.IMU_SPI_GYRO);
            return;
        }
        //�������ٶȼƵ�DMA����
        if((IMU->Flag.accel_update_flag & (1 << IMU_DR_SHFITS)) && !(IMU->IO.IMU_SPI_ACC.SPI_IO.spi->hdmatx->Instance->CR & DMA_SxCR_EN) && !(IMU->IO.IMU_SPI_ACC.SPI_IO.spi->hdmarx->Instance->CR & DMA_SxCR_EN)
        && !(IMU->Flag.gyro_update_flag & (1 << IMU_SPI_SHFITS)) && !(IMU->Flag.accel_temp_update_flag & (1 << IMU_SPI_SHFITS)))
        {
            IMU->Flag.accel_update_flag &= ~(1 << IMU_DR_SHFITS);
            IMU->Flag.accel_update_flag |= (1 << IMU_SPI_SHFITS);
						
            Set_SPI_Write_Read(&IMU->IO.IMU_SPI_ACC,SPI_DMA_ACCEL_LENGHT,accel_dma_tx_buf);
					
           SPI_Read_Write(&IMU->IO.IMU_SPI_ACC);
            return;
        }
        



        if((IMU->Flag.accel_temp_update_flag & (1 << IMU_DR_SHFITS)) && !(IMU->IO.IMU_SPI_ACC.SPI_IO.spi->hdmatx->Instance->CR & DMA_SxCR_EN) && !(IMU->IO.IMU_SPI_ACC.SPI_IO.spi->hdmarx->Instance->CR & DMA_SxCR_EN)
        && !(IMU->Flag.gyro_update_flag & (1 << IMU_SPI_SHFITS)) && !(IMU->Flag.accel_update_flag & (1 << IMU_SPI_SHFITS)))
        {
            IMU->Flag.accel_temp_update_flag &= ~(1 << IMU_DR_SHFITS);
            IMU->Flag.accel_temp_update_flag |= (1 << IMU_SPI_SHFITS);

            
            
						Set_SPI_Write_Read(&IMU->IO.IMU_SPI_ACC,SPI_DMA_ACCEL_TEMP_LENGHT,accel_temp_dma_tx_buf);
					
						SPI_Read_Write(&IMU->IO.IMU_SPI_ACC);
            return;
        }
}

void IMU_EXTI_CallBack(void* pv,uint16_t GPIO_Pin)
{
	struct IMU_t* IMU  =pv;
	if(GPIO_Pin == IMU ->IO.INT1_ACCEL_Pin)
	{
			IMU->Flag.accel_update_flag |= 1 << IMU_DR_SHFITS;
			IMU->Flag.accel_temp_update_flag |= 1 << IMU_DR_SHFITS;
			if(IMU->Flag.imu_start_dma_flag)
			{
				ReDir_SPI(&IMU->IO.IMU_SPI_GYRO,&IMU->IO.IMU_SPI_ACC);
					imu_cmd_spi_dma(pv);
			}
	}
	else if(GPIO_Pin == IMU ->IO.INT1_GYRO_Pin)
	{
			IMU->Flag.gyro_update_flag |= 1 << IMU_DR_SHFITS;
			if(IMU->Flag.imu_start_dma_flag)
			{
				ReDir_SPI(&IMU->IO.IMU_SPI_GYRO,&IMU->IO.IMU_SPI_ACC);
					imu_cmd_spi_dma(pv);
			}
	}
	else if(GPIO_Pin == GPIO_PIN_0)
	{
			//wake up the task
			//��������
			if (xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
			{
					static BaseType_t xHigherPriorityTaskWoken;
					vTaskNotifyGiveFromISR(IMU->INS_task_local_handler, &xHigherPriorityTaskWoken);
					portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
			}
	}
}
void DMA_CallBack(void* pv)
{
	struct IMU_t* IMU  =pv;
	 if(__HAL_DMA_GET_FLAG(IMU->IO.IMU_SPI_ACC.SPI_IO.spi->hdmarx, __HAL_DMA_GET_TC_FLAG_INDEX(IMU->IO.IMU_SPI_ACC.SPI_IO.spi->hdmarx)) != RESET)
    {
        __HAL_DMA_CLEAR_FLAG(IMU->IO.IMU_SPI_ACC.SPI_IO.spi->hdmarx, __HAL_DMA_GET_TC_FLAG_INDEX(IMU->IO.IMU_SPI_ACC.SPI_IO.spi->hdmarx));

        //gyro read over
        //�����Ƕ�ȡ���
        if(IMU->Flag.gyro_update_flag & (1 << IMU_SPI_SHFITS))
        {
            IMU->Flag.gyro_update_flag &= ~(1 << IMU_SPI_SHFITS);
            IMU->Flag.gyro_update_flag |= (1 << IMU_UPDATE_SHFITS);

            SPI_DMACallBack(&IMU->IO.IMU_SPI_GYRO);
						SPI_ReturnData(&IMU->IO.IMU_SPI_GYRO,IMU->RawData.RxBuff.Gyro_buff);
        }

        //accel read over
        //���ٶȼƶ�ȡ���
        if(IMU->Flag.accel_update_flag & (1 << IMU_SPI_SHFITS))
        {
            IMU->Flag.accel_update_flag &= ~(1 << IMU_SPI_SHFITS);
            IMU->Flag.accel_update_flag |= (1 << IMU_UPDATE_SHFITS);

            SPI_DMACallBack(&IMU->IO.IMU_SPI_ACC);
					SPI_ReturnData(&IMU->IO.IMU_SPI_ACC,IMU->RawData.RxBuff.ACCL_Buff);
        }
        //temperature read over
        //�¶ȶ�ȡ���
        if(IMU->Flag.accel_temp_update_flag & (1 << IMU_SPI_SHFITS))
        {
            IMU->Flag.accel_temp_update_flag &= ~(1 << IMU_SPI_SHFITS);
            IMU->Flag.accel_temp_update_flag |= (1 << IMU_UPDATE_SHFITS);

            SPI_DMACallBack(&IMU->IO.IMU_SPI_ACC);
					SPI_ReturnData(&IMU->IO.IMU_SPI_ACC,IMU->RawData.RxBuff.Temp_Buff);
        }

        imu_cmd_spi_dma(pv);

        if(IMU->Flag.gyro_update_flag & (1 << IMU_UPDATE_SHFITS))
        {
            __HAL_GPIO_EXTI_GENERATE_SWIT(GPIO_PIN_0);
        }
    }
}
#endif

