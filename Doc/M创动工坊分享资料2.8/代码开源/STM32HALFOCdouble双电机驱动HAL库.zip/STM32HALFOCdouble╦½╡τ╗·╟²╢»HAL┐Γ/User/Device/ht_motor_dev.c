/**
 * DreamChaser Frame Source File
 * 
 * @File:        ht_motor_dev.c
 * @Brief:       ���İ���HT-03��̩������canͨ���շ����ٶ�/λ��/���ؿ���
 * @Author:      Shi Yangxi
 * @Modified:    20210502
 *
 */

#include "ht_motor_dev.h"
#include "math.h"

volatile uint32_t pre_PCtick = 0;      
volatile uint32_t pre_VCtick = 0;      
volatile uint32_t loop_counter = 0;


HTMotor_t Right_Motor_Front;
HTMotor_t Left_Motor_Front;
HTMotor_t Right_Motor_Back;
HTMotor_t Left_Motor_Back;


#define Right_Motor_Back_ID       0x04
#define Left_Motor_Back_ID        0x02
#define Right_Motor_Front_ID      0x03
#define Left_Motor_Front_ID       0x01


float Motor_Init_Kp = 4;
float Motor_Init_Kd = 0.01;



HTMotor_t* HtMotorGroup_MotorGetMotorPtr(Motor_Type_e type,Motor_Direcion_e direction)
{
	if     (type == MOTOR_BACK  && direction ==MOTOR_RIGHT)  return &Right_Motor_Back;
	else if(type == MOTOR_FRONT && direction ==MOTOR_RIGHT)  return &Right_Motor_Front;
	else if(type == MOTOR_BACK  && direction ==MOTOR_LEFT )  return &Left_Motor_Back;
	else if(type == MOTOR_FRONT && direction ==MOTOR_LEFT )  return &Left_Motor_Front;

	else return 0;
}

//************************math function*************************//

/**
  * @brief  Converts a float to an unsigned int, given range and number of bits
  * @param
  * @retval 
  */
	
#define LIMIT_MIN_MAX(x,min,max) (x) = (((x)<=(min))?(min):(((x)>=(max))?(max):(x)))

static uint16_t float_to_uint(float x, float x_min, float x_max, uint8_t bits)
{
    float span = x_max - x_min;
    float offset = x_min;
    
    return (uint16_t) ((x-offset)*((float)((1<<bits)-1))/span);
}


/**
  * @brief  converts unsigned int to float, given range and number of bits
  * @param
  * @retval 
  */
static float uint_to_float(int x_int, float x_min, float x_max, int bits)
{
    float span = x_max - x_min;
    float offset = x_min;
    return ((float)x_int)*span/((float)((1<<bits)-1)) + offset;
}

//************************math function*************************//


/**
	* @brief  ht电机解码
  * @param
  * @retval 
  */
void HtMotorGroup_MotorDataDecode(uint16_t rxid,uint8_t data[])
{
	
		uint16_t tmp_value;
	
		if     (rxid == Right_Motor_Back_ID )
    {
				if(data[0]== Right_Motor_Back_ID) Right_Motor_Back.feedback.init_state=1;
				tmp_value   =  (data[1]<<8)|(data[2]);
				Right_Motor_Back.feedback.position =  uint_to_float(tmp_value, P_MIN, P_MAX, 16);
			
				tmp_value   =  ((data[4]&0x0F)<<8)|(data[5]);
				Right_Motor_Back.feedback.current  =  uint_to_float(tmp_value, A_MIN, A_MAX,12);
			
        tmp_value   =  (data[3]<<4)|(data[4]>>4);
        Right_Motor_Back.feedback.velocity =  uint_to_float(tmp_value, V_MIN, V_MAX, 12);
			
				Right_Motor_Back.feedback.last_update_time = HAL_GetTick();
    }
		else if(rxid == Left_Motor_Back_ID)
		{
				if(data[0]== Left_Motor_Back_ID) Left_Motor_Back.feedback.init_state=1;
				tmp_value   =  (data[1]<<8)|(data[2]);
				Left_Motor_Back.feedback.position =  uint_to_float(tmp_value, P_MIN, P_MAX, 16);
			
				tmp_value   =  ((data[4]&0x0F)<<8)|(data[5]);
				Left_Motor_Back.feedback.current  =  uint_to_float(tmp_value, A_MIN, A_MAX,12);
			
        tmp_value   =  (data[3]<<4)|(data[4]>>4);
        Left_Motor_Back.feedback.velocity =  uint_to_float(tmp_value, V_MIN, V_MAX, 12);
			
				Left_Motor_Back.feedback.last_update_time = HAL_GetTick();
		}
		else if (rxid == Right_Motor_Front_ID)
		{
				if(data[0]== Right_Motor_Front_ID) Right_Motor_Front.feedback.init_state=1;
				tmp_value   =  (data[1]<<8)|(data[2]);
				Right_Motor_Front.feedback.position =  uint_to_float(tmp_value, P_MIN, P_MAX, 16);
			
				tmp_value   =  ((data[4]&0x0F)<<8)|(data[5]);
				Right_Motor_Front.feedback.current  =  uint_to_float(tmp_value, A_MIN, A_MAX,12);
			
        tmp_value   =  (data[3]<<4)|(data[4]>>4);
        Right_Motor_Front.feedback.velocity =  uint_to_float(tmp_value, V_MIN, V_MAX, 12);

				Right_Motor_Front.feedback.last_update_time = HAL_GetTick();
		}
			
		else if (rxid == Left_Motor_Front_ID)
		{
				if(data[0]== Left_Motor_Front_ID) Left_Motor_Front.feedback.init_state=1;
				tmp_value   =  (data[1]<<8)|(data[2]);
				Left_Motor_Front.feedback.position =  uint_to_float(tmp_value, P_MIN, P_MAX, 16);
			
				tmp_value   =  ((data[4]&0x0F)<<8)|(data[5]);
				Left_Motor_Front.feedback.current  =  uint_to_float(tmp_value, A_MIN, A_MAX,12);
			
        tmp_value   =  (data[3]<<4)|(data[4]>>4);
        Left_Motor_Front.feedback.velocity =  uint_to_float(tmp_value, V_MIN, V_MAX, 12);

				Left_Motor_Front.feedback.last_update_time = HAL_GetTick();
		}

}
	

/**
	* @brief  ht电机打包数据
  * @param
  * @retval 
  */
void HtMotorGroup_MotorPackData(HTMotor_t* hmotor,float f_p, float f_v, float f_kp, float f_kd, float f_t)
{
    uint16_t p, v, kp, kd, t;
    
    LIMIT_MIN_MAX(f_p,  P_MIN,  P_MAX);
    LIMIT_MIN_MAX(f_v,  V_MIN,  V_MAX);
    LIMIT_MIN_MAX(f_kp, KP_MIN, KP_MAX);
    LIMIT_MIN_MAX(f_kd, KD_MIN, KD_MAX);
    LIMIT_MIN_MAX(f_t,  T_MIN,  T_MAX);
    
    p = float_to_uint(f_p,      P_MIN,  P_MAX,  16);            
    v = float_to_uint(f_v,      V_MIN,  V_MAX,  12);
    kp = float_to_uint(f_kp,    KP_MIN, KP_MAX, 12);
    kd = float_to_uint(f_kd,    KD_MIN, KD_MAX, 12);
    t = float_to_uint(f_t,      T_MIN,  T_MAX,  12);
    
    hmotor->txdata[0] = p>>8;
    hmotor->txdata[1] = p&0xFF;
    hmotor->txdata[2] = v>>4;
    hmotor->txdata[3] = ((v&0xF)<<4)|(kp>>8);
    hmotor->txdata[4] = kp&0xFF;
    hmotor->txdata[5] = kd>>4;
    hmotor->txdata[6] = ((kd&0xF)<<4)|(t>>8);
    hmotor->txdata[7] = t&0xff;
}


/**
* @brief  电机控制量设置（不进行tx
  * @retval 
  */
void HtMotorGroup_SetControlCmd(HTMotor_t* hmotor,uint8_t cmd)
{
    uint8_t buf[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00};
    switch(cmd)
    {
        case CMD_MOTOR_MODE:
            buf[7] = 0xFC;
            break;
        
        case CMD_RESET_MODE:
            buf[7] = 0xFD;
        break;
        
        case CMD_ZERO_POSITION:
            buf[7] = 0xFE;
        break;
        
        default:
        return; 
    }
		for(int i=0;i<8;i++){
			hmotor->txdata[i] = buf[i];
		}
}


/**
	* @brief  电机初始位置设置
  * @retval 
  */
void ZeroPosition(void)
{
    HtMotorGroup_SetControlCmd(&Right_Motor_Front,CMD_MOTOR_MODE);
		HtMotorGroup_CANTx(&Right_Motor_Front);
		HAL_Delay(5);
		HtMotorGroup_SetControlCmd(&Left_Motor_Front, CMD_MOTOR_MODE);
		HtMotorGroup_CANTx(&Left_Motor_Front);
		HAL_Delay(5);
    HtMotorGroup_SetControlCmd(&Right_Motor_Back, CMD_MOTOR_MODE);
		HtMotorGroup_CANTx(&Right_Motor_Back);
		HAL_Delay(5);
		HtMotorGroup_SetControlCmd(&Left_Motor_Back,CMD_MOTOR_MODE);
		HtMotorGroup_CANTx(&Left_Motor_Back);
		HAL_Delay(5);

		HtMotorGroup_MotorPackData(&Right_Motor_Front,0,0,0,0,0);
		HtMotorGroup_CANTx(&Right_Motor_Front);
		HAL_Delay(5);
		HtMotorGroup_MotorPackData(&Left_Motor_Front,0,0,0,0,0);
		HtMotorGroup_CANTx(&Left_Motor_Front);
		HAL_Delay(5);
		HtMotorGroup_MotorPackData(&Right_Motor_Back,0,0,0,0,0);
		HtMotorGroup_CANTx(&Right_Motor_Back);
		HAL_Delay(5);
		HtMotorGroup_MotorPackData(&Left_Motor_Back,0,0,0,0,0);
		HtMotorGroup_CANTx(&Left_Motor_Back);
		HAL_Delay(5);
}


/**
	* @brief  电机初始化
  * @retval 
  */
void HtMotorGroup_MotorInit(void)
{

		Left_Motor_Front.ID          =  Left_Motor_Front_ID;
		Left_Motor_Front.direction   =  MOTOR_LEFT;
		Left_Motor_Front.phcan       =  hcan1;
		Left_Motor_Front.motor_type  =  MOTOR_FRONT;
    Left_Motor_Front.kp = Motor_Init_Kp;
		Left_Motor_Front.kd = Motor_Init_Kd;
    Left_Motor_Front.motor_polarity = MOTOR_INVERSE;
    Left_Motor_Front.zero_pos = 1.4878;
    Left_Motor_Front.up_pos_limit = 1.4878;
    Left_Motor_Front.down_pos_limit = 0.0102;
	
		
		Left_Motor_Back.ID         =  Left_Motor_Back_ID;
		Left_Motor_Back.direction  =  MOTOR_LEFT;
		Left_Motor_Back.phcan      =  hcan1;
		Left_Motor_Back.motor_type =  MOTOR_BACK;
    Left_Motor_Back.kp = Motor_Init_Kp;
		Left_Motor_Back.kd = Motor_Init_Kd;
    Left_Motor_Back.motor_polarity = MOTOR_NORMAL;
		Left_Motor_Back.zero_pos = -1.8026;
    Left_Motor_Back.up_pos_limit = -1.8026;
    Left_Motor_Back.down_pos_limit = 0.4794;
		
		Right_Motor_Front.ID           =  Right_Motor_Front_ID;
		Right_Motor_Front.direction    =  MOTOR_RIGHT;
		Right_Motor_Front.phcan        =  hcan1;
		Right_Motor_Front.motor_type   =  MOTOR_FRONT;
    Right_Motor_Front.kp = Motor_Init_Kp;
		Right_Motor_Front.kd = Motor_Init_Kd;
    Right_Motor_Front.motor_polarity = MOTOR_NORMAL;
		Right_Motor_Front.zero_pos = -1.4878;
    Right_Motor_Front.up_pos_limit = -1.4878;
    Right_Motor_Front.down_pos_limit = 0.0014;
	
		Right_Motor_Back.ID          =  Right_Motor_Back_ID;
		Right_Motor_Back.direction   =  MOTOR_RIGHT;
		Right_Motor_Back.phcan       =  hcan1;
		Right_Motor_Back.motor_type  =  MOTOR_BACK;
    Right_Motor_Back.kp = Motor_Init_Kp;
		Right_Motor_Back.kd = Motor_Init_Kd;
    Right_Motor_Back.motor_polarity = MOTOR_INVERSE;
    Right_Motor_Back.zero_pos = 1.8259;
    Right_Motor_Back.up_pos_limit = 1.8259;
    Right_Motor_Back.down_pos_limit = -0.4561;


    ZeroPosition();
    loop_counter = 0;
    pre_PCtick = HAL_GetTick();
    pre_VCtick = HAL_GetTick();
}


/**
	* @brief  电机停止
  * @retval 
  */
void HtMotorGroup_MotorStop(HTMotor_t* hmotor)
{
  HtMotorGroup_SetControlCmd(hmotor,CMD_RESET_MODE);
	
	HtMotorGroup_CANTx(hmotor);
	HAL_Delay(5);
}


/**
	* @brief  电机运行
  * @retval 
  */
void HtMotorGroup_MotorStart(HTMotor_t* hmotor){
	HtMotorGroup_SetControlCmd(hmotor,CMD_MOTOR_MODE);
	
	HtMotorGroup_CANTx(hmotor);
	HAL_Delay(5);
}


/**
	* @brief  电机位置设置
  * @retval 
  */
bool HtMotorGroup_SetPosition(HTMotor_t* hmotor,float position)
	
{
		hmotor->position=  position;
    position = 1.919862177-position;//(110 degree to rad )- position 
		hmotor->zeropos_position=  position;
    position *= hmotor->motor_polarity;
		hmotor->pola_position=  position;
    position += hmotor->zero_pos;
		hmotor->output_before= position;
	
    if(hmotor->motor_polarity == MOTOR_INVERSE) 
			LIMIT_MIN_MAX(position, hmotor->down_pos_limit, hmotor->up_pos_limit);
    else if(hmotor->motor_polarity == MOTOR_NORMAL) 
			LIMIT_MIN_MAX(position, hmotor->up_pos_limit, hmotor->down_pos_limit);    
		hmotor->output_after= position;
		HtMotorGroup_MotorPackData(hmotor, position, 0, hmotor->kp, hmotor->kd, 0);
    return true;
		
}


/**
* @brief  电机转矩设置
  * @retval 
  */
bool HtMotorGroup_SetTorque(HTMotor_t* hmotor,uint8_t torque)
{
    uint32_t tick = HAL_GetTick();  
    
    if((tick - pre_VCtick) >= 10)
    {
        pre_VCtick = tick;
        
        HtMotorGroup_MotorPackData(hmotor, 0, 0, 0, 0, torque);
    }
    return true;
}


/**
	* @brief  电机速度设置
  * @retval 
  */
bool HtMotorGroup_SetVelocity(HTMotor_t* hmotor,uint8_t velocity)
{
    uint32_t tick = HAL_GetTick();  
    
    if((tick - pre_VCtick) >= 10)
    {
        pre_VCtick = tick;
        
        HtMotorGroup_MotorPackData(hmotor, 0, velocity, 0, 1, 0.2);
    }
    return true;
}


/**
	* @brief  电机CAN发送
  * @retval 
  */
void HtMotorGroup_CANTx(HTMotor_t* hmotor){
	CAN_SendMessage(hmotor->phcan,hmotor->ID,sizeof(hmotor->txdata),hmotor->txdata);
}


/**
	* @brief  电机获得初始位置
  * @retval 
  */
void HtMotorGroup_GetInitialPos(void){
	
}

/************************ COPYRIGHT BIT DreamChaser*****END OF FILE*********************/
