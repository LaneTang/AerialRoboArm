/**
 * DreamChaser Frame Header File
 * 
 * @File:        rmmotor.h
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#ifndef __AS5600_DEV_H
#define __AS5600_DEV_H
#ifdef __cplusplus
extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "frame_config.h"
#include "iic_util.h"
#include <math.h>
#include "mathtools_lib.h"	 
/* define ----------------------------------------------------------------------*/

/* Typedef --------------------------------------------------------------------*/
typedef struct 
{
	uint8_t chip_address;
  uint8_t bit_resolution;
  uint8_t angle_register_addr;
}iic_ecoder_init_t;
typedef struct 
{
	iic_ecoder_init_t init;
	float angle_raw;
	float angle_raw_last;
	float angle_consequent;
	uint16_t count;
	int16_t round_count;
}iic_ecoder_t;



/* Variables ------------------------------------------------------------------*/
extern iic_ecoder_t AS5600;
/* Functions ------------------------------------------------------------------*/	
void IIC_encoder_Config(iic_ecoder_t *AS5600,I2C_HandleTypeDef *I2C_Handle,uint8_t chip_address,uint8_t bit_resolution,uint8_t angle_register_addr);
void IIC_Encoder_Read(void);
#endif


#ifdef __cplusplus
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
