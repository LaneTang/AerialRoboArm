/**
 * DreamChaser Frame Source File
 * 
 * @File:        connect_task.c
 * @Brief:       
 * @Author:      WangHaoChen
 * @Modified:    phs
 *
 */
/* Includes -------------------------------------------------------------------*/
#include "RMD_dev.h"
//#if __IF_ENABLE( __DEV_RMD )
float PulseRerRound = 65535.0f;
/* Variables ------------------------------------------------------------------*/
const uint16_t RMD_Std_ID = 0x140;  
const uint8_t RMD_Wheel_ID_L = 0x01;
const uint8_t RMD_Wheel_ID_R = 0x02;

uint8_t p_current_l = 55;
uint8_t i_current_l = 1;

uint8_t p_current_r = 55;
uint8_t i_current_r = 1 ;
        
uint8_t p_spd_l	=	50;
uint8_t i_spd_l	=	1;

uint8_t p_spd_r	=	50;
uint8_t i_spd_r	=	1;

RMDMotor_t RMD_Wheel_L;
RMDMotor_t RMD_Wheel_R; 

uint8_t TxData[8];

uint8_t GroupTxData[8];

const float RadiusOfWheel = 0.0675;//单位m
/* Functions ------------------------------------------------------------------*/
/**
 * @brief 	电机初始化
 * @param 	None
 * @retval	None
 * @note	None
 */
void RmdMotor_MotorInit(){
	RMD_Wheel_L.ID          =  RMD_Std_ID+RMD_Wheel_ID_L;
	RMD_Wheel_L.phcan       =  &hcan1;
	RMD_Wheel_L.direction   =  CW;
	RMD_Wheel_L.Motor_Ref   = 0;
	RMD_Wheel_L.output      = 0;
	RMD_Wheel_L.pos_init_flag = 0;

	
	RMD_Wheel_R.ID         =  RMD_Std_ID+RMD_Wheel_ID_R;
	RMD_Wheel_R.phcan      =  &hcan1;
	RMD_Wheel_R.direction  =  CCW;  
	RMD_Wheel_R.Motor_Ref   = 0;
	RMD_Wheel_L.output      = 0;
	RMD_Wheel_R.pos_init_flag = 0;

	
	RmdMotor_MotorOn(&RMD_Wheel_L);
	RmdMotor_Motor_WritePI(&RMD_Wheel_L,0,0,p_spd_l,i_spd_l,p_current_l,i_current_l);
	RmdMotor_CanTx(&RMD_Wheel_L);
	HAL_Delay(100);
	RmdMotor_MotorReadPIDParam(&RMD_Wheel_L);
	RmdMotor_CanTx(&RMD_Wheel_L);
	HAL_Delay(100);

	RmdMotor_MotorOn(&RMD_Wheel_R);
	RmdMotor_Motor_WritePI(&RMD_Wheel_R,0,0,p_spd_r,i_spd_r,p_current_r,i_current_r);
	RmdMotor_CanTx(&RMD_Wheel_R);
	HAL_Delay(100);
	RmdMotor_MotorReadPIDParam(&RMD_Wheel_R);
	RmdMotor_CanTx(&RMD_Wheel_R);
	HAL_Delay(100);
	for(int i = 0;i<8;i++)TxData[i] = 0;
}

/**
	* @brief  电机PI值写入
  * @param  
  * @param  
  * @retval 
  */
void RmdMotor_Motor_WritePI(RMDMotor_t* hmotor, uint8_t kp_ang,uint8_t ki_ang, uint8_t kp_spd,uint8_t ki_spd, uint8_t kp_current,uint8_t ki_current)
{
  
  hmotor->txdata[0] = 0x31;//0x32 to ROM,0x31 to RAM
  hmotor->txdata[1] = 0x00;
  hmotor->txdata[2] = (uint8_t)kp_ang;
  hmotor->txdata[3] = (uint8_t)ki_ang;
  hmotor->txdata[4] = (uint8_t)kp_spd;
  hmotor->txdata[5] = (uint8_t)ki_spd;
  hmotor->txdata[6] = (uint8_t)kp_current;
  hmotor->txdata[7] = (uint8_t)ki_current;
        
}



/**
  * @brief  Torque Control
  * @param  motor ID ,1-32
  * @param  iq with the value range of -2000~ 2000, corresponding to the actual torque current range of -32A ~32A
  * @retval null
  */
void RmdMotor_MotorIqControl(RMDMotor_t* hmotor, int16_t iqControl,int16_t output_limit)
{
	if((hmotor == &RMD_Wheel_R&&(hmotor->pidparam.currentkp != p_current_r|| hmotor->pidparam.currentki != i_current_r))||
		(hmotor == &RMD_Wheel_L&&(hmotor->pidparam.currentkp != p_current_l|| hmotor->pidparam.currentki != i_current_l))){
			RmdMotor_MotorInit();
		return;
	}
	if(iqControl > output_limit)iqControl = output_limit;
	else if(iqControl < -output_limit)iqControl = -output_limit;
	hmotor->output = iqControl;
  if(hmotor->direction == CW){
		iqControl = -iqControl;
	}
	else if(hmotor->direction == CCW){
		iqControl = iqControl;
	}
	else{
	return;
	}
  hmotor->txdata[0] = 0xA1;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = *(uint8_t *)(&iqControl); 
  hmotor->txdata[5] = *((uint8_t *)(&iqControl)+1);
  hmotor->txdata[6] = 0;
  hmotor->txdata[7] = 0;
        
}


/**
  * @brief  SpeedControl
  * @param  motor ID ,1-32
  * @param  int32_t corresponding to the actual speed of 0.01 DPS /LSB.
  * @retval null
  */
void RmdMotor_MotorSpeedControl(RMDMotor_t* hmotor, int32_t speedControl,int32_t output_limit)
{
	if((hmotor == &RMD_Wheel_R&&(hmotor->pidparam.speedkp != p_spd_r|| hmotor->pidparam.speedki != i_spd_r))||
		(hmotor == &RMD_Wheel_L&&(hmotor->pidparam.speedkp != p_spd_l|| hmotor->pidparam.speedki != i_spd_l))){
			RmdMotor_MotorInit();
		return;
	}
	
  if(speedControl > output_limit)speedControl = output_limit;
	else if(speedControl < -output_limit)speedControl = -output_limit;
	
	hmotor->output = speedControl;
	
  if(hmotor->direction == CW){
		speedControl = -speedControl;
	}
	else if(hmotor->direction == CCW){
		speedControl = speedControl;
	}
	else{
	return;
	}
	
	
  hmotor->txdata[0] = 0xA2;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = *(uint8_t *)(&speedControl); //速度控制低字节
  hmotor->txdata[5] = *((uint8_t *)(&speedControl)+1);
  hmotor->txdata[6] = *((uint8_t *)(&speedControl)+2);
  hmotor->txdata[7] = *((uint8_t *)(&speedControl)+3);//速度控制高字节
        
}

/**
	* @brief  AngleControl(没用，不完善
  * @param  motor ID ,1-32
  * @param  the actual position is 0.01degree/LSB, 36000 represents 360°
  * @retval null
  */
void RmdMotor_MotorMultiAngleControl(RMDMotor_t* hmotor, int32_t angleControl)
{
  
  hmotor->txdata[0] = 0xA3;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = *(uint8_t *)(&angleControl); //位置控制低字芿
  hmotor->txdata[5] = *((uint8_t *)(&angleControl)+1);
  hmotor->txdata[6] = *((uint8_t *)(&angleControl)+2);
  hmotor->txdata[7] = *((uint8_t *)(&angleControl)+3);//位置控制高字芿
        
}


/**
  * @brief  ¶Ȧģʽ
  * @param  motor ID ,1-32
  * @param  the actual position is 0.01degree/LSB, 36000 represents 360°
  * @retval null
  */
void RmdMotor_MotorMultiAngleControlLimitation(RMDMotor_t* hmotor, uint16_t maxSpeed, int32_t angleControl)
{
   
  hmotor->txdata[0] = 0xA4;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = *(uint8_t *)(&maxSpeed);//速度限制低字芿
  hmotor->txdata[3] = *(uint8_t *)((&maxSpeed)+1);//速度限制高字芿
  hmotor->txdata[4] = *(uint8_t *)(&angleControl); //位置控制低字芿
  hmotor->txdata[5] = *((uint8_t *)(&angleControl)+1);
  hmotor->txdata[6] = *((uint8_t *)(&angleControl)+2);
  hmotor->txdata[7] = *((uint8_t *)(&angleControl)+3);//位置控制高字芿
  
}


/**
  * @brief  µ¥Ȧģʽ
  * @param  motor ID ,1-32
  * @param  the actual position is 0.01degree/LSB, 36000 represents 360°
  * @retval null
  */
void RmdMotor_MotorSingleloopAngleControl(RMDMotor_t* hmotor, uint8_t spinDirection, uint16_t angleControl)
{
 
  hmotor->txdata[0] = 0xA5;
  hmotor->txdata[1] = spinDirection;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = *(uint8_t *)(&angleControl); 
  hmotor->txdata[5] = *((uint8_t *)(&angleControl)+1);
  hmotor->txdata[6] = 0;
  hmotor->txdata[7] = 0;
        
}


/**
  * @brief  µ¥Ȧת¶¯Ϟ·ù
  * @param  motor ID ,1-32
  * @param  the actual position is 0.01degree/LSB, 36000 represents 360°
  * @retval null
  */
void RmdMotor_MotorSingleloopAngleControlLimitation(RMDMotor_t* hmotor, uint8_t spinDirection, uint16_t maxSpeed, uint16_t angleControl)
{

  hmotor->txdata[0] = 0xA6;
  hmotor->txdata[1] = spinDirection;
  hmotor->txdata[2] = *(uint8_t *)(&maxSpeed);
  hmotor->txdata[3] = *((uint8_t *)(&maxSpeed)+1);
  hmotor->txdata[4] = *(uint8_t *)(&angleControl); 
  hmotor->txdata[5] = *((uint8_t *)(&angleControl)+1);
  hmotor->txdata[6] = 0;
  hmotor->txdata[7] = 0;
        
}


/**
  * @brief  额外角度控制
  * @param  motor ID ,1-32
  * @param  the actual position is 0.01degree/LSB, 36000 represents 360°
  * @retval null
  */
void RmdMotor_MotorAdditionAngleControl(RMDMotor_t* hmotor, int32_t angleControl)
{
   
  hmotor->txdata[0] = 0xA7;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = *(uint8_t *)(&angleControl); 
  hmotor->txdata[5] = *((uint8_t *)(&angleControl)+1);
  hmotor->txdata[6] = *((uint8_t *)(&angleControl)+2);
  hmotor->txdata[7] = *((uint8_t *)(&angleControl)+3);
        
}


/**
  * @brief  µ绺ɨփ¶½Ƕȍ
  * @param  motor ID ,1-32
  * @param  the actual position is 0.01degree/LSB, 36000 represents 360°
  * @retval null
  */
void RmdMotor_MotorAdditionAngleControlLimitation(RMDMotor_t* hmotor, uint16_t maxSpeed, int32_t angleControl)
{

  hmotor->txdata[0] = 0xA8;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = *(uint8_t *)(&maxSpeed);
  hmotor->txdata[3] = *((uint8_t *)(&maxSpeed)+1);
  hmotor->txdata[4] = *(uint8_t *)(&angleControl); 
  hmotor->txdata[5] = *((uint8_t *)(&angleControl)+1);
  hmotor->txdata[6] = *((uint8_t *)(&angleControl)+2);
  hmotor->txdata[7] = *((uint8_t *)(&angleControl)+3);
        
}


/**
	* @brief  µ绺ʧĜ
  * @param  motor ID ,1-32
  * @retval null
  */
void RmdMotor_MotorOff(RMDMotor_t* hmotor)
{

  hmotor->txdata[0] = 0x80;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[5] = 0;
  hmotor->txdata[6] = 0;
  hmotor->txdata[7] = 0;
        
	RmdMotor_CanTx(hmotor);
	HAL_Delay(100);
}
/**
	* @brief  µ绺ֹͣʤ³ö
  * @param  motor ID ,1-32
  * @retval null
  */
void RmdMotor_MotorMotorStop(RMDMotor_t* hmotor)
{
    
  hmotor->txdata[0] = 0x81;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[5] = 0;
  hmotor->txdata[6] = 0;
  hmotor->txdata[7] = 0;

	RmdMotor_CanTx(hmotor);
	HAL_Delay(100);
}


/**
	* @brief  µ绺ʹĜ
  * @param  motor ID ,1-32
  * @retval null
  */
void RmdMotor_MotorOn(RMDMotor_t* hmotor)
{
    
  hmotor->txdata[0] = 0x88;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[5] = 0;
  hmotor->txdata[6] = 0;
  hmotor->txdata[7] = 0;

	RmdMotor_CanTx(hmotor);
	HAL_Delay(100);
}




/**
  * @brief  µ绺¶ÁPIDɨ¶¨ֵ
  * @param  motor ID ,1-32
  * @retval null
  */
void RmdMotor_MotorReadPIDParam(RMDMotor_t* hmotor)
{
  hmotor->txdata[0] = 0x30;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[5] = 0;
  hmotor->txdata[6] = 0;
  hmotor->txdata[7] = 0;

}
/**
	* @brief  µ绺¶Á±«Ʒ·´À¡
  * @param  motor ID ,1-32
  * @retval null
  */
void RmdMotor_MotorGetState(RMDMotor_t* hmotor)
{

  hmotor->txdata[0] = 0x9C;
  hmotor->txdata[1] = 0;
  hmotor->txdata[2] = 0;
  hmotor->txdata[3] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[4] = 0;
  hmotor->txdata[5] = 0;
  hmotor->txdata[6] = 0;
  hmotor->txdata[7] = 0;
        
}


/**
* @brief  µ¥¸öµ绺CAN·¢ˍ
  * @param  
  * @param  
  * @retval null
  */
void RmdMotor_CanTx(RMDMotor_t* hmotor){
	CAN_TxHeaderTypeDef CAN_TxHeader;
		
	CAN_TxHeader.DLC = 8;//sizeof(hmotor->txdata);	
	CAN_TxHeader.IDE = CAN_ID_STD;
	CAN_TxHeader.RTR = CAN_RTR_DATA;
	CAN_TxHeader.StdId = hmotor->ID;
	
	Can_SendMessage(hmotor->phcan,&CAN_TxHeader,hmotor->txdata); 
}



/**
	* @brief  µ绺½₫
  * @param  motor ID ,1-32
  * @param  the actual position is 0.01degree/LSB, 36000 represents 360°
  * @retval null
  */
void Rmd_Decode(RMDMotor_t *hmotor,uint16_t rxid,uint8_t data[])
{
		if(data[0] ==0x9C||data[0] >= 0xA1)
    {
			  hmotor->feedback.control_mode = data[0];
				hmotor->feedback.temperature = data[1];
				hmotor->feedback.current = (data[3]<<8)|data[2];
			  hmotor->feedback.speed = (data[5]<<8)|data[4];//uint:dps
				hmotor->feedback.position = (data[7]<<8)|data[6];
				hmotor->feedback.last_update_time= HAL_GetTick();
			
				if(hmotor->feedback.position-hmotor->feedback.position_last<-PulseRerRound/2.0f){
					hmotor->feedback.loop+=1;
				}
				else if(hmotor->feedback.position-hmotor->feedback.position_last>PulseRerRound/2.0f){
					hmotor->feedback.loop-=1;
				}
				hmotor->feedback.position_real = hmotor->feedback.position + PulseRerRound*hmotor->feedback.loop;
				hmotor->feedback.position_last = hmotor->feedback.position;
				
				hmotor->Data.temperature = hmotor->feedback.temperature;
				hmotor->Data.speed_l = hmotor->Data.speed;
				if(hmotor->direction == CW){
					
				hmotor->Data.current = -hmotor->feedback.current;
				hmotor->Data.speed = -((float)hmotor->feedback.speed);
				hmotor->Data.position = -((float)(hmotor->feedback.position_real-hmotor->feedback.position_init)/PulseRerRound)*360.0f;
				}
				else if(hmotor->direction == CCW){
				hmotor->Data.current = hmotor->feedback.current;
				hmotor->Data.speed = (float)hmotor->feedback.speed;
				hmotor->Data.position = ((float)(hmotor->feedback.position_real-hmotor->feedback.position_init)/PulseRerRound)*360.0f;
				}
				else{
				hmotor->Data.current =1;
				hmotor->Data.speed = 1;
				hmotor->Data.position = 1;
				}
					
				if(hmotor->pos_init_flag == 0){
					hmotor->feedback.position_init = hmotor->feedback.position_real;
					hmotor->pos_init_flag = 1;
				}
    }
		else if (data[0] ==0x30||data[0] ==0x31||data[0] ==0x32) //read pid param
		{
				hmotor->pidparam.anglekp = data[2];
				hmotor->pidparam.angleki = data[3];
				hmotor->pidparam.speedkp = data[4];
				hmotor->pidparam.speedki = data[5];
				hmotor->pidparam.currentkp = data[6];
				hmotor->pidparam.currentki = data[7];	
		}
}
/**
	* @brief  µ绺½₫
  * @param  motor ID ,1-32
  * @param  the actual position is 0.01degree/LSB, 36000 represents 360°
  * @retval null
  */
uint16_t recidd;
void RmdMotor_MotorDataDecode(uint16_t rxid,uint8_t data[])
{		recidd = rxid;
		if(rxid == RMD_Std_ID+RMD_Wheel_ID_L)
    {
			Rmd_Decode(&RMD_Wheel_L,rxid,data);
		}
		else if(rxid == RMD_Std_ID+RMD_Wheel_ID_R)
    {
			Rmd_Decode(&RMD_Wheel_R,rxid,data);
		}
}
/**
	* @brief  µ绺ש´򰼍
  * @param  
  * @param  
  * @retval 
  */
void RmdMotorGroup_TorqueCtrl(uint8_t txdata[],RMDMotor_t* hmotor,int16_t iqControl){
	switch(hmotor->ID){
		case 0x141:
			txdata[0] = *(uint8_t *)(&iqControl); 
			txdata[1] = *((uint8_t *)(&iqControl)+1);
			break;
		
		case 0x142:
			txdata[2] = *(uint8_t *)(&iqControl); 
			txdata[3] = *((uint8_t *)(&iqControl)+1);
			break;
		
		case 0x143:
			txdata[4] = *(uint8_t *)(&iqControl); 
			txdata[5] = *((uint8_t *)(&iqControl)+1);
			break;
		
		case 0x144:
			txdata[6] = *(uint8_t *)(&iqControl); 
			txdata[7] = *((uint8_t *)(&iqControl)+1);
			break;
	}
}


/**
	* @brief  µ绺ש·¢ˍ
  * @param  motor ID ,1-32,hmotorȡµ绺שĚȎҢֵ¼´¿ɍ
  * @param  the actual position is 0.01degree/LSB, 36000 represents 360°
  * @retval null
  */
void RmdMotorGroup_TorqueTX(uint8_t txdata[],RMDMotor_t* hmotor){
	CAN_TxHeaderTypeDef CAN_TxHeader;
		
	CAN_TxHeader.DLC = sizeof(*txdata);	
	CAN_TxHeader.IDE = CAN_ID_STD;
	CAN_TxHeader.RTR = CAN_RTR_DATA;
	CAN_TxHeader.StdId = 0x280;
	
	Can_SendMessage(hmotor->phcan,&CAN_TxHeader,txdata); 
}





//#endif
