
/**
 * DreamChaser Frame Source File
 * 
 * @File:       tof_dev.c
 * @Brief:      TOF���
 * @Author:     Peng	Huishuai
 * @Modified:   2021��9��27�� 20��50�� 
 *
 */
 //Encoding: Chinese GB2312
 /*
 ���ݣ�TOF_Data_t TOFLeft_Data,TOFRight_Data;	
 
��ʼ����void TOFRight_DevInit(UART_HandleTypeDef* huart)
			 void TOFLeft_DevInit(UART_HandleTypeDef* huart)
				(����init_config.c)
Callback:void TOFRight_RXCallback(UART_HandleTypeDef* huart) 
				 void TOFLeft_RXCallback(UART_HandleTypeDef* huart)
				 (����callback_config.c)
 */
#include "tof_dev.h"
#if __IF_ENABLE( __DEV_TOF )

UART_HandleTypeDef* Const_TOFLeft_UART_HANDLER;
UART_HandleTypeDef* Const_TOFRight_UART_HANDLER ;

const uint16_t Const_TOF_RX_BUFF_LEN = 9;			//TOF���ջ���������
const uint16_t Const_TOF_Distance_INF = 380;

uint8_t TOFLeft_RxData[Const_TOF_RX_BUFF_LEN];
uint8_t TOFRight_RxData[Const_TOF_RX_BUFF_LEN];			//TOF��������

/*****************************************************************TOF����***************************************************/

TOF_Data_t TOFLeft_Data,TOFRight_Data;	

/***************************************************************************************************************************/

//******************** Begin of TOF Init ********************//
/**
  * @brief      ��ȡTOF���ݶ����ָ��
  * @param      ��
  * @retval     TOF���ݶ����ָ��
  */
TOF_Data_t* TOF_GetTOFLeftDataPtr() {
    return &TOFLeft_Data;
}
TOF_Data_t* TOF_GetTOFRightDataPtr() {
    return &TOFRight_Data;
}
/**
  * @brief      ����TOF������
  * @param      TOF_Data  TOF����
  * @retval     
  */
void TOF_ResetTOFData(TOF_Data_t *TOF_Data)
{
		TOF_Data ->Distance=0;
		TOF_Data->last_update_time=0;
		TOF_Data->Strength=0;
		TOF_Data->Temperature=25;

}
/**
  * @brief      ��ʼ��TOF
  * @param      
  * @retval     
  */
void TOFLeft_DevInit(UART_HandleTypeDef* huart) {
	Const_TOFLeft_UART_HANDLER= huart;
	TOF_ResetTOFData(&TOFLeft_Data);
//	HAL_Delay(1000);
  Uart_InitUartDMA(Const_TOFLeft_UART_HANDLER);
  Uart_ReceiveDMA(Const_TOFLeft_UART_HANDLER, TOFLeft_RxData, Const_TOF_RX_BUFF_LEN);
}
void TOFRight_DevInit(UART_HandleTypeDef* huart) {
	Const_TOFRight_UART_HANDLER= huart;
	TOF_ResetTOFData(&TOFRight_Data);
//	HAL_Delay(1000);
  Uart_InitUartDMA(Const_TOFRight_UART_HANDLER);
  Uart_ReceiveDMA(Const_TOFRight_UART_HANDLER, TOFRight_RxData, Const_TOF_RX_BUFF_LEN);
}
/**
  * @brief      У��
  * @param      data  TOF��������
  * @retval     
  */
uint8_t TOFCheck(uint8_t * data)
{
	if(data[0]!=0x59)
	{
		return 0;
	}
	if(data[1]!=0x59)
	{
		return 0;
	}
	uint16_t Checksum  = 0;
	for(uint8_t i =0;i<8;i++)
	{
		Checksum += data[i];
	}
	if((Checksum&0x00ff)!=data[8])
	{
		return 0;
	}
	return 1;
}
/**
  * @brief      ����
  * @param      Tof  ����
  * @retval     
  */
void TOF_Decode(TOF_Data_t* Tof, uint8_t* buff) //put this func in IQHANDER
{
	
	if(TOFCheck(buff))
	{
		Tof->Distance = buff[3]<<8 | buff[2];
		Tof->Strength = buff[5]<<8 | buff[4];
		Tof->Temperature = (buff[7]<<8|buff[6])/8-256;
		Tof->last_update_time = HAL_GetTick();
	}
	
	if(Tof->Strength < 150){
		Tof->Distance = Const_TOF_Distance_INF;
	}
		
}
/**
  * @brief      �ص�
  * @param      
  * @retval     
  */
void TOFLeft_RXCallback(UART_HandleTypeDef* huart) {
	__HAL_DMA_DISABLE(huart->hdmarx);
	TOF_Decode(&TOFLeft_Data, TOFLeft_RxData);
	__HAL_DMA_SET_COUNTER(huart->hdmarx, Const_TOF_RX_BUFF_LEN);
	__HAL_DMA_ENABLE(huart->hdmarx);
}
void TOFRight_RXCallback(UART_HandleTypeDef* huart) {
	__HAL_DMA_DISABLE(huart->hdmarx);
	TOF_Decode(&TOFRight_Data, TOFRight_RxData);
	__HAL_DMA_SET_COUNTER(huart->hdmarx, Const_TOF_RX_BUFF_LEN);
	__HAL_DMA_ENABLE(huart->hdmarx);
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
