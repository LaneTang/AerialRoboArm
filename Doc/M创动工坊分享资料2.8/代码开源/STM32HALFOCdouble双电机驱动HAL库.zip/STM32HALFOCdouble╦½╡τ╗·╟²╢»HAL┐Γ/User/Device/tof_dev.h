

/**
 * DreamChaser Frame Source File
 * 
 * @File:       tof_dev.c
 * @Brief:      TOF���
 * @Author:     Peng	Huishuai
 * @Modified:   2021��9��27�� 20��50�� 
 *
 */

#ifndef TOF_DEV_H
#define TOF_DEV_H
#ifdef __cplusplus
extern "C" {
#endif

#include "frame_config.h"
#if __IF_ENABLE( __DEV_TOF )

#include "stm32f4xx_hal.h"
#include "usart.h"
#include "uart_util.h"
/* Typedef --------------------------------------------------------------------*/	
typedef  struct {
	
	float Distance;
	float Strength;
	int16_t Temperature;
    uint32_t last_update_time;
	
} TOF_Data_t;


//struct tag_TofConfigStruct
//{
//	UART_HandleTypeDef* huart;
//	DMA_HandleTypeDef* hdma;
//};

/* Variables ------------------------------------------------------------------*/
//extern const uint16_t Const_IMU_RX_BUFF_LEN;
extern UART_HandleTypeDef* Const_TOFLeft_UART_HANDLER;
extern UART_HandleTypeDef* Const_TOFRight_UART_HANDLER ;

extern TOF_Data_t TOFLeft_Data,TOFRight_Data;;

/* Functions ------------------------------------------------------------------*/	
// ����ӿ�
TOF_Data_t* TOF_GetTOFDataPtr(void);
void TOFLeft_DevInit(UART_HandleTypeDef* huart);
void TOFRight_DevInit(UART_HandleTypeDef* huart);
void TOFLeft_RXCallback(UART_HandleTypeDef* huart);
void TOFRight_RXCallback(UART_HandleTypeDef* huart);


#endif

#endif
#ifdef __cplusplus
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
