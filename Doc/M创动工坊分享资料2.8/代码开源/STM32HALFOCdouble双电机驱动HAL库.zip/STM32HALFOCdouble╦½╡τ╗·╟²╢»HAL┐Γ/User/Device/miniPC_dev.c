/**
 * DreamChaser Frame Source File
 *
 * @File:       miniPC_dev.c
 * @Brief:
 * @Author:
 * @Modified:
 *
 */
#include "miniPC_dev.h"
#if __IF_ENABLE( __DEV_MINIPC )

DataFromPC_t DataFromPC;
//SentrySendStatusPacket_t SentrySendStatusPacket;
SendStatusPacket_t send_packet;
void DataSend()
{
    int trick = 0;
    for(;;)
    {
        send_packet.header = 0xA5;
        send_packet.state_data.speed = 0.1f;;
        send_packet.state_data.pos = 0;
        send_packet.state_data.pitch = Move_Data.pitch_ref;
        send_packet.state_data.yaw = Motor_Yaw.encoder.consequent_angle;
        send_packet.state_data.volt = 24.0;

        CDC_Transmit_FS((uint8_t *)&send_packet,sizeof(send_packet));

        osDelay(5);
    }
}
/**
  * @brief      接收小电脑数据
  * @param      buff：缓冲空间
  * @param      len：要接收的数据长度
	* @note				put in CDC_Receive_FS(uint8_t* Buf, uint32_t *Len)
  * @retval     无
  */
void MiniPCDataReceive(uint8_t* buff,uint16_t len)
{
    uint8_t DecodeStatus  = 0;
    if( 17 == len)
    {
        static DataFromPC_t DataFromPC_temp;//*******************************************校验********************************
        memcpy(&DataFromPC_temp,buff,len);
        if(0xA5 == DataFromPC_temp.header) {
            memcpy(&DataFromPC,buff,len);
        }
    }

}
/************************ RTOS *******************/
void FreeRTOS_EnableMiniPC()
{
    xTaskCreate((TaskFunction_t)DataSend,"",128,NULL,6,NULL);
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
