/*
 * @Author: Rick rick@guaik.io
 * @Date: 2023-06-25 14:17:26
 * @LastEditors: Rick
 * @LastEditTime: 2023-06-29 20:13:42
 * @Description:
 */
#include "foc_dev.h"
#include "pwm_util.h"
#include <math.h>
#include "mathtools_lib.h"
#include "as5600_dev.h"
#define _3PI_2 4.71238898038469f
FOC_t FOC;
// 归一化角度到 [0, 2PI]
float _normalizeAngle(float angle) {
    float a = fmod(angle, 2 * PI);
    return a >= 0 ? a : (a + 2 * PI);
}

void _setPwm(FOC_t *hfoc, float Ua, float Ub, float Uc) {
    Ua = limit(Ua, hfoc->voltage_limit , 0.0f);
    Ub = limit(Ub, hfoc->voltage_limit , 0.0f);
    Uc = limit(Uc, hfoc->voltage_limit , 0.0f);

    float dc_a = limit(Ua / hfoc->voltage_power_supply, 1.0f, 0.0f);
    float dc_b = limit(Ub / hfoc->voltage_power_supply, 1.0f, 0.0f);
    float dc_c = limit(Uc / hfoc->voltage_power_supply, 1.0f, 0.0f);

    __HAL_TIM_SetCompare(hfoc->tim, TIM_CHANNEL_1, dc_a * hfoc->tim->Init.Period);//3360,5000HZ
    __HAL_TIM_SetCompare(hfoc->tim, TIM_CHANNEL_2, dc_b * hfoc->tim->Init.Period);
    __HAL_TIM_SetCompare(hfoc->tim, TIM_CHANNEL_3, dc_c * hfoc->tim->Init.Period);
}
/**
 * @description: FOC闭环控制初始化
 * @param {FOC_t} *hfoc foc句柄
 * @param {TIM_HandleTypeDef} *tim PWM定时器句柄
 * @param {float} pwm_period PWM的重装载值
 * @param {float} voltage 电源电压值
 * @param {int} dir 方向
 * @param {int} pp 极对数
 * @return {*}
 */
void FOC_Closeloop_Init(FOC_t *hfoc, TIM_HandleTypeDef *tim,float voltage_supplay,float voltage_limit, int dir, int pp) {
    memset((void *)hfoc, 0, sizeof(FOC_t));
    hfoc->tim = tim;
		HAL_TIM_Base_Start(tim);
    HAL_TIM_PWM_Start(tim, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(tim, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(tim, TIM_CHANNEL_3);
    // 配置电源电压和限压
    hfoc->voltage_power_supply = voltage_supplay;
	if(voltage_limit > voltage_supplay)voltage_limit = voltage_supplay;
    hfoc->voltage_limit = voltage_limit;
    // 配置方向和极对数
    hfoc->dir = dir;
    hfoc->pp = pp;
}

/**
 * @description: 获取闭环控制电角度数据
 * @param {FOC_t} *hfoc foc句柄
 * @return {float} 电角度值
 */
float FOC_Get_ElectricalAngle(FOC_t *hfoc) {
    return _normalizeAngle((float)(hfoc->dir * hfoc->pp) * AS5600.angle_raw - hfoc->zero_electric_angle);
}
/**
 * @description: 设置力矩
 * @param {FOC_t} *hfoc foc句柄
 * @param {float} Uq 力矩值
 * @param {float} angle_el 电角度
 * @return {*}
 */
void FOC_SetTorque(FOC_t *hfoc, float Uq, float angle_el) {
    Uq = limit(Uq, hfoc->voltage_power_supply / 2.0f,-hfoc->voltage_power_supply / 2.0f);
    float Ud = 0;
    angle_el = _normalizeAngle(angle_el);

    // Park逆变换
    float Ualpha = -Uq * sin(angle_el) + Ud * cos(angle_el);
    float Ubeta = Uq * cos(angle_el) + Ud * sin(angle_el);

    // Clark逆变换
    float Ua = Ualpha + hfoc->voltage_limit / 2.0f;
    float Ub = (sqrt(3) * Ubeta - Ualpha) / 2.0f + hfoc->voltage_limit / 2.0f;
    float Uc = (-Ualpha - sqrt(3) * Ubeta) / 2.0f + hfoc->voltage_limit / 2.0f;
    _setPwm(hfoc, Ua, Ub, Uc);
}
/**
 * @description: 编码器零位较准（需要配置传感器相关函数指针）
 * @param {FOC_t} *hfoc foc句柄
 * @return {*}
 */
float OpenShaftAngle = 0;
float AligCompletShaftAngle = 0;
float alignmentVolt = 3;
int i = 0;
void FOC_AlignmentSensor(FOC_t *hfoc) {
    // 较准0位电角度
    FOC_SetTorque(hfoc, alignmentVolt, 0);
    float step = 0.001f;
    HAL_Delay(1500);
    IIC_Encoder_Read();
    HAL_Delay(100);
    IIC_Encoder_Read();
    HAL_Delay(100);
    IIC_Encoder_Read();
    HAL_Delay(100);
    IIC_Encoder_Read();
    HAL_Delay(100);
    OpenShaftAngle = AS5600.angle_consequent;
    for(i = 0; i<1000; i++) {
        FOC_SetTorque(hfoc, alignmentVolt, i*step*_3PI_2);
        HAL_Delay(2);
    }
    FOC_SetTorque(hfoc, alignmentVolt, _3PI_2);
    HAL_Delay(1500);
    IIC_Encoder_Read();
    HAL_Delay(100);
    IIC_Encoder_Read();
    HAL_Delay(100);
    IIC_Encoder_Read();
    HAL_Delay(100);
    IIC_Encoder_Read();
    HAL_Delay(100);
    hfoc->zero_electric_angle = FOC_Get_ElectricalAngle(hfoc);
    FOC_SetTorque(hfoc, 0, _3PI_2);
		AligCompletShaftAngle = AS5600.angle_consequent;
    if(AligCompletShaftAngle > OpenShaftAngle) {
        hfoc->dir = 1;
    } else if(AligCompletShaftAngle < OpenShaftAngle) {
        hfoc->dir = -1;
    } else {
        FOC_AlignmentSensor(hfoc);
    }
}
