/**
 * DreamChaser Frame Source File
 *
 * @File:        .c
 * @Brief:
 * @Author:      Peng Huishuai
 * @Modified:
 *
 */
#include "as5600_dev.h"

/* Variables ------------------------------------------------------------------*/
I2C_HandleTypeDef *Const_IIC_HANDLER;
iic_ecoder_t AS5600;
const uint16_t Const_I2C_RX_BUFF_LEN  = 10;
uint8_t IIC_ENCODER_RX_BUFF[Const_I2C_RX_BUFF_LEN];
/* Functions ------------------------------------------------------------------*/
/**
  * @brief      ԵʼۯSnail֧ܺ
  * @param
  * @retval     Ϟ
  */
void IIC_encoder_Config(iic_ecoder_t *iic_ecoder,I2C_HandleTypeDef *I2C_Handle,uint8_t chip_address,uint8_t bit_resolution,uint8_t angle_register_addr)
{
    Const_IIC_HANDLER = I2C_Handle;
    iic_ecoder->init.chip_address = chip_address<<1;
    iic_ecoder->init.bit_resolution = bit_resolution;
    iic_ecoder->init.angle_register_addr =angle_register_addr;
};
/**
  * @brief      ٸsnail֧ܺע̍pwmхۅ
  * @param      snail֧ܺޡٹͥ
  * @retval
  */
void IIC_Encoder_Read(void) {
    IIC_Mem_Read_IT(&hi2c2,AS5600.init.chip_address,AS5600.init.angle_register_addr,IIC_ENCODER_RX_BUFF,2);

    AS5600.count =  IIC_ENCODER_RX_BUFF[0]<<8|IIC_ENCODER_RX_BUFF[1];

    AS5600.angle_raw = 	(float)AS5600.count/(1<<AS5600.init.bit_resolution)*PI*2;
    if(AS5600.angle_raw - AS5600.angle_raw_last > 5) {
        AS5600.round_count -= 1;
    }
    if(AS5600.angle_raw - AS5600.angle_raw_last < -5) {
        AS5600.round_count += 1;
    }
    AS5600.angle_consequent = AS5600.round_count*PI*2 + AS5600.angle_raw;

    AS5600.angle_raw_last = AS5600.angle_raw;
}
/************************ COPYRIGHT BIT DreamChaser *****END OF FILE****/
