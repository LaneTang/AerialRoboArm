/**
 * DreamChaser Frame Header File
 * 
 * @File:        Snail_dev.h
 * @Brief:       
 * @Author:      Peng Huishuai
 * @Modified:    
 *
 */
#ifndef __ECHO_DEV_H
#define __ECHO_DEV_H
#ifdef __cplusplus
extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "frame_config.h"
#include "FreeRTOS.h"
#include "main.h"
#include "cmsis_os.h"
/* define ----------------------------------------------------------------------*/

/* Typedef --------------------------------------------------------------------*/
typedef struct{
	GPIO_TypeDef* GPIOx;
	uint16_t GPIO_Pin;
	TIM_HandleTypeDef *TIMHandle;
	int channel;
	
	uint8_t is_need_triger;
	uint8_t is_have_rising_triger;
	uint8_t is_have_rising_edge;
	uint16_t triger_start_count;
	float fly_time_count;
	float distance;
	float lasttime;
	float delt_time;
	float fps;
}Echo_t;

/* Variables ------------------------------------------------------------------*/
extern Echo_t Echo_A,Echo_B;
/* Functions ------------------------------------------------------------------*/	
void Echo_Init(Echo_t *echo, GPIO_TypeDef* GPIOx_tri,	uint16_t GPIO_Pin_tri, TIM_HandleTypeDef *TIMHandle_echo,int channel_echo);
void Echo_Send_Triger(Echo_t *echo);
void Echo_CaptureCallback(Echo_t *echo);
void FreeRTOS_Echo_TaskStart(void);
#endif
#ifdef __cplusplus
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
