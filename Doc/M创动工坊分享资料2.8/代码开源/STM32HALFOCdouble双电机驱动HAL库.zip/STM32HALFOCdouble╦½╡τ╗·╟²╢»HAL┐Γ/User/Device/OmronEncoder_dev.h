/**
 * DreamChaser Frame Header File
 * 
 * @File:        .h
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#ifndef __OMRONENCODER_DEV_H
#define __OMRONENCODER_DEV_H
#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "frame_config.h"
#if __IF_ENABLE( __DEV_OMRONENCODER )

#include "tim.h"
#include "filter_lib.h"
/* define ----------------------------------------------------------------------*/
	 
/* Typedef --------------------------------------------------------------------*/
typedef struct{
	TIM_HandleTypeDef *EncoderHandle;
	uint16_t counter;
	uint16_t counter_last;
	int32_t delta_counter;
	int32_t consequent_counter;
	int16_t overflow_count;
	float angle;
	float omiga;
	float speed;
	float position;
}OmronEncode_Data_t;
/* Variables ------------------------------------------------------------------*/
void OmronEncoder_Init(OmronEncode_Data_t* pEncoder , TIM_HandleTypeDef *EncoderTIMHandle);
void OmronEncoder_Read(OmronEncode_Data_t* pEncoder);
/* Functions ------------------------------------------------------------------*/	 
extern OmronEncode_Data_t Encoder_Chassis;
#endif
#endif

#ifdef __cplusplus
}
#endif


/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
