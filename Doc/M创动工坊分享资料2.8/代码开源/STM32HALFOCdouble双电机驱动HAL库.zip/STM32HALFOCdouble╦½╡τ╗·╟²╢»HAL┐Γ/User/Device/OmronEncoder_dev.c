/**
 * DreamChaser Frame Source File
 * 
 * @File:        .c
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */

#include "OmronEncoder_dev.h"	 
#if __IF_ENABLE( __DEV_OMRONENCODER )
/* Includes -------------------------------------------------------------------*/


/* Variables ------------------------------------------------------------------*/
const uint16_t PAUSLE_PER_ROUND = 5000;
const float RADIUS = 3.0f;
	
OmronEncode_Data_t Encoder_Chassis;
low_pass_t  Omron_low_filter;

/* Functions ------------------------------------------------------------------*/	 
/**
 * @brief 	欧姆龙编码器初始化
 * @param 	None
 * @retval	None
 * @note	None
 */
void OmronEncoder_Init(OmronEncode_Data_t* pEncoder , TIM_HandleTypeDef *EncoderTIMHandle){
	low_pass_t *lp = &Omron_low_filter;
	
	pEncoder->EncoderHandle = EncoderTIMHandle;
	HAL_TIM_Encoder_Start(pEncoder->EncoderHandle, TIM_CHANNEL_ALL); 
	
	pEncoder->counter = 0;
	pEncoder->counter_last = 0;
	pEncoder->delta_counter = 0;
	pEncoder->overflow_count = 0;
	pEncoder->consequent_counter = 0;
	pEncoder->omiga = 0;
	pEncoder->speed = 0;
	pEncoder->position = 0;
	low_pass_filter_init(lp,0.2,1);
} 

/**
 * @brief 	欧姆龙编码器数据读取
 * @param 	None
 * @retval	None
 * @note	None
 */
void OmronEncoder_Read(OmronEncode_Data_t* pEncoder){
	pEncoder->counter = __HAL_TIM_GET_COUNTER(pEncoder->EncoderHandle);
	pEncoder->delta_counter = - pEncoder->counter + pEncoder->counter_last;
	if(pEncoder->delta_counter < -60000){  
		(pEncoder->overflow_count)++;
		pEncoder->delta_counter += 65535;
	}
	else if(pEncoder->delta_counter > 60000){ 
		(pEncoder->overflow_count)--;
		pEncoder->delta_counter -= 65535;
	}
	pEncoder->consequent_counter += pEncoder->delta_counter;
	pEncoder->angle = (float)pEncoder->consequent_counter / (float)PAUSLE_PER_ROUND * 360.0f;
	pEncoder->omiga = pEncoder->delta_counter / (float)PAUSLE_PER_ROUND * 360.0f * 1000.0f;
	pEncoder->speed = low_pass_filter(pEncoder->omiga / 180 * 3.1415916f * RADIUS,&Omron_low_filter);
	pEncoder->position +=  pEncoder->delta_counter / (float)PAUSLE_PER_ROUND * 2 * 3.1415926f * RADIUS;
	pEncoder->counter_last = pEncoder->counter;
}
#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
