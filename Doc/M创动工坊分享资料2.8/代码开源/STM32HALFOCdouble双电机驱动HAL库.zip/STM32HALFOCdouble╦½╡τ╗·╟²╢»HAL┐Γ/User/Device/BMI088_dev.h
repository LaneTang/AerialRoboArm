/**
 * DreamChaser Frame Header File
 * 
 * @File:		BMI088_dev.h
 * @Brief:    
 * @Author:     
 * @Modified:   
 *
 */
#ifndef BMI088_DEV_H
#define BMI088_DEV_H
#ifdef __cplusplus
extern "C" {
#endif

#include "frame_config.h"
#if __IF_ENABLE( __DEV_BMI088 )

#include <main.h>
#include "MahonyAHRS_lib.h"
#include "math.h"
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"
#include "pid_lib.h"
#include "spi_util.h"
#include "pwm_util.h"
#include "imu_decode_lib.h"

#define SPI_DMA_GYRO_LENGHT       8
#define SPI_DMA_ACCEL_LENGHT      9
#define SPI_DMA_ACCEL_TEMP_LENGHT 4


#define IMU_DR_SHFITS        0
#define IMU_SPI_SHFITS       1
#define IMU_UPDATE_SHFITS        2


#define BMI088_GYRO_RX_BUF_DATA_OFFSET  1
#define BMI088_ACCEL_RX_BUF_DATA_OFFSET 2

//ist83100ԭʼ�����ڻ�����buf��λ��
#define IST8310_RX_BUF_DATA_OFFSET 16


#define MPU6500_TEMP_PWM_MAX 5000 //mpu6500�����¶ȵ�����TIM������ֵ������PWM���Ϊ MPU6500_TEMP_PWM_MAX - 1


#define INS_TASK_INIT_TIME 7 //����ʼ���� delay һ��ʱ��

#define INS_YAW_ADDRESS_OFFSET    0
#define INS_PITCH_ADDRESS_OFFSET  1
#define INS_ROLL_ADDRESS_OFFSET   2

#define INS_GYRO_X_ADDRESS_OFFSET 0
#define INS_GYRO_Y_ADDRESS_OFFSET 1
#define INS_GYRO_Z_ADDRESS_OFFSET 2

#define INS_ACCEL_X_ADDRESS_OFFSET 0
#define INS_ACCEL_Y_ADDRESS_OFFSET 1
#define INS_ACCEL_Z_ADDRESS_OFFSET 2

#define INS_MAG_X_ADDRESS_OFFSET 0
#define INS_MAG_Y_ADDRESS_OFFSET 1
#define INS_MAG_Z_ADDRESS_OFFSET 2

struct tag_IMUdata
{
	float yaw,pitch,roll;
	float SpeedPitch,SpeedRoll,SpeedYaw;
	uint32_t Updatetime;
	float yawOffset,pitchOffset,rollOffset;
	int yawLoop;
	float yawRou;//yaw����ת�ܽǶ�
	float yawLast;
};
struct IMU_t
{
	struct tag_IMUdata IMUdata;
	struct 
	{
		SPI_t IMU_SPI_ACC;
		SPI_t IMU_SPI_GYRO;
		uint32_t INT1_ACCEL_Pin;
		uint32_t INT1_GYRO_Pin;
		
		PID_PIDParamTypeDef pidpara;
		PID_PIDTypeDef pid;
		PWMHandle_t PWM_Temp;
	}IO;
	struct
	{
		bmi088_data_t bmi088_data;
		float INS_quat[4];
		struct 
		{
			uint8_t ACCL_Buff[20];
			uint8_t Temp_Buff[20];
			uint8_t Gyro_buff[20];
		}RxBuff;
	}RawData;
	struct 
	{
		uint8_t imu_start_dma_flag;
		uint8_t gyro_update_flag;
		uint8_t accel_update_flag;
		uint8_t accel_temp_update_flag;
	}Flag;
	
	
	TaskHandle_t INS_task_local_handler;
};
struct tag_IMU_InitConfig
{
	UART_HandleTypeDef* huart;
	DMA_HandleTypeDef* hdma;
};
/*************************************************values********************************************************************/
extern struct IMU_t IMU;
//****************************************************************FUNCTIONS************************************************
void EnableIMU(struct IMU_t* IMU);

void DisableIMU(struct IMU_t* IMU);

void Returnypr(struct IMU_t* IMU,float * data);

void Returnyprs(struct IMU_t* IMU,float * data);

uint32_t ReturnGYUptime(struct IMU_t* IMU);

void SetPitchOffset(struct IMU_t* IMU,float offset);

void SetYawOffset(struct IMU_t* IMU,float offset);
	
void SetRollOffset(struct IMU_t* IMU,float offset);

void SetIMUOffset(struct IMU_t* IMU);

void GetIMUdata(struct IMU_t* IMU);//IMUУ��&�������

void IMU_EXTI_CallBack(void* pv,uint16_t GPIO_Pin);

void DMA_CallBack(void* pv);
#endif

#endif
#ifdef __cplusplus
}
#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
