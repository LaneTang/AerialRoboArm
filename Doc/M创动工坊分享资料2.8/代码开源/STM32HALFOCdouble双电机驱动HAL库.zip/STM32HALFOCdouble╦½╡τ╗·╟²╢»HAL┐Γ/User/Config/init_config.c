/**
 * DreamChaser Frame Source File
 * 
 * @File:        .c
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */

/* Includes -------------------------------------------------------------------*/
#include "init_config.h"	 
#include "foc_dev.h"
/* Variables ------------------------------------------------------------------*/
/* Functions ------------------------------------------------------------------*/	 
/**
 * @brief 	初始化
 * @param 	None
 * @retval	None
 * @note	None
 */

void frameInit(void){
	// 启动外设
	Remote_InitRemote(&huart3);
	Motor_GroupConfig();
	FOC_Closeloop_Init(&FOC,&htim1, 24,10, 1, 11);
	IIC_encoder_Config(&AS5600,&hi2c2,0x36,12,0x0C);
	FOC_AlignmentSensor(&FOC);
}
/**
 * @brief 	初始化RTOS线程
 * @param 	None
 * @retval	None
 * @note	None
 */

void frameRTOSInit(void){
	RTOS_GimbalTaskStart();
	RTOS_ModeControlTaskStart();
	FreeRTOS_EnableMiniPC();
}

/**
 * @brief 	轮询任务
 * @param 	None
 * @retval	None
 * @note	None
 */
void mainloop(void){
	HAL_Delay(10);
	
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
