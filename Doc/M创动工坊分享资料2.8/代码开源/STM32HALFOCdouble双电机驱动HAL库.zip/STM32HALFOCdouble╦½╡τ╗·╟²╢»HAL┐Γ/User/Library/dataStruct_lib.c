/**
 * DreamChaser Frame Source File
 * 
 * @File:        .c
 * @Brief:       
 * @Author:     Huang Xingze
 * @Modified:    
 *
 */

 #include "dataStruct_lib.h"
 /**
 * @brief 	��ʼ�����ζ���
 * @param 	None
 * @retval	None
 * @note	None
 */
void InitringBuffer(ringBuffer_t * ringBuf,int Typesize)
{
	ringBuf->len = Typesize;
}
/**
 * @brief 	�жϻ��ζ����Ƿ�����������1
 * @param 	None
 * @retval	None
 * @note	None
 */
uint8_t IsRingBufferFull(ringBuffer_t *ringBuf)
{
	 if (ringBuf == NULL)
    {
        return 0;
    }
    
    if(((ringBuf->in+1) % RING_BUFF_SIZE) == ringBuf->out)
    {
        return 1;
    }
    return 0;
}
/**
 * @brief 	�жϻ��ζ����Ƿ��,�շ���1
 * @param 	None
 * @retval	None
 * @note	None
 */
uint8_t RingBuffIsEmpty(ringBuffer_t *ringBuf)
{ 
	if (ringBuf == NULL)
    {
        return 0;
    }
    
    if(ringBuf->in == ringBuf->out)   //д��λ�úͶ���λ�����ʱΪ��
    {
//		printf("Ring buffer is Empty\r\n");
        return 1;
    }
    return 0;
}
/**
 * @brief 	��ȡ���ζ��г���
 * @param 	None
 * @retval	None
 * @note	None
 */
uint8_t GetRingBufferLength(ringBuffer_t *ringBuf)
{
    if (ringBuf == NULL)
    {
        return 0;
    }

    return (ringBuf->in - ringBuf->out + RING_BUFF_SIZE) % RING_BUFF_SIZE;
}
/**
 * @brief 	д��һ�ֽڵ����ζ���
 * @param 	None
 * @retval	None
 * @note	None
 */
uint8_t WriteOneByteToRingBuffer(ringBuffer_t *ringBuf,uint8_t data)
{
	if (ringBuf == NULL)
    {
        return 0;
    }
    
    if(IsRingBufferFull(ringBuf))   //д֮ǰ���ж϶����Ƿ�д��
    {
        return 0;
    }

    ringBuf->buffer[ringBuf->in] = data;
    ringBuf->in = (++ringBuf->in) % RING_BUFF_SIZE;    //��ֹԽ��
	return 1;
}
/**
 * @brief 	��ȡһ�ֽ�
 * @param 	None
 * @retval	None
 * @note	None
 */
uint8_t ReadOneByteFromRingBuffer(ringBuffer_t *ringBuf,uint8_t *data)
{
	if (ringBuf == NULL)
    {
        return 0;
    }
    
    if(RingBuffIsEmpty(ringBuf))    //��֮ǰ�ж϶����Ƿ�Ϊ��
    {
        return 0;
    }

    *data = ringBuf->buffer[ringBuf->out];
    ringBuf->out = (++ringBuf->out) % RING_BUFF_SIZE;    //��ֹԽ��

    return 1;
} 
/**
 * @brief 	д��
 * @param 	None
 * @retval	None
 * @note	None
 */
void RingBuf_Write(ringBuffer_t *ringBuf,uint8_t *writeBuf)
{
     uint8_t i;
	
	if (ringBuf == NULL)
    {
        return;
    }
    
    for(i = 0; i < ringBuf-> len; i++)
    {
        WriteOneByteToRingBuffer(ringBuf,writeBuf[i]);
    }
}
/**
 * @brief 	��ȡ
 * @param 	None
 * @retval	None
 * @note	None
 */
unsigned char RingBuf_Read(ringBuffer_t * ringBuf,uint8_t* pData)
{
     uint8_t i;
    
	if (ringBuf == NULL)
    {
        return 0;
    }
    
    for(i = 0; i < ringBuf-> len; i++)
    {
        ReadOneByteFromRingBuffer(ringBuf,&pData[i]);
    }
		return 1;
}

/************************ COPYRIGHT BIT DreamChaser *****END OF FILE****/

