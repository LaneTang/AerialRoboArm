/**
 * DreamChaser Frame Header File
 * 
 * @File:        remote_task.h
 * @Brief:       
 * @Author:      Huang Xingze
 * @Modified:    
 *
 */

#ifndef _DATA_STRUCTURE_H_
#define _DATA_STRUCTURE_H_
/* Includes -------------------------------------------------------------------*/
#include "main.h"
/* Const ----------------------------------------------------------------------*/
	
/* define ---------------------------------------------------------------------*/
#define RING_BUFF_SIZE 2000
/* Typedef --------------------------------------------------------------------*/
typedef struct ringBuff
{
    unsigned int in;               //д���λ��
    unsigned int out;              //������λ��
    unsigned char buffer[RING_BUFF_SIZE];     //������
	uint8_t len;
}ringBuffer_t;
/* Variables ------------------------------------------------------------------*/

/* Functions ------------------------------------------------------------------*/	

void InitringBuffer(ringBuffer_t * ringBuf,int Typesize);
void RingBuf_Write(ringBuffer_t *ringBuf,uint8_t *writeBuf);
unsigned char RingBuf_Read(ringBuffer_t * ringBuf,uint8_t* pData);
uint8_t IsRingBufferFull(ringBuffer_t *ringBuf);
uint8_t RingBuffIsEmpty(ringBuffer_t * ringBuf);
#endif
