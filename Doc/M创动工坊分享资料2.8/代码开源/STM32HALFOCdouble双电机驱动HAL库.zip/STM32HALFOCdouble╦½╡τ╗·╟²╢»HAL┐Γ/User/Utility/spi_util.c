#include "spi_util.h"
#include "string.h"
void Set_SPI_Read(SPI_t* SPI_Ins,uint8_t len);
void SPI_Read_Write(SPI_t* SPI_Ins);
void Set_SPI_Write(SPI_t* SPI_Ins,uint8_t len,uint8_t* Data);
/**
  * @brief      ʹ��SPI��DMA
  * @param    
  */
void Enable_SPI_DMA(SPI_t* SPI)
{
		SPI->ENABLE_DMA = 1;
	 SET_BIT(SPI->SPI_IO.spi->Instance->CR2, SPI_CR2_TXDMAEN);
   SET_BIT(SPI->SPI_IO.spi->Instance->CR2, SPI_CR2_RXDMAEN);

    __HAL_SPI_ENABLE(SPI->SPI_IO.spi);
    //disable DMA
    //ʧЧDMA
    __HAL_DMA_DISABLE(SPI->SPI_IO.spi->hdmarx);
    
    while(SPI->SPI_IO.spi->hdmarx->Instance->CR & DMA_SxCR_EN)
    {
        __HAL_DMA_DISABLE(SPI->SPI_IO.spi->hdmarx);
    }

    __HAL_DMA_CLEAR_FLAG(SPI->SPI_IO.spi->hdmarx, DMA_LISR_TCIF2);

    SPI->SPI_IO.spi->hdmarx->Instance->PAR = (uint32_t) & (SPI1->DR);
    //memory buffer 1
    //�ڴ滺����1
    SPI->SPI_IO.spi->hdmarx->Instance->M0AR = (uint32_t)(SPI->SPI_IO.RXbuff);
    //data length
    //���ݳ���
    __HAL_DMA_SET_COUNTER(SPI->SPI_IO.spi->hdmarx, SPI->SPI_IO.ReadNUm);

    __HAL_DMA_ENABLE_IT(SPI->SPI_IO.spi->hdmarx, DMA_IT_TC);


    //disable DMA
    //ʧЧDMA
    __HAL_DMA_DISABLE(SPI->SPI_IO.spi->hdmatx);
    
    while(SPI->SPI_IO.spi->hdmatx->Instance->CR & DMA_SxCR_EN)
    {
        __HAL_DMA_DISABLE(SPI->SPI_IO.spi->hdmatx);
    }


    __HAL_DMA_CLEAR_FLAG(SPI->SPI_IO.spi->hdmatx, DMA_LISR_TCIF3);

    SPI->SPI_IO.spi->hdmatx->Instance->PAR = (uint32_t) & (SPI1->DR);
    //memory buffer 1
    //�ڴ滺����1
    SPI->SPI_IO.spi->hdmatx->Instance->M0AR = (uint32_t)(SPI->SPI_IO.TXbuff);
    //data length
    //���ݳ���
    __HAL_DMA_SET_COUNTER(SPI->SPI_IO.spi->hdmatx, SPI->SPI_IO.ReadNUm);		
}
/**
  * @brief      ��ʼ��SPI
  * @param    
  */
void InitSPI(SPI_t* SPI)
{
	if(SPI->ENABLE_DMA)
	{
		Enable_SPI_DMA(SPI);
	}
	SPI->SPIMode = 3;
}
/**
  * @brief      ��Ϊֻ��
  * @param    len���ݳ���
  */
void Set_SPI_Read(SPI_t* SPI_Ins,uint8_t len)
{
	//if(SPI_Ins->SPIMode == 3) //����
	{
		SPI_Ins->SPIMode = 0;
		SPI_Ins->SPI_IO.ReadNUm = len;
		return;
	}
}
/**
  * @brief      ��Ϊֻд
  * @param    len���ݳ���
  */
void Set_SPI_Write(SPI_t* SPI_Ins,uint8_t len,uint8_t* Data)
{
	//if(SPI_Ins->SPIMode == 3) //����
	{
		SPI_Ins->SPIMode = 1;
		SPI_Ins->SPI_IO.ReadNUm = len;
		for(int i =0;i<len;i++)
		{
			SPI_Ins->SPI_IO.TXbuff[i] = Data[i];
		}
		return;
	}
}
/**
  * @brief      ��Ϊ�ɶ�д
  * @param    len���ݳ���
  */
void Set_SPI_Write_Read(SPI_t* SPI_Ins,uint8_t len,uint8_t* Data)
{
	//if(SPI_Ins->SPIMode == 3) //����
	{
		SPI_Ins->SPIMode = 2;
		SPI_Ins->SPI_IO.ReadNUm = len;
		for(int i =0;i<len;i++)
		{
			SPI_Ins->SPI_IO.TXbuff[i] = Data[i];
		}
		return;
	}
}
/**
  * @brief     CS;chip select
  * @param    
  */
void SPI_CS_Choose(SPI_t* SPI_Ins)
{
	HAL_GPIO_WritePin(SPI_Ins->SPI_CS.GPIOx,SPI_Ins->SPI_CS.GPIO_PIN,GPIO_PIN_RESET);
}
/**
  * @brief    �ͷ�CS
  * @param    
  */
void SPI_CS_Release(SPI_t* SPI_Ins)
{
	HAL_GPIO_WritePin(SPI_Ins->SPI_CS.GPIOx,SPI_Ins->SPI_CS.GPIO_PIN,GPIO_PIN_SET);
}
/**
  * @brief    ��DMA����
  * @param    
  */
void SPI_TR_IT(SPI_t* SPI_Ins)
{
	HAL_SPI_TransmitReceive(SPI_Ins->SPI_IO.spi,  SPI_Ins->SPI_IO.TXbuff,  SPI_Ins->SPI_IO.RXbuff,  SPI_Ins->SPI_IO.ReadNUm, 1000);
}
/**
  * @brief      DMA����
  * @param    
  */
void SPI_TR_DMA(SPI_t* SPI_Ins)
{
	//disable DMA
    //ʧЧDMA
    __HAL_DMA_DISABLE(SPI_Ins->SPI_IO.spi->hdmarx);
    __HAL_DMA_DISABLE(SPI_Ins->SPI_IO.spi->hdmatx);
    while(SPI_Ins->SPI_IO.spi->hdmarx->Instance->CR & DMA_SxCR_EN)
    {
        __HAL_DMA_DISABLE(SPI_Ins->SPI_IO.spi->hdmarx);
    }
    while(SPI_Ins->SPI_IO.spi->hdmatx->Instance->CR & DMA_SxCR_EN)
    {
        __HAL_DMA_DISABLE(SPI_Ins->SPI_IO.spi->hdmatx);
    }
    //clear flag
    //�����־λ
    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmarx, __HAL_DMA_GET_TC_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmarx));
    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmarx, __HAL_DMA_GET_HT_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmarx));
    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmarx, __HAL_DMA_GET_TE_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmarx));
    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmarx, __HAL_DMA_GET_DME_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmarx));
    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmarx, __HAL_DMA_GET_FE_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmarx));

    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmatx, __HAL_DMA_GET_TC_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmatx));
    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmatx, __HAL_DMA_GET_HT_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmatx));
    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmatx, __HAL_DMA_GET_TE_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmatx));
    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmatx, __HAL_DMA_GET_DME_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmatx));
    __HAL_DMA_CLEAR_FLAG (SPI_Ins->SPI_IO.spi->hdmatx, __HAL_DMA_GET_FE_FLAG_INDEX(SPI_Ins->SPI_IO.spi->hdmatx));
    //set memory address
    //�������ݵ�ַ
    SPI_Ins->SPI_IO.spi->hdmarx->Instance->M0AR = (uint32_t)SPI_Ins->SPI_IO.RXbuff;
    SPI_Ins->SPI_IO.spi->hdmatx->Instance->M0AR = (uint32_t)SPI_Ins->SPI_IO.TXbuff;
    //set data length
    //�������ݳ���
    __HAL_DMA_SET_COUNTER(SPI_Ins->SPI_IO.spi->hdmarx, SPI_Ins->SPI_IO.ReadNUm);
    __HAL_DMA_SET_COUNTER(SPI_Ins->SPI_IO.spi->hdmatx, SPI_Ins->SPI_IO.ReadNUm);
    //enable DMA
    //ʹ��DMA
    __HAL_DMA_ENABLE(SPI_Ins->SPI_IO.spi->hdmarx);
    __HAL_DMA_ENABLE(SPI_Ins->SPI_IO.spi->hdmatx);
}
/**
  * @brief      DMA��д
  * @param    
  */
void SPI_Read_Write(SPI_t* SPI_Ins)
{
	if(!SPI_Ins->ENABLE_DMA)
	{
		switch (SPI_Ins->SPIMode)
		{
			case 0:
			{
				for(int i = 0;i<SPI_Ins->SPI_IO.ReadNUm;i++)
				SPI_Ins->SPI_IO.TXbuff[i] = 0x55;
				SPI_TR_IT(SPI_Ins);
				break;
			}
			case 1:
			{
				SPI_TR_IT(SPI_Ins);
				for(int i = 0;i<SPI_Ins->SPI_IO.ReadNUm;i++)
				{
					SPI_Ins->SPI_IO.RXbuff[i] = 0x00;
				}
				break;
			}
			case 2:
			{
				SPI_TR_IT(SPI_Ins);
				break;
			}
		}
		SPI_Ins->SPIMode = 3;		
	}
	else
	{
		switch (SPI_Ins->SPIMode)
		{
			case 0:
			{
				SPI_CS_Choose(SPI_Ins);
				for(int i = 0;i<SPI_Ins->SPI_IO.ReadNUm;i++)
				SPI_Ins->SPI_IO.TXbuff[i] = 0x55;
				SPI_TR_DMA(SPI_Ins);
				break;
			}
			case 1:
			{
				SPI_CS_Choose(SPI_Ins);
				SPI_TR_DMA(SPI_Ins);
				for(int i = 0;i<SPI_Ins->SPI_IO.ReadNUm;i++)
				{
					SPI_Ins->SPI_IO.RXbuff[i] = 0x00;
				}
				
				break;
			}
			case 2:
			{
				SPI_CS_Choose(SPI_Ins);
				SPI_TR_DMA(SPI_Ins);
				break;
			}
		}
		SPI_Ins->SPIMode = 4;				
	}
	
}
/**
  * @brief      �жϻص�
  * @param    
  */
void SPI_DMACallBack(SPI_t* SPI_Ins)
{
	SPI_Ins->SPIMode = 3;				
	SPI_CS_Release(SPI_Ins);
}
/**
  * @brief      ��������
  * @param    
  */
void SPI_ReturnData(SPI_t* SPI_Ins,uint8_t *data)
{
	memcpy(data,SPI_Ins->SPI_IO.RXbuff,SPI_Ins->SPI_IO.ReadNUm);
}
