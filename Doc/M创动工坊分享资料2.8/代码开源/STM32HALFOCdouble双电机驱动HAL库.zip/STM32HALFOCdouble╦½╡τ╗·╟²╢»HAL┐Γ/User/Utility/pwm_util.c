/**
 * DreamChaser Frame Source File
 * 
 * @File:        .c
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#include "pwm_util.h"
/**
 * @brief 	开启PWM
 * @param 	pwm:pwm句柄
 * @retval	None
 */
void PWM_StartPWM(PWMHandle_t* pwm) {
	if (pwm->state == PWM_OFF) {
		HAL_TIM_PWM_Start(pwm->htim, pwm->ch); 
		pwm->state = PWM_ON;
	}
}

/**
 * @brief 	关闭PWM
 * @param 	pwm:pwm句柄
 * @retval	None
 */
void PWM_StopPWM(PWMHandle_t* pwm) {
	if (pwm->state == PWM_ON) {
		HAL_TIM_PWM_Stop(pwm->htim, pwm->ch);
		pwm->state = PWM_OFF;
	}
}

/**
 * @brief 	设置PWM占空比
 * @param 	pwm:pwm句柄
 * @retval	None
 */
void PWM_SetPWMDuty(PWMHandle_t* pwm, float duty) {
    
    pwm->duty = duty;
		if(pwm->state==PWM_ON)
    __HAL_TIM_SetCompare(pwm->htim,pwm->ch,duty*pwm->htim->Init.Period);  
}
//tim2,3,4,5,6,7,12,13,14在APB1  42MHz
//tim1,8,9,10,11  APB2  84MHz
/**
 * @brief 	初始化PWM
 * @param 	apb时钟总线
 * @param 	duty初始占空比
 * @retval	None
 */
void PWM_InitPWM(PWMHandle_t* pwm, TIM_HandleTypeDef* htim, uint32_t channel ,float duty) {
	pwm->htim   = htim;
	pwm->ch     = channel;
	pwm->state  = PWM_ON;
	pwm->duty   = duty;
	HAL_TIM_PWM_Start(htim,channel);
	PWM_SetPWMDuty(pwm,duty);
	}


/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
