/* USER CODE BEGIN 1 */

#include "iic_util.h"
/**
  * @brief      初始化I2C DMA
  * @param      huart: UART句柄
  * @retval     无
  */
void I2C_InitUartDMA(I2C_HandleTypeDef *hi2c) {
    /* open uart idle it */
    __HAL_I2C_CLEAR_STOPFLAG(hi2c);
    __HAL_I2C_ENABLE_IT(hi2c, UART_IT_IDLE);
}
/**
  * @brief      I2C错误处理程序
  * @param      ret: 错误代码
  * @retval     无
  */
void IIC_ErrorHandler(uint32_t ret) {
    while (1) {
        return;
    }
}
/**
 * @brief        任意地址写一个字节数据（阻塞）
 * @param        DevAddress —— 设备地址（0-255）
 * @param        MemAddress —— 写数据的地址（0-255）
 * @param        Data  —— 数据
 * @retval       成功 —— HAL_OK
*/
void IIC_Mem_Send(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint16_t MemAddress, uint8_t Data,uint16_t size, uint32_t Timeout)
{
	HAL_StatusTypeDef ret = HAL_I2C_Mem_Write(hi2c, DevAddress, MemAddress, I2C_MEMADD_SIZE_8BIT, &Data,size, Timeout);

    if (ret != HAL_OK) {
        /* Transmission request Error */
        IIC_ErrorHandler(ret);
    }
}

/**
 * @brief        IIC任意地址读一个字节数据（阻塞）
 * @param        addr —— 读数据的地址（0-255）
 * @param        read_buf —— 存放读取数据的地址
 * @retval       成功 —— HAL_OK
*/
void IIC_Mem_Read(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint16_t MemAddress, uint8_t *pData, uint16_t size, uint32_t Timeout)
{
	HAL_StatusTypeDef ret = HAL_I2C_Mem_Read(hi2c, DevAddress, MemAddress, I2C_MEMADD_SIZE_8BIT, pData,size, Timeout);

    if (ret != HAL_OK) {
        /* Transmission request Error */
        IIC_ErrorHandler(ret);
    }
}
/**
 * @brief        任意地址写一个字节数据（阻塞）
 * @param        DevAddress —— 设备地址（0-255）
 * @param        MemAddress —— 写数据的地址（0-255）
 * @param        Data  —— 数据
 * @retval       成功 —— HAL_OK
*/
void IIC_Mem_Send_IT(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint16_t MemAddress, uint8_t Data,uint16_t size)
{
	HAL_StatusTypeDef ret = HAL_I2C_Mem_Write_IT(hi2c, DevAddress, MemAddress, I2C_MEMADD_SIZE_8BIT, &Data,size);

    if (ret != HAL_OK) {
        /* Transmission request Error */
        IIC_ErrorHandler(ret);
    }
}

/**
 * @brief        IIC任意地址读一个字节数据（阻塞）
 * @param        addr —— 读数据的地址（0-255）
 * @param        read_buf —— 存放读取数据的地址
 * @retval       成功 —— HAL_OK
*/
void IIC_Mem_Read_IT(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint16_t MemAddress, uint8_t *pData, uint16_t size)
{
	HAL_StatusTypeDef ret = HAL_I2C_Mem_Read_IT(hi2c, DevAddress, MemAddress, I2C_MEMADD_SIZE_8BIT, pData,size);

    if (ret != HAL_OK) {
        /* Transmission request Error */
        IIC_ErrorHandler(ret);
    }
}
/**
 * @brief        任意地址写一个字节数据（非阻塞）
 * @param        DevAddress —— 设备地址（0-255）
 * @param        Data  —— 数据
 * @retval       成功 —— HAL_OK
*/
void IIC_Send_IT(I2C_HandleTypeDef *hi2c, uint16_t DevAddress,uint8_t Data, uint16_t size)
{
	HAL_StatusTypeDef ret = HAL_I2C_Master_Transmit_IT(hi2c, DevAddress,&Data,size);

    if (ret != HAL_OK) {
        /* Transmission request Error */
        IIC_ErrorHandler(ret);
    }
}


/**
 * @brief        IIC任意地址读一个字节数据（非阻塞）
 * @param        addr —— 读数据的地址（0-255）
 * @param        read_buf —— 存放读取数据的地址
 * @retval       成功 —— HAL_OK
*/
void IIC_Read_IT(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint8_t *pData, uint16_t size)
{
	HAL_StatusTypeDef ret = HAL_I2C_Master_Receive_IT(hi2c, DevAddress, pData,size);

    if (ret != HAL_OK) {
        /* Transmission request Error */
        IIC_ErrorHandler(ret);
    }
}
/**
  * @brief      enable global i2c it and do not use DMA transfer done it
  * @param      huart: uart IRQHandler id
  * @param      pData: receive buff 
  * @param      Size:  buff size
  * @retval     set success or fail
  */
void I2C_ReceiveDMA(I2C_HandleTypeDef *hi2c, uint8_t rxdata[], uint32_t size) {
    uint32_t tmp1 = 0;
    tmp1 = hi2c->State;
    if (tmp1 == HAL_I2C_STATE_READY) {
        if ((rxdata == NULL) || (size == 0)) {
            return;
        }
        hi2c->pBuffPtr = rxdata;
        hi2c->XferSize = size;
        hi2c->ErrorCode  = HAL_I2C_ERROR_NONE;
        /* Enable the DMA Stream */
        HAL_DMA_Start(hi2c->hdmarx, (uint32_t)&hi2c->Instance->DR, (uint32_t)rxdata, size);
        /* 
         * Enable the DMA transfer for the receiver request by setting the DMAR bit
         * in the UART CR3 register 
         */
        SET_BIT(hi2c->Instance->CR2, I2C_CR2_DMAEN);
    }
}