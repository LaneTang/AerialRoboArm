/**
 * DreamChaser Frame Header File
 * 
 * @File:        pwm_util.h
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#ifndef __PWM_UTIL_H
#define __PWM_UTIL_H
#ifdef __cplusplus
extern "C" {
#endif 

#include "tim.h"
	typedef enum
{
	PWM_OFF,
	PWM_ON
}PWM_State_e;

//typedef enum{
//	APB1_TIMER = 1,
//	APB2_TIMER = 2

//}PWM_APB_e;

typedef struct
{
	TIM_HandleTypeDef* htim;	//定时器句柄
	uint32_t ch;				//通道
	float duty;					//占空比
	PWM_State_e state;		//开关	
}PWMHandle_t;


void PWM_InitPWM(PWMHandle_t* pwm, TIM_HandleTypeDef* htim, uint32_t ch ,float duty) ;
void PWM_StartPWM(PWMHandle_t* pwm);
void PWM_StopPWM(PWMHandle_t* pwm);
void PWM_SetPWMDuty(PWMHandle_t* pwm, float duty);

#endif
#ifdef __cplusplus
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
