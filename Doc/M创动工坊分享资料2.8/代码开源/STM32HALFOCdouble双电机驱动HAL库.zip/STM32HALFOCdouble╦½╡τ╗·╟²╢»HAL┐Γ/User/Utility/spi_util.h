#include "main.h"
#include "cmsis_os.h"
#include "can.h"
#include "dma.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "usb_device.h"
#include "gpio.h"
#ifndef _BSP_SPI_H_
#define _BSP_SPI_H_
typedef struct
{
	GPIO_TypeDef* GPIOx;
	uint32_t GPIO_PIN;
}SPI_CS_t;
typedef struct
{
	SPI_HandleTypeDef * spi;
	uint8_t TXbuff[40];
	uint8_t RXbuff[40];
	uint8_t NowReadPtr;
	uint32_t ReadNUm;
}SPI_IO_t;
typedef struct
{
	SPI_IO_t SPI_IO;
	SPI_CS_t SPI_CS;
	uint8_t SPIMode;//R 0 W 1 R|W 2  ���� 3
	uint8_t ENABLE_DMA;
}SPI_t;
void Set_SPI_Read(SPI_t* SPI_Ins,uint8_t len);

void SPI_Read_Write(SPI_t* SPI_Ins);

void Set_SPI_Write_Read(SPI_t* SPI_Ins,uint8_t len,uint8_t* Data);

void Set_SPI_Write(SPI_t* SPI_Ins,uint8_t len,uint8_t* Data);

void SPI_ReturnData(SPI_t* SPI_Ins,uint8_t *data);

void InitSPI(SPI_t* SPI);

void SPI_DeLay_us(uint32_t Time);

void SPI_DMACallBack(SPI_t* SPI_Ins);

void Enable_SPI_DMA(SPI_t* SPI);

void SPI_CS_Choose(SPI_t* SPI_Ins);

void SPI_CS_Release(SPI_t* SPI_Ins);
#endif
