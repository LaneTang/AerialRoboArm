/**
 * DreamChaser Frame Header File
 *
 * @File:        uart_util.h
 * @Brief:
 * @Author:      Ju	Chaowen
 * @Modified:
 *
 */
#ifndef __IIC_UTIL_H
#define __IIC_UTIL_H
#ifdef __cplusplus
extern "C" {
#endif
    /* Includes -------------------------------------------------------------------*/
#include "i2c.h"
    /* USER CODE BEGIN Prototypes */
    void IIC_Mem_Send(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint16_t MemAddress, uint8_t Data, uint16_t size, uint32_t Timeout);
    void IIC_Mem_Read(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint16_t MemAddress, uint8_t *pData, uint16_t size, uint32_t Timeout);
    void IIC_Mem_Send_IT(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint16_t MemAddress, uint8_t Data,uint16_t size);
    void IIC_Mem_Read_IT(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint16_t MemAddress, uint8_t *pData, uint16_t size);
    void I2C_InitUartDMA(I2C_HandleTypeDef *hi2c);
    void I2C_ReceiveDMA(I2C_HandleTypeDef *hi2c, uint8_t rxdata[], uint32_t size);
    /* USER CODE END Prototypes */

#endif
#ifdef __cplusplus
}
#endif
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
