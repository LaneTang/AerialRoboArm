/**
 * DreamChaser Frame Header File
 * 
 * @File:        .h
 * @Brief:       
 * @Author:      Peng Huishuai
 * @Modified:    
 *
 */
#ifndef _CONNECT_TASK_H
#define _CONNECT_TASK_H
#ifdef __cplusplus
extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "can_util.h"
#include "frame_config.h"
#include "miniPC_dev.h"
#include "autoaim_func.h"
/* Const ----------------------------------------------------------------------*/
	
/* define ---------------------------------------------------------------------*/
	
/* Typedef --------------------------------------------------------------------*/
 typedef enum  
{
	CHASSIS_JUDGE = 0,
	REMOTE        = 1,
	GIMBAL 			  = 2,
	MINIPC		    = 3,
	ALL           = 4,
}CAN_STDID_ADDR;

typedef enum 
{
    blue = 1,
	red  = 2,
}color;

typedef enum {
	SHOOTER_STOP       	= 0,   //摩擦轮停止
	SHOOTER_FAST  	    = 1,   //30 m/s
	SHOOTER_SLOW        = 2,   //15 m/s
	SHOOTER_OVER        = 3,   //超射速
}Shooter_ModeType_e;


__packed typedef struct
{	
	    __packed struct
		{
			int16_t YawAngle;
			int16_t PitchAngle;
			int8_t FeederSpeed;
		}Remote;
		
		
		__packed struct
		{
		    uint16_t DataFlow;
			int16_t Chassis_current_pos;
		}Chassis;
	
		__packed struct
		{
			uint8_t GimbalMove_Mode;
			uint8_t GimbalMove_Cylce_Mode;
			uint8_t Shooter_Mode;
			uint8_t Feeder_Mode;
		}Mode;
		
		__packed struct
		{
			uint8_t is_MiniPC_Shutdown;
		}ToMiniPC;
		
}Chassis_Data_t;


__packed typedef struct
{	
	    __packed struct
		{
			uint8_t is_get;
			uint16_t DataFlow;
		}MiniPC;
		__packed struct
		{
		   uint16_t DataFlow;
		   uint8_t Gimbal_Response_State;
		}Gimbal;
}Gimbal_Data_t;

/* Variables ------------------------------------------------------------------*/
extern  Chassis_Data_t ChassisData;
extern  Gimbal_Data_t GimbalData;

/* Functions ------------------------------------------------------------------*/	 

void DataConnect_Init(void);

void Chassis_SendTaskStart(void);
void Gimbal_SendTaskStart(void);

void Connect_EncoderDecodeCallback(CAN_HandleTypeDef* phcan, uint16_t stdid, uint8_t rxdata[]);

#ifdef __cplusplus
}
#endif
#endif
/************************ COPYRIGHT BIT DreamChaser *****END OF FILE****/




















