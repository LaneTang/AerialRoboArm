/**
 * DreamChaser Frame Source File
 * 
 * @File:        connect_task.c
 * @Brief:       板间通信相关
 * @Author:      Zhu Tianyu
 * @Modified:    2021/11/3
 *
 */
 
/* Includes -------------------------------------------------------------------*/
#include "connect_task.h"
#include "gimbal_task.h"
#include "cmsis_os.h"

/* Variables ------------------------------------------------------------------*/
Gimbal_Data_t GimbalData;
Chassis_Data_t ChassisData;
CAN_Buff_t SomeThing_TxBuff;

/* Functions ------------------------------------------------------------------*/	 
/**
 * @brief 	xx
 * @param 	None
 * @retval	None
 * @note	None
 */
void DataConnect_Init(void)
{
	Can2.hcan=&hcan2;
	Can_InitFilterAndStart(Can2.hcan);
	InitringBuffer(&Can2.TxRingQue,sizeof(CAN_Buff_t));
	
	ChassisData.Remote.PitchAngle = 0;
	ChassisData.Remote.YawAngle = 0;
}
 
/**
 * @brief 	发送云台数据
 * @param 	None
 * @retval	None
 * @note	None
 */
uint8_t changeflag = 0;
void SendGimbalData(Gimbal_Data_t *gimbaldata){

	 SomeThing_TxBuff.STDID = GIMBAL;  
	
	 SomeThing_TxBuff.DLC = 8;
	 SomeThing_TxBuff.Buff[0] = 0;
	 SomeThing_TxBuff.Buff[1] = 0;
	 SomeThing_TxBuff.Buff[2] = 0;
	 SomeThing_TxBuff.Buff[3] = 0;
	 SomeThing_TxBuff.Buff[4] = 0;
	 SomeThing_TxBuff.Buff[5] = 0;
	 SomeThing_TxBuff.Buff[6] = 0;
	 SomeThing_TxBuff.Buff[7] = 0;
		
	 for(int i=0;i<SomeThing_TxBuff.DLC;i++)
	 {
			if(SomeThing_TxBuff.Buff[i] != SomeThing_TxBuff.BuffLast[i])
			changeflag = 1;
			break;
	 }
	 if(changeflag)
	 CAN_WriteTxdata(&Can2,&SomeThing_TxBuff);
	 for(int i=2;i<SomeThing_TxBuff.DLC;i++)
	 {
			SomeThing_TxBuff.BuffLast[i] = SomeThing_TxBuff.Buff[i];
			
	 }
 }

/**
 * @brief 	云台电脑数据解码1
 * @param 	云台原始数据
 * @retval	None
 * @note	None
 */
void miniPC_Decode(uint8_t rxdata[]) 
{
}
/**
 * @brief 	xx
 * @param 	None
 * @retval	None
 * @note	None
 */
void Connect_EncoderDecodeCallback(CAN_HandleTypeDef* phcan, uint16_t stdid, uint8_t rxdata[])
{
	switch (stdid)
		
	{
		case CHASSIS_JUDGE:
			break;
		
		case REMOTE:
			break;
		
		case MINIPC:
			miniPC_Decode(rxdata) ;
		  break;
		
		default:
			break;

	}

}


/************************ RTOS *******************/
/**
 * @brief 	xx
 * @param 	None
 * @retval	None
 * @note	None
 */
 void Gimbal_SendTask() 
{	
	for(;;)
	{	
		GimbalData.Gimbal.DataFlow=HAL_GetTick();
		SendGimbalData(&GimbalData);
		osDelay(1);
	}	
}
void Gimbal_SendTaskStart(void)
{
	xTaskCreate((TaskFunction_t)Gimbal_SendTask,"",128,NULL,6,NULL);
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/

