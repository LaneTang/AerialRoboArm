/**
 * DreamChaser Frame Source File
 *
 * @File:        gimbal_task.c
 * @Brief:
 * @Author:
 * @Modified:    2021/11/8
 *
 */
/* Includes -------------------------------------------------------------------*/
#include "gimbal_task.h"
#include "frame_config.h"
#include "modectrl_task.h"
#include "RMD_dev.h"
#include "as5600_dev.h"
#include "foc_dev.h"
/* Variables ------------------------------------------------------------------*/
Motor_t   Motor_Chasis , Motor_Yaw;
Motor_Group_t *Motor_gimbal3508Motors;
move_data_t Move_Data;
float pitch_offset = -60;
low_pass_t speed_lp;
PID_t PID_Pitch[2];
/* Functions ------------------------------------------------------------------*/
/**
 * @brief 	云台初始化
 * @param 	None
 * @retval	None
 * @note	None
 */
void Gimbal_ParaInit(void) {
}


/**
* @brief        不同模式下云台参数设置
  * @param      无
  * @retval     无
  */
float torque_ref = 0;
void Gimbal_MotorTask() {

    for(;;)
    {
			FOC_SetTorque(&FOC, torque_ref ,FOC_Get_ElectricalAngle(&FOC));
        IIC_Encoder_Read();
        osDelay(5);
    }
}

/************************ RTOS *******************/
void RTOS_GimbalTaskStart(void)
{
    xTaskCreate((TaskFunction_t)Gimbal_MotorTask,"",128,NULL,6,NULL);
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
