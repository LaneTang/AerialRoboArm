/**
 * DreamChaser Frame Source File
 *
 * @File:        modectrl_task.c
 * @Brief:       云台模式接受命令及摩擦轮控制
 * @Author:      Zhu Tianyu
 * @Modified:    2021/11/4
 *
 */

/* Includes -------------------------------------------------------------------*/
#include "modectrl_task.h"
#include "frame_config.h"

/* Variables ------------------------------------------------------------------*/
uint8_t ModeChange_Flag = 0;
robot_mode_e RobotMode,Last_RobotMode;
float timet = 0;
/* Functions ------------------------------------------------------------------*/
/**
 * @brief 	云台运动模式控制
 * @param 	None
 * @retval	None
 * @note	None
 */

void Robot_ModeChange(void) {
    Last_RobotMode = RobotMode;
    switch(Remote_RemoteData.remote.sr)
    {
    case Remote_SWITCH_UP:
        RobotMode = robot_stop;
        break;
    case Remote_SWITCH_MIDDLE:
        RobotMode = robot_remote;
        break;
    case Remote_SWITCH_DOWN:
        RobotMode = robot_auto;
        break;
    default:
        break;
    }
}


/**
 * @brief 	摩擦轮模式控制
 * @param 	None
 * @retval	None
 * @note	None
 */
void Robot_MoveCtrl(void) {
    switch(RobotMode)
    {
    case robot_stop:
        Move_Data.speed_ref = 0;
        Move_Data.pitch_ref = 0;
        Move_Data.yaw_ref = 0;
        break;
    case robot_remote:
        Move_Data.speed_ref = Remote_RemoteData.remote.ch[2]*3.0f;
        Move_Data.pitch_ref += Remote_RemoteData.remote.ch[1]/10.0f/1000.0f;
        Move_Data.yaw_ref += Remote_RemoteData.remote.ch[0]/3.0f/1000.0f;
        break;
    case robot_auto:
			timet += 0.001f;
        Move_Data.speed_ref = 0;
        Move_Data.pitch_ref = 50.0f * sin(timet) + 50;
        Move_Data.yaw_ref = 0;
        break;
    default:
        break;
    }

}

/**
 * @brief 	云台总控
 * @param 	None
 * @retval	None
 * @note	None
 */
void Gimbal_Centrol_Ctrl_Task(void)
{

    for(;;)
    {
        Robot_ModeChange();
        Robot_MoveCtrl();
        osDelay(1);
    }

}


/************************ RTOS *******************/
void RTOS_ModeControlTaskStart(void)
{
    xTaskCreate((TaskFunction_t)Gimbal_Centrol_Ctrl_Task,"",128,NULL,6,NULL);
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
