/**
 * DreamChaser Frame Header File
 * 
 * @File:        remote_task.h
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#ifndef __MODECTRL_TASK_H
#define __MODECTRL_TASK_H
#ifdef __cplusplus
extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
//#include "remote_dev.h"
#include "include_lib.h"
#include "gimbal_task.h"
#include "snail_dev.h"
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "remote_dev.h"
/* Const ----------------------------------------------------------------------*/

/* define ---------------------------------------------------------------------*/
	
/* Typedef --------------------------------------------------------------------*/
typedef enum{
	robot_stop = 0,
	robot_auto = 1,
	robot_remote = 2
}robot_mode_e;
/* Variables ------------------------------------------------------------------*/

/* Variables ------------------------------------------------------------------*/
extern uint8_t ModeChange_Flag;

/* Functions ------------------------------------------------------------------*/	 
void RTOS_ModeControlTaskStart(void);
#ifdef __cplusplus
}
#endif
#endif
/************************ COPYRIGHT BIT DreamChaser *****END OF FILE****/
