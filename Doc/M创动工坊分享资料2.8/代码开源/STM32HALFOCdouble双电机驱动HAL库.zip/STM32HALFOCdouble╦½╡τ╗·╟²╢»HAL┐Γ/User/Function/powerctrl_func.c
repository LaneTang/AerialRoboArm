/**
 * DreamChaser Frame Source File
 * 
 * @File:        shootctrl_func.c
 * @Brief:       
 * @Author:      Zhu Tianyu
 * @Modified:    2021/10/26
 *
 */
 
/* Includes -------------------------------------------------------------------*/
#include "powerctrl_func.h"
#include <math.h>

/* Variables ------------------------------------------------------------------*/
float CONST_POWERBUFFER_LIMIT_FAST;
float CONST_POWERBUFFER_LIMIT_SLOW;
float CONST_POWERBUFFER_LIMIT_STOP;

/* Functions ------------------------------------------------------------------*/	

/**
  * @brief      功率控制初始化
  * @param      无
  * @retval     无
  * @note       
  */
void PowerctrlInit(void){
	CONST_POWERBUFFER_LIMIT_FAST = 80.0f;
    CONST_POWERBUFFER_LIMIT_SLOW = 30.0f;
    CONST_POWERBUFFER_LIMIT_STOP = 10.0f;
}

/**
  * @brief      功率控制函数
  * @param      
  * @retval     
  * @note       
  */
float Power_PowerCtrl(float output)
{
        if(Referee_RefereeData.chassis_power_buffer >= CONST_POWERBUFFER_LIMIT_FAST){ 
			   output = limit( output ,24000 , -24000 );
		}
		else if(Referee_RefereeData.chassis_power_buffer >= CONST_POWERBUFFER_LIMIT_SLOW){
			   output = limit( output ,10000 , -10000 );
		}
		else if(Referee_RefereeData.chassis_power_buffer >= CONST_POWERBUFFER_LIMIT_STOP){
			   output = limit( output ,2000 , -2000 );
		}
		else{
			   output = 0;
		}
		
		return output;
}

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
