/**
 * DreamChaser Frame Header File
 * 
 * @File:        .h
 * @Brief:       
 * @Author:      Zhu Tianyu
 * @Modified:    
 *
 */
#ifndef __MOVECTRL_FUNC_H
#define __MOVECTRL_FUNC_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "cmsis_os.h"
#include "miniPC_dev.h"
	 
/* define ----------------------------------------------------------------------*/

/* Typedef --------------------------------------------------------------------*/
typedef enum {
	GimbalMove_STOP       	        = 0,   //枪口停止
	GimbalMove_INIT                 = 1,   //初始化阶段   
  GimbalMove_REMOTE        	 	    = 2,   //巡检模式
	GimbalMove_AUTOAIM              = 3,   //枪口自瞄
	GimbalMove_AUTOAIM_WAIT         = 4,   //目标丢失一小段时间云台不动
	
}GimbalMove_ModeType_e;
	 

typedef struct{
	GimbalMove_ModeType_e GimbalMove_Mode;
	
	float Yaw_Ref;
	float Pitch_Ref;
	
	float Yaw_Ref_Limited;
	float Pitch_Ref_Limited;
	
	float Last_Yaw_Ref;
	float Last_Pitch_Ref;
	
}GimbalMove_t;
	 
/* Variables ------------------------------------------------------------------*/
extern GimbalMove_t GimbalMove_Data; 
extern uint16_t Autoaim_count;

/* Functions ------------------------------------------------------------------*/	 
void GimbalMove_Ctrl(void);
void GimbalmoveInit(void);

#ifdef __cplusplus
}
#endif

#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
