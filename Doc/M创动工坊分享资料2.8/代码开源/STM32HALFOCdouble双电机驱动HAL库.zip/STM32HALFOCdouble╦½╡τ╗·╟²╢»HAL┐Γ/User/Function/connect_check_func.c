/**
 * DreamChaser Frame Source File
 * 
 * @File:        
 * @Brief:       检测各部分是否离线
 * @Author:      
 * @Modified:    2021年10月30日
 */
/* Includes -------------------------------------------------------------------*/
#include "connect_task.h"
#include "connect_check_func.h"
#include "cmsis_os.h"
#include "referee_dev.h"
#include "log_func.h"
#include "remote_dev.h"
//#include "time.h"
/* Variables -------------------------------------Connect_Flag-----------------------------*/
ConnectStatus_t Connect_Flag;
uint8_t CAN_CongOK;
uint32_t PreTick;

float time_last = 0;//time from other device
/* Functions ------------------------------------------------------------------*/

/**
 * @brief 	检查左云台是否在线
 * @param 	None
 * @retval	None
 * @note	None
 */
void CheckConnect_something()
{
	if(PreTick == time_last)
		{
				if(Connect_Flag == CONNECTED)
				{
				Connect_Flag = DISCONNECTED;
				AddAnEvent("\r\nDISCONNECTED\r\n");
				}
		}
		else
		{
			if(Connect_Flag == DISCONNECTED)
			{
				Connect_Flag = CONNECTED;
				AddAnEvent("\r\nCONNECTED\r\n");
			}
			
		}
		PreTick = time_last;
}




/**
 * @brief 	检查两个电脑是否在线
 * @param 	None
 * @retval	None
 * @note	None
 */
void Check_ConnectTask()
{
	AddAnEvent("\r\nConnect_Check_Start\r\n");
	for(;;)
	{
		CheckConnect_something();
		osDelay(200);
	}
}
/********************************FREERTOS*********************************/
/**
 * @brief 	开启检测任务（云台，电脑）
 * @param 	None
 * @retval	None
 * @note	None
 */
void RTOS_CheckTaskStart()
{
	xTaskCreate((TaskFunction_t)Check_ConnectTask,"",64,NULL,6,NULL);
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
