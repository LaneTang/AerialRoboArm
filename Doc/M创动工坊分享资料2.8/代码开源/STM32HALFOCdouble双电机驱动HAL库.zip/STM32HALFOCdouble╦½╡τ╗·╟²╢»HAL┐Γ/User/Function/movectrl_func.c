/**
 * DreamChaser Frame Source File
 * 
 * @File:        movectrl_func.c
 * @Brief:       
 * @Author:      Zhu Tianyu
 * @Modified:    2021/11/1
 *
 */

/* Includes -------------------------------------------------------------------*/
#include "movectrl_func.h"	 
#include "connect_task.h"
#include "gimbal_task.h"
#include "autoaim_func.h"
#include "modectrl_task.h"
/* Variables ------------------------------------------------------------------*/
GimbalMove_t GimbalMove_Data;

uint16_t Autoaim_count;

float Target_YawAngle , Target_PitchAngle;
/* Functions ------------------------------------------------------------------*/	 
/**
 * @brief 	云台运动初始化
 * @param 	None
 * @retval	None
 * @note	None
 */
void GimbalmoveInit(void){
	
	GimbalMove_Data.GimbalMove_Mode = GimbalMove_INIT;
	Last_GimbalMode = GimbalMove_Data.GimbalMove_Mode;
	
	Autoaim_count = 0;
	
	Target_YawAngle = Target_PitchAngle = 0;

}

			 
/**
  * @brief      云台运动具体控制
  * @param      
  * @retval     
  * @note       
  */

void GimbalMove_Ctrl(void){
	switch(GimbalMove_Data.GimbalMove_Mode)
	{
		case GimbalMove_REMOTE:
			  
		    break;
		case GimbalMove_AUTOAIM:
			
		    break;
		
		case GimbalMove_AUTOAIM_WAIT:
		  	
		
		    if(Autoaim_count >= 1200){
				GimbalMove_Data.GimbalMove_Mode = GimbalMove_REMOTE;
				Autoaim_count = 0;
			}
				break;
		
		default:
			break;
	}
}


/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
