/**
 * DreamChaser Frame Header File
 * 
 * @File:        .h
 * @Brief:       
 * @Author:      
 * @Modified:    
 *
 */
 /* Includes -------------------------------------------------------------------*/

#include "main.h"
#include "log_func.h"
#include "string.h"
#include "connect_task.h"
#include "time.h"
#include "dataStruct_lib.h"
#include "referee_dev.h"

/* Variables ------------------------------------------------------------------*/
//extern struct tag_Chassis_Task Chassis_Task;

FATFS Log_fs;            //�����ռ�
FIL Log_fil;             // �ļ���Ŀ
uint32_t SizeOfLog;
char Lofname[] = "Log";  // �ļ���
DIR DirInfo;
FATFS log_fs;
int numoftxt = 0;
char logtxtname[20];
ringBuffer_t logbuff;
FRESULT openres;


/* Functions ------------------------------------------------------------------*/	   

/**
  * @brief      д���¼������ζ���
  * @param      Logbuff�ַ�����
  * @retval     void
  * @note       NULL
  */
void AddAnEvent(char * Logbuff)
{
	RingBuf_Write(&logbuff,(uint8_t *)Logbuff);
}
/**
  * @brief      ��ȡ����ʱ�䣨��ʽת����
  * @param      Logbuff�ַ�����
  * @retval     void
  * @note       NULL
  */
void GetPCTime(const unsigned int time,char* buff)
{
	strftime(buff,30,"%Y -%m-%d %H:%M:%S",gmtime(&time));
}

/**
  * @brief      д����־
  * @param      buffд������
  * @param      file�ļ���
  * @retval     void
  * @note       NULL
  */
void Write_Log(char* buff,FIL *file)
{
	int i = 0;
	UINT bb;
	while(buff[i]!='\0')
	{
		f_write(&Log_fil,&buff[i++],1,&bb);
	}
	f_write(&Log_fil,&buff[i],1,&bb);
}
/**
  * @brief      ɨ���ļ�
  * @param      path
  * @param      NumofFile
  * @retval     FRESULT
  * @note       NULL
  */
FRESULT scan_files (
    char* path,        /* Start node to be scanned (***also used as work area***) */
		int *NumofFile
		)
{
    FRESULT res;
    DIR dir;
    UINT i;
    static FILINFO fno;


    res = f_opendir(&dir, path);                       /* Open the directory */
    if (res == FR_OK) {
        for (;;) {
            res = f_readdir(&dir, &fno);                   /* Read a directory item */
            if (res != FR_OK || fno.fname[0] == 0) break;  /* Break on error or end of dir */
            if (fno.fattrib & AM_DIR) {                    /* It is a directory */
                i = strlen(path);
                sprintf(&path[i], "/%s", fno.fname);
							int num = 0;
                res = scan_files(path,&num);                    /* Enter the directory */
                if (res != FR_OK) break;
                path[i] = 0;
            } else {                                       /* It is a file. */
                (*NumofFile)++;
            }
        }
        f_closedir(&dir);
    }

    return res;
}
/********************************FREERTOS*********************************/
/**
  * @brief      Write logs to ringbuffer and try to write into SD card
  * @param      NULL
  * @retval     void
  * @note       NULL
  */
void WriteLogs_Task()
{
	while(f_mount(&log_fs, "", 0)!=FR_OK);
	scan_files(Lofname,&numoftxt);
	
	sprintf(logtxtname,"Log/log%d.txt",numoftxt++);
	f_open(&Log_fil,logtxtname,FA_CREATE_ALWAYS|FA_WRITE);
	Write_Log("Chassis Log Create!\r\n",&Log_fil);
	f_close(&Log_fil);
	
	f_open(&Log_fil,logtxtname,FA_WRITE);
	f_lseek(&Log_fil,Log_fil.obj.objsize);
	char buff[50] = "Log:Chassis_log Start\r\n";
	Write_Log(buff,&Log_fil);
	f_close(&Log_fil);
	
	
	for(;;)
	{
		while(f_mount(&log_fs, "", 0)!=FR_OK);
		openres = f_open(&Log_fil,logtxtname,FA_WRITE);
		f_lseek(&Log_fil,Log_fil.obj.objsize);
		sprintf(buff,"Time Now: %ld\r\n",(long)HAL_GetTick());
		Write_Log(buff,&Log_fil);
		
		sprintf(buff,"NowEnergybuff: %ld\r\n",(long)Referee_RefereeData.chassis_power_buffer);
		Write_Log(buff,&Log_fil);
		
		sprintf(buff,"NowPower: %ld\r\n",(long)Referee_RefereeData.chassis_power);
		Write_Log(buff,&Log_fil);
		
		while(!RingBuffIsEmpty(&logbuff))
		{
			RingBuf_Read(&logbuff,(uint8_t *)buff);
			Write_Log(buff,&Log_fil);
		}
		Write_Log("\r\n\r\n\r\n\r\n\r\n\r\n",&Log_fil);
		f_close(&Log_fil);
		osDelay(500);
	}
}

/**
  * @brief      Start log task
  * @param      NULL
  * @retval     void
  * @note       NULL
  */
void FreeRTOS_LogTaskStart()
{
	InitringBuffer(&logbuff,40);
	xTaskCreate((TaskFunction_t)WriteLogs_Task,"",1024,NULL,6,NULL);
}

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/

