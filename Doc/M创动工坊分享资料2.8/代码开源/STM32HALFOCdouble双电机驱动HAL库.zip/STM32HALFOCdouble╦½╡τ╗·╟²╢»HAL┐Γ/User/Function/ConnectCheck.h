/**
 * DreamChaser Frame Header File
 * 
 * @File:        .h
 * @Brief:       
 * @Author:      Peng Huishuai
 * @Modified:    
 *
 */
#ifndef _CONNECTSCHDULE_H
#define _CONNECTSCHDULE_H
#ifdef __cplusplus
extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "miniPC_dev.h"

/* Const ----------------------------------------------------------------------*/
	
/* define ---------------------------------------------------------------------*/
	
/* Typedef --------------------------------------------------------------------*/
typedef enum
{
	DISCONNECTED = 0,
	CONNECTED    = 1,
}ConnectStatus_t;
	
/* Variables ------------------------------------------------------------------*/

/* Functions ------------------------------------------------------------------*/	 
void StartCheck(void);

#ifdef __cplusplus
}
#endif
#endif
/************************ COPYRIGHT BIT DreamChaser *****END OF FILE****/










