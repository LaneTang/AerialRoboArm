/**
 * DreamChaser Frame Header File
 * 
 * @File:        .h
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#ifndef __X_H
#define __X_H

#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "filter_lib.h"
#include "mathtools_lib.h"
#include "miniPC_dev.h"
#include "usbd_cdc_if.h"	
/* define ----------------------------------------------------------------------*/
	 
/* Typedef --------------------------------------------------------------------*/
typedef enum{
	DISTANCE_ERROR  = 0,
	DISTANCE_CLOSE  = 1,
	DISTANCE_MIDDLE = 2,
	DISTANCE_FAR    = 3,
}DistanceLevel_ModeType_e;

typedef struct{
	float x;
	float y;
	float z;
	float vx;
	float vz;
	float ax;
	float az;
	
	float last_vx;
	float last_vz;
	
	float x_predict_val;
	float z_predict_val;
	
	DistanceLevel_ModeType_e distance_level;
}TargetData_t;	

/* Variables ------------------------------------------------------------------*/
extern float v_Chassis;
extern TargetData_t TargetData_predict , TargetData_predict_re;

/* Functions ------------------------------------------------------------------*/	 
void GimbalMove_AutoAimRef_Change(void);
void GimbalMove_FolowOther_AutoAimRef_Change(void);
void AutoAim_Para_Init(void);

#ifdef __cplusplus
}
#endif

#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
