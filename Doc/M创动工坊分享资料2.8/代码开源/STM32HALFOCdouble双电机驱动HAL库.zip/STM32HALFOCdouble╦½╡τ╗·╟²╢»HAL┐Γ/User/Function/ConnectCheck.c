/**
 * DreamChaser Frame Source File
 * 
 * @File:        
 * @Brief:       检测各部分是否离线
 * @Author:      
 * @Modified:    2021年10月30日
 */
/* Includes -------------------------------------------------------------------*/

#include "ConnectCheck.h"
#include "connect_task.h"

/* Variables ------------------------------------------------------------------*/
uint8_t Connect_Flag[7];

uint32_t PreTick[7];

/* Functions ------------------------------------------------------------------*/
void Check_Connect(void);

//xTaskHandle Gimbal_resume_L,Gimbal_resume_R; 
/**
 * @brief 	开启检测任务（云台，电脑）
 * @param 	None
 * @retval	None
 * @note	None
 */
void StartCheck()
{
	xTaskCreate((TaskFunction_t)Check_Connect,"",64,NULL,6,NULL);	
}
/**
 * @brief 	检测底盘是否离线
	@param 	None
 * @retval	None
 * @note	None
 */
void CheckConnect_Chassis()
{
	if(PreTick[CHASSIS_JUDGE] == *(uint32_t*)&ChassisData.Chassis.DataFlow)
		{
			if(Connect_Flag[CHASSIS_JUDGE] == CONNECTED)
			{
				Connect_Flag[CHASSIS_JUDGE] = DISCONNECTED;
				//CALLBACK_DISCONNECT(CHASSIS);
			}
		}
		else
		{
			if(Connect_Flag[CHASSIS_JUDGE] == DISCONNECTED)
			{
				//CALLBACK_CONNECT(CHASSIS);
				Connect_Flag[CHASSIS_JUDGE] = CONNECTED;
			}
			
		}
		PreTick[CHASSIS_JUDGE] = *(uint32_t*)&ChassisData.Chassis.DataFlow;
}
///**
// * @brief 	检测裁判系统是否离线
//	@param 	None
// * @retval	None
// * @note	None
// */
//void CheckConnect_Referee()
//{
//	if(PreTick[CHASSIS_JUDGE] == *(uint32_t*)&Referee_RefereeData.last_update_time)
//		{
//			if(Connect_Flag[CHASSIS_JUDGE] == CONNECTED)
//			{
//				Connect_Flag[CHASSIS_JUDGE] = DISCONNECTED;
//				AddAnEvent("\r\nReferee_LOST\r\n");
//			}
//		}
//		else
//		{
//			if(Connect_Flag[CHASSIS_JUDGE] == DISCONNECTED)
//			{
//				//CALLBACK_CONNECT(JUDGE_SYSTEM);
//				Connect_Flag[CHASSIS_JUDGE] = CONNECTED;
//				AddAnEvent("\r\nReferee_CONNECTED\r\n");
//			}
//			
//		}
//		PreTick[CHASSIS_JUDGE] = *(uint32_t*)&Referee_RefereeData.last_update_time;
//}


/**
 * @brief 	检查电脑是否在线
 * @param 	None
 * @retval	None
 * @note	None
 */

void CheckConnect_MINIPC_LOWER()
{
	if(PreTick[MINIPC_LOWER1] == *(uint32_t*)&DataFromPC.target_data.timestamp) 
		{
			if(Connect_Flag[MINIPC_LOWER1] == CONNECTED)
			{
				Connect_Flag[MINIPC_LOWER1] = DISCONNECTED;
				//AddAnEvent("\r\nMINIPC_LOWER_LOST\r\n");
			}
		}
		else
		{
			if(Connect_Flag[MINIPC_LOWER1] == DISCONNECTED)
			{
				//CALLBACK_CONNECT(MINIPC_LOWER);
				Connect_Flag[MINIPC_LOWER1] = CONNECTED;
				//AddAnEvent("\r\nMINIPC_LOWER_CONNECT\r\n");
			}
			
		}
		PreTick[MINIPC_LOWER1] = *(uint32_t*)&DataFromPC.target_data.timestamp;
}

/********************************FREERTOS*********************************/
/**
 * @brief 	检查两个电脑是否在线
 * @param 	None
 * @retval	None
 * @note	None
 */
void Check_Connect()
{
	for(;;)
	{
		osDelay(500);

		CheckConnect_MINIPC_LOWER();

		CheckConnect_Chassis();
	}
}

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
