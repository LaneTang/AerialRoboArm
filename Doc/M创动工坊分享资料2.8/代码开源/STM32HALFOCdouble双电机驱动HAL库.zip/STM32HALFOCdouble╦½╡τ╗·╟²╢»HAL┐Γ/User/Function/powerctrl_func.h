

/**
 * DreamChaser Frame Header File
 * 
 * @File:        shootctrl.h
 * @Brief:       
 * @Author:      Zhu Tianyu
 * @Modified:    2021/10/26
 *
 */
#ifndef POWERCTRL_FUNC_H
#define POWERCTRL_FUNC_H
#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "referee_dev.h"
#include "mathtools_lib.h"
/* define ----------------------------------------------------------------------*/
	 
/* Typedef --------------------------------------------------------------------*/

	 
/* Variables ------------------------------------------------------------------*/


/* Functions ------------------------------------------------------------------*/	 
void PowerctrlInit(void);
float Power_PowerCtrl(float output);


#ifdef __cplusplus
}
#endif
#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
