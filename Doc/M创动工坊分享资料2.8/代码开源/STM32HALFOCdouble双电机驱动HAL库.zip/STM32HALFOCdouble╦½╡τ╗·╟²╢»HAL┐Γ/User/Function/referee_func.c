/**
 * DreamChaser Frame Source File
 * 
 * @File:        .c
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */

/* Includes -------------------------------------------------------------------*/
#include "referee_func.h"	
#include "movectrl_func.h"
#include "connect_check_func.h"
#include "modectrl_task.h"

/* Variables ------------------------------------------------------------------*/
uint8_t self_color;  //1：红色  2：蓝色  0：错误

uint16_t Self_Outpost_HP;
uint16_t Last_Self_Outpost_HP;
uint16_t Last_Remain_HP;
Queue_Remain_HP_t Queue_Remain_HP;
uint16_t Referee_Remain_HP_SelectCount;

uint8_t isBackHurt , isFrontHurt;
uint8_t isHurtFast;  //2s内掉血50
uint8_t isBigHurt;  //受到大弹丸伤害
uint8_t isDartHurt;
uint8_t isOverShootSpeed;  //超射速
uint8_t isOverShootHeat;   //超热量
uint8_t isOverChassisPower; //超功率

uint32_t Referee_SafeTimeCount , Referee_HurtTimeCount;

InterRobot_TX_t InterRobot_TX_200, InterRobot_TX_201, InterRobot_TX_202;
uint8_t InterRobot_ENERGYBUFF_TX_BUFF[Const_InterRobot_TX_BUFF_LEN];
/* Functions ------------------------------------------------------------------*/	 
/**
 * @brief 	xx
 * @param 	None
 * @retval	None
 * @note	None
 */
void Referee_DataProcess_Init(void){
	
	isBackHurt = isFrontHurt = isHurtFast = isBigHurt = 0;
	isOverShootSpeed = isOverShootHeat = isOverChassisPower = 0;
	Referee_SafeTimeCount = 0;
	Referee_HurtTimeCount = 0;
	Referee_Remain_HP_SelectCount = 0;
	Referee_RefereeData.hurt_type = 10;
	Referee_RefereeData.armor_id = 10;
	Last_Remain_HP = Referee_RefereeData.remain_HP;
	Queue_Remain_HP.front = Queue_Remain_HP.rear = 0;
		
}

/**
  * @brief      
  * @param      
  * @retval    
  */
void Referee_DataClear(void){
	if(Referee_SafeTimeCount > 4000){
		isBackHurt = 0;
		isFrontHurt = 0;
		isBigHurt = 0;
		Referee_RefereeData.hurt_type = 10;
		Referee_RefereeData.armor_id = 10;
		Referee_SafeTimeCount = 0;
		Queue_Remain_HP.front = Queue_Remain_HP.rear = 0;
	}
	
	if(Last_Remain_HP == Referee_RefereeData.remain_HP){
		Referee_SafeTimeCount++;
	}
	else if(Last_Remain_HP > Referee_RefereeData.remain_HP){
		Referee_SafeTimeCount = 0;
	}
	
	Last_Remain_HP = Referee_RefereeData.remain_HP;
}
	
/**
 * @brief 	小电脑原始数据入队
 * @param 	None
 * @retval	None
 * @note	None
 */
void Referee_Remain_HP_enQueue(void){

	  if((Queue_Remain_HP.rear + 1) % maxSize_Remain_HP == Queue_Remain_HP.front){  
    	  Queue_Remain_HP.front = (Queue_Remain_HP.front + 1) % maxSize_Remain_HP;
	  }
	  Queue_Remain_HP.rear = (Queue_Remain_HP.rear + 1) % maxSize_Remain_HP;
	  Queue_Remain_HP.data[Queue_Remain_HP.rear] = Referee_RefereeData.remain_HP;
	    	
}

/**
  * @brief      
  * @param      
  * @retval    
  */
void Referee_DataProcess(void){
	Referee_RefereeDataTypeDef* referee = &Referee_RefereeData;
	
	if(referee->robot_id == 7){   //己方为红方
		self_color = 1;
	}
	else if(referee->robot_id == 107){   //己方为蓝方
		self_color = 2;
	}
	else{
		self_color = 0;
	}
	
	/*大弹丸受击监测*/
	if(Last_Remain_HP - referee->remain_HP > 90){
		isBigHurt = 1;
	}
	
	Referee_DataClear();
	
	/*哨兵掉血监测*/
	if(referee->hurt_type == 0){ 
		if(Referee_Remain_HP_SelectCount >= 100){
		    Referee_Remain_HP_enQueue();
			Referee_Remain_HP_SelectCount = 0;
		}
		else{
            Referee_Remain_HP_SelectCount++;
		}
		
		if(referee->armor_id == 0){ //不确定，假设前
	        isFrontHurt = 1;
		}
		else if(referee->armor_id == 1){
			isBackHurt = 1;
		}
		
		if(Queue_Remain_HP.data[Queue_Remain_HP.rear] - Queue_Remain_HP.data[Queue_Remain_HP.front] >= 50){
			isHurtFast = 1;
		}
		else{
			isHurtFast = 0;
		}
	}
	else if(referee->hurt_type == 2 && referee->game_progress == 4){
		isOverShootSpeed = 1;
	}
	else if(referee->hurt_type == 3){
		isOverShootHeat = 1;
	}
	else if(referee->hurt_type == 4){
		isOverChassisPower = 1;
	}
	
	/*前哨站状态检测*/
	if(self_color == 1){
		Self_Outpost_HP = referee->red_outpost_HP;
	}
	else if(self_color == 2){
		Self_Outpost_HP = referee->blue_outpost_HP;
	}
	
	/*飞镖受击检测*/
	if(Last_Self_Outpost_HP - Self_Outpost_HP > 400){
		isDartHurt = 1;
	}
	else{
		isDartHurt = 0;
	}
	
	Last_Self_Outpost_HP = Self_Outpost_HP;
}

	
/**
  * @brief  机器人间通讯发送
  * @param      
  * @retval    
  */
void InterRobot_Send(void){
	Referee_RefereeDataTypeDef* referee = &Referee_RefereeData;

	InterRobot_TX_200.InterRobot_TX_BUFF[0] = 0;
	InterRobot_TX_200.InterRobot_TX_BUFF[1] = 1;
	InterRobot_TX_200.InterRobot_TX_BUFF[2] = 2;
	InterRobot_TX_200.InterRobot_TX_BUFF[3] = 3;
	InterRobot_TX_200.InterRobot_TX_BUFF[4] = 4;
	InterRobot_TX_200.InterRobot_TX_BUFF[5] = 5;
	InterRobot_TX_200.InterRobot_TX_BUFF[6] = 6;
	
	InterRobot_ENERGYBUFF_TX_BUFF[0] = referee->chassis_power_buffer;
	if(self_color == 1){
		Referee_SendRobotCustomData(0x0200 , 6, InterRobot_TX_200.InterRobot_TX_BUFF, Const_InterRobot_TX_BUFF_LEN); 
		osDelay(10);
	}
	else if(self_color == 2){
		Referee_SendRobotCustomData(0x0200 , 106, InterRobot_TX_200.InterRobot_TX_BUFF, Const_InterRobot_TX_BUFF_LEN);
		osDelay(10);
	}
}
/**
  * @brief      裁判系统机器人间通信任务
  * @param      
  * @retval    
  */
void Referee_Task() 
{	
	for(;;)
	{
		InterRobot_Send();
		
		osDelay(20);
	}	
}


/************************ RTOS *******************/

void Referee_Task_Start(void)
{
	xTaskCreate((TaskFunction_t)Referee_Task,"",256,NULL,6,NULL);
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
