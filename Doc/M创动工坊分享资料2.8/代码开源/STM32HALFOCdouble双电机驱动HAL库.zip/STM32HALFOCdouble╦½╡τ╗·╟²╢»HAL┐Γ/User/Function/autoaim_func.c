/**
 * DreamChaser Frame Source File
 * 
 * @File:        autoaim_func.c
 * @Brief:       自瞄及其预测
 * @Author:      Zhu Tianyu
 * @Modified:    
 *
 */

/* Includes -------------------------------------------------------------------*/
#include "autoaim_func.h"
#include "movectrl_func.h"	
#include "connect_task.h"
#include "modectrl_task.h"	  

#include <math.h>

/* Variables ------------------------------------------------------------------*/
TargetData_t TargetData_predict;//插帧预测数据  
TargetData_t TargetData_predict_re;//相对自己坐标数据
float bullet_fly_time = 0;//弹丸飞行时间

float kt_Predict_x = 0.5;//x轴预测时间量
float kk_Predict_x = 1;//x轴弹丸飞行时间预测矫正系数
float k_Predict_Correction_x = 1.0f;//x轴总预测量矫正系数

float kt_Predict_z = 0.5;//z轴预测时间量
float kk_Predict_z = 1;//z轴弹丸飞行时间预测矫正系数
float k_Predict_Correction_z = 1.0f;//z轴 总预测量矫正系数

float k_Predict_Offset_y = 0.025;//斜坡补偿增益系数（视觉z轴数据准的话就不需要）

float Autoaim_OffsetPitch = 0, Autoaim_OffsetYaw = 0;
float Predict_Offest_x = -80, Predict_Offset_y = -100,Predict_Offset_z = 0;

float bullet_speed = 28;
float Slef_speed_x = 0;//自身的x轴移动速度，需传入
float Slef_speed_z = 0;//自身的z轴移动速度，需传入


uint8_t is_x_SuddenStart , is_x_SuddenStop , is_z_SuddenStart , is_z_SuddenStop;

uint16_t TimeCountPredict = 0;//插帧用的时间计数器
uint16_t Target_x_SuddenStart_Count , Target_x_SuddenStop_Count , Target_z_SuddenStart_Count , Target_z_SuddenStop_Count;
/* Functions ------------------------------------------------------------------*/
/**
 * @brief 	自瞄相关初始化
 * @param 	None
 * @retval	None
 * @note	None
 */
void AutoAim_Para_Init(){
		  is_x_SuddenStart = is_x_SuddenStop = is_z_SuddenStart = is_z_SuddenStop = 0;
}

/**
  * @brief   Yaw轴打弹角度解析函数（此函数使用了atan，在角度大于180时会出现问题）   
  * @param      
  * @retval     
  * @note       
  */
float YawAngle_Shoot_Cal(float target_x, float target_z){
	if(target_z == 0)
		return 0;
	return(atan(target_x / target_z) / 3.1415926 * 180);
}

/**
  * @brief   Pitch轴打弹角度解析函数   
  * @param      
  * @retval     
  * @note    y向下为正，输出角度向上为正,单位：度，m     
  */
float PitchAngle_Shoot_Cal(float target_x, float target_y, float target_z,float bullet_speed){
	float d = sqrt(target_x*target_x + target_z*target_z);
	float g = 9.8;
	float g_2 = 9.8 * 9.8;
	float v0_2 = bullet_speed * bullet_speed;
	float v0_4 = v0_2 * v0_2;
	float d_2 = d * d;
	if(1 - g_2*d_2/v0_4 + 2*g*target_y/v0_2 < 0)
		return 0;
	return ((atan((v0_2) * (-1 + sqrt(1 - g_2*d_2/v0_4 + 2*g*target_y/v0_2)) / (g * d))) / 3.1415926 * 180);
}

/**
 * @brief 	根据自瞄数据和预测量计算电机期望
 * @param 	None
 * @retval	None
 * @note	None
 */
void GimbalMove_AutoAimRef_Change(){
	
	/*利用外插法预测插帧 & 预测系数修正*///正负需自行调整
	if(it_flag){//define by yourself in usb_cdc_if.c,and set it_flag to 1 in CDC_Receive_FS()
		TargetData_predict.x = (float)DataFromPC.target_data.x + Predict_Offest_x;
	  TargetData_predict.y = (float)DataFromPC.target_data.y + Predict_Offset_y;
		TargetData_predict.z = (float)DataFromPC.target_data.z + Predict_Offset_z;
	    
		
		TargetData_predict.vx = -(float)DataFromPC.target_data.vx;
		TargetData_predict.vz = (float)DataFromPC.target_data.vz;
		TargetData_predict.ax = fabs(TargetData_predict.vx) - fabs(TargetData_predict.last_vx);
		TargetData_predict.az = fabs(TargetData_predict.vz) - fabs(TargetData_predict.last_vz);
		
		
		if(is_x_SuddenStart){
			Target_x_SuddenStart_Count ++;
			k_Predict_Correction_x = 1.1f;
			if(Target_x_SuddenStart_Count > 50){
				Target_x_SuddenStart_Count = 0;
				is_x_SuddenStart = 0;
				k_Predict_Correction_x = 1.0f;
			}
		}
		else if(is_x_SuddenStop){
			Target_x_SuddenStop_Count ++;
			k_Predict_Correction_x = 0.5f;
			if(Target_x_SuddenStop_Count > 50){
				Target_x_SuddenStop_Count = 0;
				is_x_SuddenStop = 0;
				k_Predict_Correction_x = 1.0f;
			}
		}
		else if(TargetData_predict.ax >= 0){
			if(Target_x_SuddenStart_Count == 5){
				is_x_SuddenStart = 1;
				k_Predict_Correction_x = 1.1f;
			}
			else if(TargetData_predict.ax >= 22.0f){
				Target_x_SuddenStart_Count++;
				k_Predict_Correction_x = 1.05f;
			}
			else{
				Target_x_SuddenStart_Count = 0;
				k_Predict_Correction_x = 1.0f;
			}
		}
		else{
			if(Target_x_SuddenStop_Count == 3){
				is_x_SuddenStop = 1;
				k_Predict_Correction_x = 0.5f;
			}
			else if(TargetData_predict.ax <= -18.0f){
				Target_x_SuddenStop_Count++;
				k_Predict_Correction_x = 0.8f;
			}
			else{
				Target_x_SuddenStop_Count = 0;
				k_Predict_Correction_x = 1.0f;
			}
		}
		
		if(is_z_SuddenStart){
			Target_z_SuddenStart_Count ++;
			k_Predict_Correction_z = 1.1f;
			if(Target_z_SuddenStart_Count > 45){
				Target_z_SuddenStart_Count = 0;
				is_z_SuddenStart = 0;
				k_Predict_Correction_z = 1.0f;
			}
		}
		else if(is_z_SuddenStop){
			Target_z_SuddenStop_Count ++;
			k_Predict_Correction_z = 0.5f;
			if(Target_z_SuddenStop_Count > 45){
				Target_z_SuddenStop_Count = 0;
				is_z_SuddenStop = 0;
				k_Predict_Correction_z = 1.0f;
			}
		}
		else if(TargetData_predict.az >= 0){
			if(Target_z_SuddenStart_Count == 5){
				is_z_SuddenStart = 1;
				k_Predict_Correction_z = 1.1f;
			}
			else if(TargetData_predict.az >= 25.0f){
				Target_z_SuddenStart_Count++;
				k_Predict_Correction_z = 1.05f;
			}
			else{
				Target_z_SuddenStart_Count = 0;
				k_Predict_Correction_z = 1.0f;
			}
		}
		else{
			if(Target_z_SuddenStop_Count == 5){
				is_z_SuddenStop = 1;
				k_Predict_Correction_z = 0.5f;
			}
			else if(TargetData_predict.az <= -25.0f){
				Target_z_SuddenStop_Count++;
				k_Predict_Correction_z = 0.5f;
			}
			else{
				Target_z_SuddenStop_Count = 0;
				k_Predict_Correction_z = 1.0f;
			}
		}
	  it_flag = 0;
		TimeCountPredict = 0;
		TargetData_predict.last_vx = TargetData_predict.vx;
		TargetData_predict.last_vz = TargetData_predict.vz;
	}
	else if(TimeCountPredict < 15){
		TargetData_predict.x -=  0.001f * DataFromPC.target_data.vx;
		TargetData_predict.z +=  0.001f * DataFromPC.target_data.vz;
		TimeCountPredict++;
	}
	
    /*云台直角坐标系换算*/
	TargetData_predict_re.vx = TargetData_predict.vx - Slef_speed_x;
	TargetData_predict_re.vz = TargetData_predict.vz - Slef_speed_z;
	TargetData_predict_re.x = TargetData_predict.x;
	TargetData_predict_re.y = TargetData_predict.y;
	TargetData_predict_re.z = TargetData_predict.z;
	
	/*云台预测*/
	bullet_fly_time = 0.001f * sqrt(powf(TargetData_predict_re.x,2) + powf(TargetData_predict_re.y,2) + powf(TargetData_predict_re.z,2)) / SHOOTER_SPEED_FAST;//单位s
	TargetData_predict_re.x_predict_val = kt_Predict_x * TargetData_predict_re.vx + kk_Predict_x * TargetData_predict_re.vx * bullet_fly_time;
	TargetData_predict_re.z_predict_val = kt_Predict_z * TargetData_predict_re.vz + kk_Predict_z * TargetData_predict_re.vz * bullet_fly_time;
	TargetData_predict_re.x += k_Predict_Correction_x * TargetData_predict_re.x_predict_val;
	TargetData_predict_re.z += k_Predict_Correction_z * TargetData_predict_re.z_predict_val;
	
	
	/*云台球坐标系换算*/
  GimbalMove_Data.Yaw_Ref =  YawAngle_Shoot_Cal(TargetData_predict_re.x * 0.001f , TargetData_predict_re.z * 0.001f) + Autoaim_OffsetYaw;
	GimbalMove_Data.Pitch_Ref = -PitchAngle_Shoot_Cal(TargetData_predict_re.x * 0.001f,TargetData_predict_re.y * 0.001f,TargetData_predict_re.z * 0.001f,bullet_speed)
															+ Autoaim_OffsetPitch;
 
	/*远中近距离判断*/
	if(DataFromPC.target_data.ID == 1){  //英雄
		if(TargetData_predict_re.z >= 8500 && TargetData_predict_re.z <= 11000){
			TargetData_predict_re.distance_level = DISTANCE_FAR;
		}
		else if(TargetData_predict_re.z >= 7000){
			TargetData_predict_re.distance_level = DISTANCE_MIDDLE;
		}
		else if(TargetData_predict_re.z >= 0){
			TargetData_predict_re.distance_level = DISTANCE_CLOSE;
		}
		else{
			TargetData_predict_re.distance_level = DISTANCE_ERROR;
		}
	}
	else{
		if(TargetData_predict_re.z >= 8500 && TargetData_predict_re.z <= 11000){
			TargetData_predict_re.distance_level = DISTANCE_FAR;
		}
		else if(TargetData_predict_re.z >= 7000){
			TargetData_predict_re.distance_level = DISTANCE_MIDDLE;
		}
		else if(TargetData_predict_re.z >= 0){
			TargetData_predict_re.distance_level = DISTANCE_CLOSE;
		}
		else{
			TargetData_predict_re.distance_level = DISTANCE_ERROR;
		}
	}
}	 

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
