/**
 * DreamChaser Frame Header File
 * 
 * @File:        log.c
 * @Brief:       往SD卡中写入运行日志
 * @Author:      HuangXingze
 * @Modified:    PengHuishuai
 *
 */
 /* Includes -------------------------------------------------------------------*/

#include "main.h"
#include "log_func.h"
#include "string.h"
#include "connect_task.h"
#include "time.h"
#include "dataStruct_lib.h"
#include "referee_dev.h"
#include "connect_check_func.h"
/* Variables ------------------------------------------------------------------*/
//extern struct tag_Chassis_Task Chassis_Task;

FATFS Log_fs;            /* filesystem object */
FIL Log_fil;             // 
uint32_t SizeOfLog;
char Lofname[] = "Log";  // 文件名
DIR DirInfo;
FATFS log_fs;
int numoftxt = 0;
char logtxtname[20];
ringBuffer_t logbuff;
FRESULT openres;

/* -------------------------------------------Functions ------------------------------------------------*/	   
void WriteLogs(void);
void GetPCTime(const unsigned int time,char* buff);//格式化电脑时间
void Write_Log(char* buff,FIL *file);

/* Functions ------------------------------------------------------------------*/	   


/**
  * @brief      添加一个事件
  * @param      Logbuff：待添加内容
  * @retval     void
  * @note       API接口
  */
void AddAnEvent(char * Logbuff)
{
	RingBuf_Write(&logbuff,(uint8_t *)Logbuff);
}
/**
  * @brief      格式化PC时间
	* @param      
  * @retval     void
  * @note       NULL
  */
void GetPCTime(const unsigned int time,char* buff)
{
	strftime(buff,30,"%Y -%m-%d %H:%M:%S",gmtime(&time));
}
/**
  * @brief       无用
  * @param       
  * @retval     void
  * @note       NULL
  */
void CAN_Connenct_log()
{
	
}
/**
  * @brief      写入单个日志
  * @param      buff：待写入的内容
	* @param      file：文件名
  * @retval     void
  * @note       被WriteLogs()引用
  */
void Write_Log(char* buff,FIL *file)
{
	int i = 0;
	UINT bb;
	while(buff[i]!='\0')
	{
		f_write(&Log_fil,&buff[i++],1,&bb);
	}
	f_write(&Log_fil,&buff[i],1,&bb);
}
/**
  * @brief      扫描(遍历)文件
  * @param      path
  * @param      NumofFile
  * @retval     FRESULT
  * @note       NULL
  */
FRESULT scan_files (
    char* path,        /* Start node to be scanned (***also used as work area***) */
		int *NumofFile
		)
{
    FRESULT res;
    DIR dir;
    UINT i;
    static FILINFO fno;


    res = f_opendir(&dir, path);                       /* Open the directory */
    if (res == FR_OK) {
        for (;;) {
            res = f_readdir(&dir, &fno);                   /* Read a directory item */
            if (res != FR_OK || fno.fname[0] == 0) break;  /* Break on error or end of dir */
            if (fno.fattrib & AM_DIR) {                    /* It is a directory */
                i = strlen(path);
                sprintf(&path[i], "/%s", fno.fname);
							int num = 0;
                res = scan_files(path,&num);                    /* Enter the directory */
                if (res != FR_OK) break;
                path[i] = 0;
            } else {                                       /* It is a file. */
                (*NumofFile)++;
            }
        }
        f_closedir(&dir);
    }

    return res;
}

/**************************************FreeRTOS********************************/
//extern uint32_t PreTrick[7];
/**
  * @brief      写log
  * @param      NULL
  * @retval     NULL
  * @note       NULL
  */
void WriteLogs()
{
	while(f_mount(&log_fs, "", 0)!=FR_OK);//挂载文件系统
	scan_files(Lofname,&numoftxt);//作用在于计算已有的文件数
	
	sprintf(logtxtname,"Log/log%d.txt",numoftxt++);
	f_open(&Log_fil,logtxtname,FA_CREATE_ALWAYS|FA_WRITE);
	Write_Log("HelloWorld!\r\nChassis Log Create!\r\n",&Log_fil);
	f_close(&Log_fil);
	
	
	f_open(&Log_fil,logtxtname,FA_WRITE);
	f_lseek(&Log_fil,Log_fil.obj.objsize);
	char buff[50] = "Log:Chassis_log Start\r\n";
	Write_Log(buff,&Log_fil);
	f_close(&Log_fil);
	
	
	for(;;)
	{
		while(f_mount(&log_fs, "", 0)!=FR_OK);
		openres = f_open(&Log_fil,logtxtname,FA_WRITE);
		f_lseek(&Log_fil,Log_fil.obj.objsize);
		sprintf(buff,"NowChassis Time: %ld\r\n",(long)HAL_GetTick());
		Write_Log(buff,&Log_fil);
		sprintf(buff,"NowGIMBAL_L Time: %ld\r\n",(long)GimbalDataUpper.Gimbal.DataFlow);
		Write_Log(buff,&Log_fil);
		sprintf(buff,"NowGIMBAL_R Time: %ld\r\n",(long)GimbalDataLower.Gimbal.DataFlow);
		Write_Log(buff,&Log_fil);
		char timebuff[30];
		
		GetPCTime(GimbalDataUpper.MiniPC.DataFlow,timebuff);
		
		sprintf(buff,"NowMINIPCLClock Time: %s\r\n",timebuff);
		Write_Log(buff,&Log_fil);
		GetPCTime(GimbalDataLower.MiniPC.DataFlow,timebuff);
		Write_Log(buff,&Log_fil);
		sprintf(buff,"NowMINIPCRClock Time: %s\r\n",timebuff);
		Write_Log(buff,&Log_fil);
		
		sprintf(buff,"NowEnergybuff: %ld\r\n",(long)Referee_RefereeData.chassis_power_buffer);
		Write_Log(buff,&Log_fil);
		sprintf(buff,"NowPower: %ld\r\n",(long)Referee_RefereeData.chassis_power);
		Write_Log(buff,&Log_fil);
		
		
		
		sprintf(buff,"\r\nJudge: %d Remote: %d GIMBAL_Upper: %d GIMBAL_Lower: %d MiniPC_Upper: %d MiniPC_Lower: %d\r\n",Connect_Flag[CHASSIS_JUDGE],Connect_Flag[REMOTE],Connect_Flag[GIMBAL_UPPER],Connect_Flag[GIMBAL_LOWER],Connect_Flag[MINIPC_UPPER1],Connect_Flag[MINIPC_LOWER1]);
		Write_Log(buff,&Log_fil);
		

		
		while(!RingBuffIsEmpty(&logbuff))
		{
			RingBuf_Read(&logbuff,(uint8_t *)buff);
			Write_Log(buff,&Log_fil);
		}
		Write_Log("\r\n*****************\r\n",&Log_fil);
		f_close(&Log_fil);
		osDelay(500);
	}
}
/**
  * @brief      开启日志
  * @param      NULL
  * @retval     void
  * @note       NULL
  */
void Enable_logging()
{
	InitringBuffer(&logbuff,80);
	xTaskCreate((TaskFunction_t)WriteLogs,"",1024,NULL,6,NULL);
}
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
