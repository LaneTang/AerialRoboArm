/**
 * DreamChaser Frame Header File
 * 
 * @File:        shootctrl.h
 * @Brief:       
 * @Author:      Zhu Tianyu
 * @Modified:    2021/10/23
 *
 */
#ifndef SHOOTCTRL_FUNC_H
#define SHOOTCTRL_FUNC_H
#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "connect_task.h"

/* define ----------------------------------------------------------------------*/
	 
/* Typedef --------------------------------------------------------------------*/
typedef enum {
	FEEDER_SPEED_STOP       	= 0,
	FEEDER_SPEED_WAIT  		    = 1,
	FEEDER_SPEED_SLOW    		= 2,
	FEEDER_SPEED_FAST   		= 3,
	FEEDER_REMOTE               = 4,
	FEEDER_SPEED_REVERSE     	= 5,
}Feeder_ModeType_e; 

typedef struct {
	Feeder_ModeType_e Feeder_Mode;
	float feeder_speed;
	uint16_t Feeder_ReverseCount;  //倒转计时
	uint8_t Feeder_StuckCount;     //卡弹次数
}Feeder_Data_t;
/* Variables ------------------------------------------------------------------*/
extern Feeder_Data_t Feeder_Data;

extern uint16_t Const_HeatCtrlFastLimit;
extern uint16_t Const_HeatCtrlSlowLimit;
extern uint16_t Const_HeatCtrlWaitLimit;
extern uint16_t Const_HeatCtrlStopLimit;

/* Functions ------------------------------------------------------------------*/	 
void FeederInit(void);
void FeederSpeed_Ctrl(void);
void Feeder_StuckProtect(void);

#ifdef __cplusplus
}
#endif
#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
