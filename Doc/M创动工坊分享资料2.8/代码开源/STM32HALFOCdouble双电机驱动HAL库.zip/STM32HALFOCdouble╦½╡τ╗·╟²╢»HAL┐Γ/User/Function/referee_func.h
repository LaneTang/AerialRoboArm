/**
 * DreamChaser Frame Header File
 * 
 * @File:        .h
 * @Brief:       
 * @Author:      Ju	Chaowen
 * @Modified:    
 *
 */
#ifndef __REFEREE_FUNC_H
#define __REFEREE_FUNC_H
#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "referee_dev.h"
/* define ----------------------------------------------------------------------*/
#define maxSize_Remain_HP 20
#define Const_InterRobot_TX_BUFF_LEN 8
/* Typedef --------------------------------------------------------------------*/
typedef struct{
	float data[maxSize_Remain_HP];
	uint8_t front;
	uint8_t rear;
}Queue_Remain_HP_t;	

typedef struct{
	uint8_t InterRobot_TX_BUFF[Const_InterRobot_TX_BUFF_LEN];
	uint8_t Connect_State;
	uint8_t Chassis_State;
	uint8_t Gimbal_Up_State;
	uint8_t Gimbal_Up_Cycle_State;
	uint8_t Gimbal_Low_State;
	uint8_t Gimbal_Low_Cycle_State;

}InterRobot_TX_t;


/* Variables ------------------------------------------------------------------*/
extern uint8_t self_color;
extern uint16_t Self_Outpost_HP;
extern uint8_t isBackHurt; 
extern uint8_t isFrontHurt;
extern uint8_t isHurtFast; 
extern uint8_t isBigHurt;
extern uint8_t isDartHurt;
/* Functions ------------------------------------------------------------------*/	 
void Referee_DataProcess_Init(void);
void Referee_DataProcess(void);
void OverShootProtect(void);
void OverPowerProtect(void);
void Referee_Task_Start(void);
#ifdef __cplusplus
}
#endif
#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
