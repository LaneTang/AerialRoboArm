/**
 * DreamChaser Frame Source File
 * 
 * @File:        feederctrl_func.c
 * @Brief:       
 * @Author:      Zhu Tianyu
 * @Modified:    2021/10/23
 *
 */
 
/* Includes -------------------------------------------------------------------*/
#include "feederctrl_func.h"
#include "gimbal_task.h"
#include "gimbal_task.h"
/* Variables ------------------------------------------------------------------*/
Feeder_Data_t Feeder_Data; 

float Const_FeederSlowSpeed;
float Const_FeederFastSpeed;
float Const_FeederWaitSpeed;

uint16_t Const_HeatCtrlFastLimit;
uint16_t Const_HeatCtrlSlowLimit;
uint16_t Const_HeatCtrlWaitLimit;
uint16_t Const_HeatCtrlStopLimit;
/* Functions ------------------------------------------------------------------*/
/**
  * @brief      拨弹轮初始化
  * @param      NULL
  * @retval     NULL
  */
void FeederInit(void) {
	
    Const_FeederSlowSpeed = 500.0f;
    Const_FeederFastSpeed = 3300.0f;
    Const_FeederWaitSpeed = 0.0f;

    Const_HeatCtrlFastLimit = 60;
    Const_HeatCtrlSlowLimit = 30;
    Const_HeatCtrlWaitLimit = 10;
    Const_HeatCtrlStopLimit = 5;
	
	Feeder_Data.Feeder_ReverseCount = Feeder_Data.Feeder_StuckCount = 0;
}

/**
  * @brief      拨弹轮速度计算
  * @param      NULL
  * @retval     NULL
  */
void FeederSpeed_Ctrl(void) {
    Feeder_Data_t* feeder = &Feeder_Data;
	
	/*下枪口热控*/
	switch(feeder->Feeder_Mode)
	{
		case FEEDER_SPEED_FAST: 
			feeder->feeder_speed = Const_FeederFastSpeed; 
            break;
        
    case FEEDER_SPEED_SLOW: 
			feeder->feeder_speed = Const_FeederSlowSpeed; 
            break;

    case FEEDER_SPEED_WAIT: 
			feeder->feeder_speed = Const_FeederWaitSpeed; 
            break;	

    case FEEDER_SPEED_STOP: 
			if(DataFromPC.target_data.is_get == 1)
			feeder->feeder_speed = ChassisData.Remote.FeederSpeed * 30;
      else
      feeder->feeder_speed = 0;
            break;
 
	  case FEEDER_REMOTE: 
			feeder->feeder_speed = ChassisData.Remote.FeederSpeed * 30; 
		       break;
		
    case FEEDER_SPEED_REVERSE:
        feeder->feeder_speed = -3000;
            break;
		
	default:
			feeder->feeder_speed = 0;
			break;
	}		
	
}

/**
* @brief        云台卡弹反转控制函数
  * @param      NULL
  * @retval     NULL
  */
void Feeder_StuckProtect(void){
	Feeder_Data_t* feeder = &Feeder_Data;
	
	if(feeder->feeder_speed == 0){
		return;
	}
	if(feeder->Feeder_Mode != FEEDER_SPEED_REVERSE && abs(Motor_Feeder.encoder.speed) >= 500){  
		feeder->Feeder_ReverseCount = 0;
		return;
	}
	
	if(feeder->Feeder_Mode != FEEDER_SPEED_REVERSE && abs(Motor_Feeder.encoder.speed) <= 10 && fabs(Motor_Feeder.output) > 5000.0f && feeder->Feeder_ReverseCount < 1500){
		(feeder->Feeder_ReverseCount) ++;
	}
	else if(feeder->Feeder_Mode != FEEDER_SPEED_REVERSE && feeder->Feeder_ReverseCount == 800){
		(feeder->Feeder_StuckCount)++;
		feeder->Feeder_Mode = FEEDER_SPEED_REVERSE;
	}
	else if(feeder->Feeder_Mode == FEEDER_SPEED_REVERSE && feeder->Feeder_ReverseCount <= 500){
		(feeder->Feeder_ReverseCount)++;
		feeder->Feeder_Mode = FEEDER_SPEED_REVERSE;
	}
	else if(feeder->Feeder_Mode == FEEDER_SPEED_REVERSE && feeder->Feeder_ReverseCount > 600){
		feeder->Feeder_ReverseCount = 0;
		feeder->Feeder_Mode = FEEDER_SPEED_STOP;
	}
}



