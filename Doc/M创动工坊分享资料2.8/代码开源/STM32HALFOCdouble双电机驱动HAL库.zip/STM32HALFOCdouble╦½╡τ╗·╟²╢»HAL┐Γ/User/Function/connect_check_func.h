#include "main.h"
#ifndef _CONNECTSCHDULE_H_
#define _CONNECTSCHDULE_H_
typedef enum
{
	DISCONNECTED = 0,
	CONNECTED = 1,
}ConnectStatus_t;

extern ConnectStatus_t Connect_Flag;

void RTOS_CheckTaskStart(void);
#endif
