/**
 * DreamChaser Frame Header File
 * 
 * @File:        log.h
 * @Brief:       
 * @Author:      
 * @Modified:    
 *
 */
#ifndef __LOG_H
#define __LOG_H
#ifdef __cplusplus
 extern "C" {
#endif
/* Includes -------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"
#include "string.h"
#include "stdio.h"
/* define ----------------------------------------------------------------------*/
	 
/* Typedef --------------------------------------------------------------------*/
FRESULT scan_files (
    char* path,        /* Start node to be scanned (***also used as work area***) */
		int *NumofFile
		);
		
/* Variables ------------------------------------------------------------------*/
	 
/* Functions ------------------------------------------------------------------*/	
void FreeRTOS_LogTaskStart(void);
void AddAnEvent(char * Logbuff);
	 
#ifdef __cplusplus
}
#endif
#endif

/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/		
