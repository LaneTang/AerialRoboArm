#include "main.h"
#include "fatfs.h"
#include "string.h"
#include "stdio.h"

/* Functions ------------------------------------------------------------------*/	
FRESULT scan_files (
    char* path,        /* Start node to be scanned (***also used as work area***) */
		int *NumofFile
		);
		
//void Init_Loging(void);
void Enable_logging(void);
void AddAnEvent(char * Logbuff);
/************************ (C) COPYRIGHT BIT DreamChaser *****END OF FILE****/
